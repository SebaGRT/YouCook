<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Emma · Día 3 (domingo 15): Guardados, Perfil y revisión visual

**Meta del día:** las dos últimas pantallas del mockup y la revisión visual de toda la app, en escritorio y en teléfono. Todo en `main` antes de las 18:00.

← [Día 2](dia2.md) · [Índice de guías](../README.md)

## Mapa del día

| Paso | Qué haces | Archivo | Depende de |
|---|---|---|---|
| 1 | Guardados | `guardados/index.blade.php` | Controlador de Miguel (sábado) |
| 2 | Perfil | `perfil/show.blade.php` | Controlador de Miguel (sábado) · **PR antes de las 13:00** |
| 3 | Revisión visual contra el mockup | `docs/evidencia/qa-visual.md` | Todo integrado |
| 4 | Capturas | `docs/evidencia/capturas/` | Paso 3 |
| 5 | (Opcional) Stickers nuevos | `components/stickers/*.blade.php` | — |
| 6 | Preparar tu parte de la presentación | — | — |

**Tiempo:** unas 3 h (~210 líneas de código y la revisión).

Rama: `git switch main && git pull && composer install && npm install && php artisan migrate:fresh --seed && git switch -c emma/dia3-perfil`.

Igual que ayer, las dos vistas ya existen en versión **provisional** de Miguel: míralas para ver las variables y reemplázalas.

---

## Paso 1 · Guardados

En el mockup: `screens/Saved.tsx`. **Reemplaza todo:**

📄 **`web/resources/views/guardados/index.blade.php`** · 36 líneas

```blade
@extends('layouts.app')

@section('titulo', 'Guardados')

@section('contenido')
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h1 class="text-[34px] leading-tight font-black md:text-[44px]">Guardados</h1>
            <p class="mt-1 text-charcoal-soft">
                {{ $recipes->isEmpty() ? 'Tu recetario personal.' : trans_choice('{1} 1 receta para cuando te dé hambre.|[2,*] :count recetas para cuando te dé hambre.', $recipes->count()) }}
            </p>
        </div>
    </div>

    @if ($recipes->isNotEmpty())
        <div class="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            @foreach ($recipes as $recipe)
                <x-recipe-card :recipe="$recipe" saved :cooked="in_array($recipe->id, $cookedIds)" />
            @endforeach
        </div>
    @else
        <div class="mt-8 flex flex-col items-center rounded-[32px] bg-white px-6 py-16 text-center shadow-soft md:py-24">
            <div class="relative h-32 w-48">
                <div class="absolute top-6 left-2"><x-sticker kind="pan" size="84" rotate="-14" /></div>
                <div class="absolute top-0 right-2"><x-sticker kind="tomate" size="96" rotate="10" /></div>
            </div>
            <h2 class="mt-4 text-[26px] font-black">Aún no guardas recetas</h2>
            <p class="mt-2 max-w-sm text-charcoal-soft">
                Toca el ícono <x-icon name="bookmark" size="16" class="inline -translate-y-px text-tomato-500" /> en cualquier receta y aparecerá aquí para tenerla a mano.
            </p>
            <a href="{{ route('recetas.index') }}" class="mt-7 rounded-2xl bg-tomato-500 px-6 py-3.5 font-display font-extrabold text-white shadow-[inset_0_-4px_0_rgb(0_0_0/0.14)] hover:bg-tomato-600">
                Explorar recetas
            </a>
        </div>
    @endif
@endsection
```

**Entiende**
- `trans_choice('{1} … |[2,*] …', $n)` elige el texto según el número: «1 receta» o «3 recetas».
- `<x-recipe-card … saved />`: un atributo sin valor vale `true`. Aquí todas las tarjetas están guardadas.
- El estado vacío es el del mockup: dos stickers superpuestos (con `absolute`) y el botón «Explorar recetas».
- Para verlo vacío, quita los tres guardados de Camila o registra una cuenta nueva.

## Paso 2 · Perfil

En el mockup: `screens/Profile.tsx`. **Reemplaza todo:**

📄 **`web/resources/views/perfil/show.blade.php`** · parte 1 de 5 (líneas 1–28) · empieza el archivo

```blade
@extends('layouts.app')

@section('titulo', 'Perfil')

@section('contenido')
    @php
        $porcentaje = $total > 0 ? (int) round($cooked / $total * 100) : 0;
        $faltan = 10 - $cooked;
        $giros = [-6, 4, -3, 7, -8, 3, -4, 6, -2, 5];
    @endphp

    <div class="grid gap-8 lg:grid-cols-[340px_1fr]">
        <aside class="h-fit space-y-5">
            {{-- --- Tarjeta de la persona --- --}}
            <div class="rounded-[28px] bg-white p-7 text-center shadow-soft">
                <div class="mx-auto w-fit"><x-avatar size="96" /></div>
                <h1 class="mt-4 text-[26px] font-black">{{ $user->name }}</h1>
                <p class="text-charcoal-soft">{{ $user->email }}</p>
                <span class="mt-3 inline-block rounded-full bg-tomato-50 px-3 py-1 text-sm font-bold text-tomato-600">{{ $level }}</span>
                <dl class="mt-6 grid grid-cols-3 divide-x divide-cream-200 rounded-2xl bg-cream p-3">
                    @foreach (['Cocinadas' => $cooked, 'Guardadas' => $saved, 'Stickers' => $cooked] as $nombre => $valor)
                        <div>
                            <dd class="font-display text-2xl font-black">{{ $valor }}</dd>
                            <dt class="text-xs text-charcoal-soft">{{ $nombre }}</dt>
                        </div>
                    @endforeach
                </dl>
            </div>
```

**Entiende**
- El `@php` de arriba calcula lo que se usa varias veces: el porcentaje, cuántas faltan para la insignia y los giros de los stickers (los mismos números del mockup).
- `$level`, `$cooked`, `$saved` y `$total` vienen del controlador de Miguel.
- El `@foreach` recorre un arreglo `['Cocinadas' => 7, ...]`: `$nombre` es la clave y `$valor`, el número. Cada sticker se gana al cocinar una receta: por eso «Stickers» es igual a «Cocinadas».

📄 **`web/resources/views/perfil/show.blade.php`** · parte 2 de 5 (líneas 30–84) · sigue debajo de la parte anterior

```blade
            {{-- --- Mis datos: se ven como texto y «Editar» los cambia por campos --- --}}
            <form
                method="POST"
                action="{{ route('perfil.update') }}"
                class="space-y-4 rounded-[28px] bg-white p-6 shadow-soft"
                x-data="{ editando: @js($errors->any()) }"
            >
                @csrf
                @method('PATCH')

                <h2 class="font-display text-lg font-extrabold">Mis datos</h2>

                <div x-show="! editando" class="space-y-4">
                    @foreach (['Nombre' => $user->name, 'Correo' => $user->email, 'Miembro desde' => Str::ucfirst($user->created_at->translatedFormat('F Y'))] as $nombre => $valor)
                        <div class="flex items-center justify-between gap-3 border-b border-cream-200 pb-3 text-sm last:border-0">
                            <span class="shrink-0 text-charcoal-soft">{{ $nombre }}</span>
                            <span class="truncate font-semibold">{{ $valor }}</span>
                        </div>
                    @endforeach
                </div>

                <div x-show="editando" x-cloak class="space-y-4">
                    <div>
                        <x-input-label for="name" value="Nombre" />
                        <x-text-input id="name" name="name" class="w-full" :value="old('name', $user->name)" required autocomplete="name" />
                        <x-input-error :messages="$errors->get('name')" class="mt-1.5" />
                    </div>
                    <div>
                        <x-input-label for="email" value="Correo" />
                        <x-text-input id="email" name="email" type="email" class="w-full" :value="old('email', $user->email)" required autocomplete="username" />
                        <x-input-error :messages="$errors->get('email')" class="mt-1.5" />
                    </div>
                </div>

                <div class="flex gap-2 pt-1">
                    <button type="button" x-show="! editando" x-on:click="editando = true" class="flex flex-1 items-center justify-center gap-2 rounded-xl border-2 border-cream-300 py-2.5 text-sm font-bold hover:border-tomato-200">
                        <x-icon name="pencil" size="15" /> Editar
                    </button>
                    <button type="submit" x-show="editando" x-cloak class="flex flex-1 items-center justify-center gap-2 rounded-xl bg-tomato-500 py-2.5 text-sm font-bold text-white hover:bg-tomato-600">
                        <x-icon name="check" size="15" /> Guardar
                    </button>
                    {{-- Este botón envía el formulario «salir», que está más abajo
                         (un formulario no puede ir dentro de otro). --}}
                    <button type="submit" form="salir" class="flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold text-charcoal-soft hover:bg-cream-200">
                        <x-icon name="logout" size="15" /> Cerrar sesión
                    </button>
                </div>
            </form>

            <form id="salir" method="POST" action="{{ route('logout') }}" class="hidden">
                @csrf
            </form>
        </aside>

        <div class="space-y-8">
```

**Entiende**
- En el mockup, «Editar» no hacía nada. Aquí sí: `editando` (Alpine) cambia entre ver los datos como texto y editarlos en campos. `x-show` muestra uno u otro.
- `x-data="{ editando: @js($errors->any()) }"`: si el formulario volvió con errores, parte abierto en modo edición para que se vean.
- `@method('PATCH')`: HTML solo envía `GET` y `POST`; este campo oculto le dice a Laravel que es una actualización (`PATCH /perfil`).
- `old('name', $user->name)`: lo que la persona escribió si hubo un error; si no, el valor guardado.
- «Cerrar sesión» envía **otro** formulario (`form="salir"`), porque un formulario no puede ir dentro de otro.
- `translatedFormat('F Y')` escribe la fecha en español: «Noviembre 2026».

📄 **`web/resources/views/perfil/show.blade.php`** · parte 3 de 5 (líneas 85–104) · sigue debajo de la parte anterior

```blade
            {{-- --- Progreso del reto --- --}}
            <section class="relative overflow-hidden rounded-[32px] bg-charcoal p-7 text-white md:p-9">
                <div class="pointer-events-none absolute -top-6 right-6 hidden md:block"><x-sticker kind="olla2" size="120" rotate="12" /></div>
                <p class="font-display text-sm font-extrabold tracking-wider text-[#FFC23D] uppercase">Reto YouCook</p>
                <h2 class="mt-2 max-w-md text-[30px] leading-tight font-black md:text-[38px]">
                    {{ $cooked }} de {{ $total }} recetas cocinadas
                </h2>
                <p class="mt-2 text-white/75">
                    {{ $faltan > 0 ? "Te faltan {$faltan} para desbloquear la insignia «Chef de pensión»." : '¡Desbloqueaste «Chef de pensión»! Vamos por las 20.' }}
                </p>
                <div class="mt-6 flex items-center gap-4">
                    <div class="h-4 flex-1 overflow-hidden rounded-full bg-white/15" role="progressbar" aria-valuenow="{{ $cooked }}" aria-valuemin="0" aria-valuemax="{{ $total }}">
                        <div class="h-full rounded-full bg-gradient-to-r from-[#FFC23D] to-tomato-500 transition-all duration-700" style="width: {{ $porcentaje }}%"></div>
                    </div>
                    <span class="font-display text-xl font-black">{{ $porcentaje }}%</span>
                </div>
                <div class="mt-3 flex justify-between text-xs text-white/60">
                    <span>Inicio</span><span>5 · Aprendiz</span><span>10 · Chef de pensión</span><span>20 · Maestra</span>
                </div>
            </section>
```

**Entiende**
- La barra de progreso es un `<div>` dentro de otro: el de adentro mide `width: 35%`.
- `role="progressbar"` con `aria-valuenow` describe la barra a los lectores de pantalla.
- `"Te faltan {$faltan} para…"`: dentro de comillas dobles, PHP reemplaza `{$variable}` por su valor.

📄 **`web/resources/views/perfil/show.blade.php`** · partes 4 a 5 de 5 (líneas 106–148) · sigue debajo de la parte anterior

```blade
            {{-- --- Stickers --- --}}
            <section>
                <div class="flex items-baseline justify-between">
                    <h2 class="text-2xl font-black">Mis stickers</h2>
                    <span class="text-sm text-charcoal-soft">{{ $cooked }} de {{ $total }} desbloqueados</span>
                </div>
                <div class="mt-5 grid grid-cols-3 gap-3 rounded-[28px] bg-white bg-[radial-gradient(circle_at_1px_1px,#efdcc0_1px,transparent_0)] [background-size:18px_18px] p-5 shadow-soft sm:grid-cols-5 xl:grid-cols-10">
                    @foreach ($recipes as $recipe)
                        @php $ganado = in_array($recipe->id, $cookedIds); @endphp
                        <div class="flex flex-col items-center gap-1 text-center" title="{{ $ganado ? $recipe->sticker_name : 'Bloqueado' }}">
                            <div class="{{ $ganado ? 'pop' : 'opacity-80' }}" style="animation-delay: {{ $loop->index * 40 }}ms">
                                <x-sticker :kind="$recipe->sticker" size="72" :locked="! $ganado" :rotate="$giros[$loop->index % count($giros)]" />
                            </div>
                            <span class="text-[11px] leading-tight font-semibold {{ $ganado ? 'text-charcoal' : 'text-[#B3A99D]' }}">{{ $ganado ? $recipe->sticker_name : '???' }}</span>
                        </div>
                    @endforeach
                </div>
            </section>

            {{-- --- Checklist --- --}}
            <section class="rounded-[28px] bg-white p-6 shadow-soft md:p-8">
                <h2 class="text-2xl font-black">Checklist de recetas</h2>
                <p class="mt-1 text-sm text-charcoal-soft">Cada receta que marques como cocinada te da un sticker nuevo.</p>
                <ul class="mt-5 grid gap-x-8 sm:grid-cols-2">
                    @foreach ($recipes as $recipe)
                        @php $ganado = in_array($recipe->id, $cookedIds); @endphp
                        <li class="flex items-center gap-3 border-b border-cream-200 py-3">
                            <span class="grid size-6 shrink-0 place-items-center rounded-lg {{ $ganado ? 'bg-basil-500 text-white' : 'border-2 border-cream-300' }}">
                                @if ($ganado)
                                    <x-icon name="check" size="14" stroke="3" />
                                @endif
                            </span>
                            <a href="{{ route('recetas.show', $recipe) }}" class="flex-1 hover:text-tomato-600 {{ $ganado ? 'text-charcoal-soft line-through decoration-cream-300' : 'font-medium' }}">{{ $recipe->title }}</a>
                            @unless ($ganado)
                                <x-icon name="lock" size="14" class="text-[#C9B394]" />
                            @endunless
                        </li>
                    @endforeach
                </ul>
            </section>
        </div>
    </div>
@endsection
```

**Entiende**
- Los stickers recorren las 20 recetas: si está cocinada (`$ganado`), se dibuja su sticker con su nombre; si no, el «?» bloqueado y «???».
- `$loop->index` es el número de vuelta partiendo en 0. Se usa para el giro de cada sticker y para el retraso de la animación `pop` (aparecen de a uno).
- El fondo de puntitos es `bg-[radial-gradient(...)]` con `[background-size:18px_18px]`: valores a la medida, copiados del mockup.
- En el checklist, todas las recetas enlazan a su detalle (en el mockup solo 8 existían de verdad).

Revisa con la cuenta de Camila y sube el PR **antes de las 13:00**:

- [ ] «7 de 20 recetas cocinadas», 35 %, «Te faltan 3…», 7 stickers con nombre y 13 bloqueados.
- [ ] «Editar» abre los campos; guardar muestra el aviso «Datos actualizados». Un correo inválido muestra el error con el formulario abierto.
- [ ] «Cerrar sesión» lleva a `/login`.
- [ ] `/guardados` con 3 recetas y, con una cuenta nueva, el estado vacío.

```bash
npm run build && php artisan test
git add . && git commit -m "Guardados y Perfil del mockup"
git push -u origin emma/dia3-perfil
```

## Paso 3 · Revisión visual contra el mockup

Con todo integrado (`git switch main && git pull && php artisan migrate:fresh --seed`), compara **pantalla por pantalla** con el mockup y con las capturas de [`objetivo/`](../objetivo/). Hazlo en dos anchos: escritorio (1440 px) y teléfono (390 px; en el navegador, `F12` → ícono de teléfono).

Anota en `docs/evidencia/qa-visual.md` una tabla con: pantalla, ancho, ¿igual al mockup?, diferencia y si se corrigió.

| Pantalla | Qué mirar |
|---|---|
| Registro e ingreso | Foto y stickers a la izquierda (solo escritorio); errores bajo cada campo |
| Catálogo | Stickers del buscador (solo escritorio), categorías con scroll horizontal en teléfono, 4 / 2 / 1 columnas |
| Detalle | Botón de guardar sobre la foto (solo teléfono), datos en 2 o 4 columnas, panel de la IA en sus 3 estados |
| Asistente | La columna izquierda desaparece en teléfono; el chat ocupa el alto de la pantalla; las sugerencias se deslizan |
| Guardados | Con recetas y vacío |
| Perfil | Stickers en 3, 5 o 10 columnas; checklist en 1 o 2 columnas |
| Todas | La barra de abajo no tapa contenido; el aviso (toast) queda sobre la barra en teléfono |

Además:

- [ ] Recorre la app solo con el teclado (`Tab` y `Enter`): todo lo que se puede tocar muestra el borde de foco.
- [ ] Ningún texto se sale de su caja con un nombre largo (regístrate como «María Fernanda de los Ángeles Valenzuela»).

Las diferencias **intencionales** ya están en el [índice](../README.md#qué-cambia-respecto-del-mockup): no las anotes como errores. Corrige lo pequeño tú misma (son clases de Tailwind); si el problema está en un archivo de otro, avísale. **Todo antes de las 18:00.**

## Paso 4 · Capturas

Guarda en `docs/evidencia/capturas/` una captura de cada pantalla en escritorio y en teléfono (14 en total), más tres de estados: alternativas de la IA, aviso de receta cocinada y guardados vacío. Van al README y a la presentación.

## Paso 5 · (Opcional) Stickers nuevos

Solo si sobra tiempo. Nueve recetas comparten el sticker `estrella`. Para darle uno propio a una receta:

1. Copia `components/stickers/tomate.blade.php` con otro nombre, por ejemplo `cazuela.blade.php`, y cambia las formas (el lienzo mide 100 × 100).
2. En `database/data/recetas.php`, cambia `'sticker' => 'estrella'` por `'sticker' => 'cazuela'` en esa receta (el archivo es de Miguel: avísale).
3. `php artisan migrate:fresh --seed` y mira el Perfil.

En la propuesta ya dejamos anotado el riesgo de no alcanzar: la estrella es un resultado válido.

## Paso 6 · Preparar tu parte de la presentación

Tienes que poder explicar en 2 minutos, mostrando el código:

- [ ] Cómo se pasó el mockup de React a Blade: un componente de React = un componente Blade (`<RecipeCard r={r} />` → `<x-recipe-card :recipe="$recipe" />`), con las mismas clases de Tailwind.
- [ ] Qué es un layout y cómo lo usan las páginas: `@extends`, `@section` y `@yield` (`layouts/app.blade.php`).
- [ ] Dónde hay Alpine y por qué (el ojo de la contraseña, los pasos, «Editar») y dónde hay un formulario (guardar, cocinada), y la diferencia entre ambos.
- [ ] Cómo se adapta la app al teléfono (`md:hidden`, `lg:grid-cols-4`, las dos barras).
- [ ] Las diferencias declaradas con el mockup.

## Cierre del día

- [ ] `qa-visual.md` y las capturas en `main` antes de las 18:00.
- [ ] Ensayo general a las 21:00.
