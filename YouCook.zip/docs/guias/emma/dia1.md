<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Emma · Día 1 (viernes 13): íconos, stickers, ingreso y barra de navegación

**Meta del día:** las piezas visuales que usa toda la app (íconos, logo y stickers), las pantallas de ingreso y registro del mockup y el layout con la barra de navegación.

← [Índice de guías](../README.md) · Siguiente: [Día 2](dia2.md)

## Mapa del día

| Paso | Qué haces | Archivo | Depende de |
|---|---|---|---|
| 0 | Clonar y dejar el proyecto andando | (comandos) | Esqueleto de Sebastián (~10:30) |
| 1 | Íconos | `components/icon.blade.php` | — |
| 2 | Logo | `components/logo.blade.php` | — |
| 3 | Stickers: la carita y los 12 dibujos | `components/sticker-face.blade.php`, `components/stickers/*.blade.php` | — |
| 4 | El sticker con borde blanco | `components/sticker.blade.php` | — |
| 5 | Mirar íconos y stickers | `resources/views/muestra.blade.php` (no se sube) | — |
| 6 | Layout de ingreso | `layouts/guest.blade.php` | — |
| 7 | Botón, campos y errores con nuestro estilo | 4 componentes chicos | — |
| 8 | Campo con ícono | `components/auth-field.blade.php` | — |
| 9 | Ingreso y registro | `auth/login.blade.php`, `auth/registro.blade.php` | **PR 1** |
| 10 | Avatar | `components/avatar.blade.php` | Modelos de Miguel (13:00) |
| 11 | Barra de navegación | `components/nav.blade.php` | |
| 12 | Aviso (toast) | `components/toast.blade.php` | |
| 13 | Layout de la app | `layouts/app.blade.php` | Modelos de Miguel (13:00) |
| 14 | «En construcción» con el layout | `pendiente.blade.php` | **PR 2** |

Todas las rutas de vistas parten de `web/resources/views/`.

**Tiempo:** unas 3 h 30 (~560 líneas; los dibujos de los stickers se pueden copiar). Antes de empezar, lee [cómo leer los bloques de código](../README.md#cómo-leer-los-bloques-de-código) y [cómo pasar del mockup a Blade](../README.md#del-mockup-react-a-blade).

Mientras esperas el esqueleto, abre el mockup (`mockup/Mockup de YouCook/src/components/`) y lee `Icons.tsx`, `Stickers.tsx` y `Nav.tsx`: es lo que vas a traducir hoy.

---

## Paso 0 · Clonar y dejar el proyecto andando

Cuando Sebastián avise «Esqueleto en main»:

```bash
git clone <url-del-repo> && cd YouCook/web
composer install
npm install
cp .env.example .env
php artisan key:generate
php artisan migrate          # responde «yes» si pregunta por crear database.sqlite
git switch -c emma/dia1-ingreso
```

Para trabajar, **dos terminales** en `web/`: `php artisan serve` (el sitio, en `http://localhost:8000`) y `npm run dev` (recompila los estilos al guardar). Regístrate en `/registro` para tener una cuenta.

## Paso 1 · Íconos

En el mockup cada ícono es una función de React (`Icons.tsx`). Aquí es **un** componente que recibe el nombre. **Crea:**

📄 **`web/resources/views/components/icon.blade.php`** · 34 líneas

```blade
@props(['name', 'size' => 20, 'filled' => false, 'stroke' => 2])

@php
    // Los mismos íconos del mockup (components/Icons.tsx), por nombre.
    $icons = [
        'search' => '<circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />',
        'bookmark' => '<path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4z" />',
        'clock' => '<circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />',
        'flame' => '<path d="M12 3s5 4.5 5 10a5 5 0 0 1-10 0c0-2.5 1.5-4 1.5-4s.5 2 2 2c0-3 1.5-6 1.5-8z" />',
        'users' => '<circle cx="9" cy="8" r="3.5" /><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6" />',
        'wallet' => '<rect x="3" y="6" width="18" height="14" rx="3" /><path d="M16 13h2M3 10h18M6 6l9-3 1.5 3" />',
        'check' => '<path d="m5 12.5 4.5 4.5L19 7.5" />',
        'sparkle' => '<path d="M12 3c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7zM19 16c.3 1.6 1 2.4 2.5 2.5-1.6.3-2.3 1-2.5 2.5-.3-1.6-1-2.3-2.5-2.5 1.6-.2 2.3-1 2.5-2.5z" />',
        'send' => '<path d="M4 12 20 4l-6 16-3-7z" /><path d="m11 13 9-9" />',
        'alert' => '<path d="M12 3.5 22 20H2z" /><path d="M12 10v4M12 17h.01" />',
        'info' => '<circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" />',
        'arrow-left' => '<path d="M19 12H5M11 6l-6 6 6 6" />',
        'arrow-right' => '<path d="M5 12h14M13 6l6 6-6 6" />',
        'x' => '<path d="M6 6l12 12M18 6 6 18" />',
        'refresh' => '<path d="M20 11a8 8 0 0 0-14.3-4.6L4 8M4 4v4h4M4 13a8 8 0 0 0 14.3 4.6L20 16M20 20v-4h-4" />',
        'lock' => '<rect x="5" y="11" width="14" height="10" rx="2.5" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />',
        'home' => '<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z" />',
        'chat' => '<path d="M20 12a8 8 0 0 1-11.8 7L4 20l1.2-3.8A8 8 0 1 1 20 12z" />',
        'user' => '<circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" />',
        'swap' => '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7" />',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="3" /><path d="m4 7 8 6 8-6" />',
        'eye' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" />',
        'pencil' => '<path d="M4 20h4L19 9l-4-4L4 16z" /><path d="m13.5 6.5 4 4" />',
        'logout' => '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10" />',
        'chevron-down' => '<path d="m6 9 6 6 6-6" />',
    ];
@endphp

<svg {{ $attributes }} width="{{ $size }}" height="{{ $size }}" viewBox="0 0 24 24" fill="{{ $filled ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="{{ $stroke }}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{!! $icons[$name] !!}</svg>
```

**Entiende**
- Un archivo en `resources/views/components/` es un componente: `icon.blade.php` se usa como `<x-icon name="clock" size="15" />`.
- `@props([...])` declara lo que recibe y sus valores por defecto. Lo que **no** está en `@props` (por ejemplo `class="text-tomato-500"`) llega en `$attributes` y se pega en el `<svg>`.
- `{!! ... !!}` imprime sin escapar. Se puede porque el contenido es nuestro (los trazos del SVG). Para cualquier texto que venga de una persona o de la IA se usa siempre `{{ }}`.
- `stroke="currentColor"`: el ícono toma el color del texto. Por eso se pinta con clases `text-…`.
- De React a HTML cambian los nombres de los atributos: `strokeWidth` → `stroke-width`, `strokeLinecap` → `stroke-linecap`, `className` → `class`.

## Paso 2 · Logo

**Crea:**

📄 **`web/resources/views/components/logo.blade.php`** · 11 líneas

```blade
<a href="{{ route('recetas.index') }}" {{ $attributes->class('flex items-center gap-2') }}>
    <span class="grid size-9 place-items-center rounded-xl bg-tomato-500 text-white shadow-[inset_0_-3px_0_rgb(0_0_0/0.15)]">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M5 11h14v3a6 6 0 0 1-6 6h-2a6 6 0 0 1-6-6z" fill="currentColor" fill-opacity=".25" />
            <path d="M3 11h18M9 7c-1-1.5 1-2.5 0-4M14 7c-1-1.5 1-2.5 0-4" />
        </svg>
    </span>
    <span class="font-display text-[22px] font-black tracking-tight">
        You<span class="text-tomato-500">Cook</span>
    </span>
</a>
```

**Entiende**
- `$attributes->class('flex items-center gap-2')` une las clases del componente con las que le pasen: `<x-logo class="mb-10 lg:hidden" />`.
- `route('recetas.index')` escribe la URL de la ruta con ese nombre.

## Paso 3 · Stickers: la carita y los 12 dibujos

Todos los stickers comparten la misma carita. **Crea:**

📄 **`web/resources/views/components/sticker-face.blade.php`** · 12 líneas

```blade
@props(['x' => 50, 'y' => 55, 's' => 1])

{{-- La carita que comparten todos los stickers. --}}
<g transform="translate({{ $x }} {{ $y }}) scale({{ $s }})" stroke="none">
    <circle cx="-8" cy="-2" r="2.8" fill="#2E2B28" />
    <circle cx="8" cy="-2" r="2.8" fill="#2E2B28" />
    <circle cx="-7" cy="-3" r="0.9" fill="#fff" />
    <circle cx="9" cy="-3" r="0.9" fill="#fff" />
    <path d="M-4 4 q4 4 8 0" stroke="#2E2B28" stroke-width="2.4" fill="none" stroke-linecap="round" />
    <ellipse cx="-13" cy="4" rx="3.5" ry="2.2" fill="#FF8C8C" opacity="0.7" />
    <ellipse cx="13" cy="4" rx="3.5" ry="2.2" fill="#FF8C8C" opacity="0.7" />
</g>
```

Cada dibujo es un archivo dentro de `components/stickers/`. **Los trazos (`d="…"`) son dibujo, no código: estos 12 archivos se pueden copiar y pegar.** Lo que tienes que entender es la estructura de uno: un grupo `<g>` con borde oscuro, las formas con su color y la carita encima.

📄 **`web/resources/views/components/stickers/tomate.blade.php`** · 6 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 26c20 0 32 12 32 30S68 86 50 86 18 74 18 56s12-30 32-30z" fill="#E8503A" />
    <path d="M30 44c3-6 9-10 15-11" stroke="#fff" stroke-width="4" stroke-linecap="round" fill="none" opacity="0.6" />
    <path d="M50 30 40 20l8 3 2-9 3 9 8-3-9 10z" fill="#3F8F4E" />
    <x-sticker-face y="60" />
</g>
```

**Entiende**
- `<g stroke="#2E2B28" stroke-width="3">` le pone el borde oscuro a todas las formas de adentro.
- `<x-sticker-face y="60" />` dibuja la carita. `x`, `y` y `s` (tamaño) la mueven según el dibujo.
- Vienen de `Stickers.tsx`: son los mismos trazos, con los atributos escritos como HTML.

<details>
<summary>Los otros 11 dibujos (un archivo cada uno, en <code>components/stickers/</code>)</summary>

📄 **`web/resources/views/components/stickers/huevo.blade.php`** · 6 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M22 50c-6-16 10-30 26-26 10-12 32-4 30 12 12 8 8 30-8 32-6 12-30 14-36 2-14 0-18-12-12-20z" fill="#fff" />
    <circle cx="52" cy="52" r="16" fill="#FFC23D" />
    <path d="M44 44a9 9 0 0 1 8-4" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" />
    <x-sticker-face x="52" y="54" s="0.8" />
</g>
```

📄 **`web/resources/views/components/stickers/huevo2.blade.php`** · 6 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 14c16 0 28 26 28 44S66 88 50 88 22 76 22 58s12-44 28-44z" fill="#FFF3DD" />
    <path d="M24 50l8-6 7 6 7-7 8 7 7-6 8 6 7-4" fill="none" />
    <circle cx="74" cy="24" r="9" fill="#FFC23D" />
    <x-sticker-face y="66" s="0.9" />
</g>
```

📄 **`web/resources/views/components/stickers/tallarin.blade.php`** · 8 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
    <path d="M30 40c4-14 10-4 14-16M48 38c2-14 10-8 10-22M62 40c6-10 10-6 12-16" fill="none" stroke="#E8A93A" stroke-width="5" />
    <path d="M30 40c4-14 10-4 14-16M48 38c2-14 10-8 10-22M62 40c6-10 10-6 12-16" fill="none" stroke-width="1.5" opacity="0.5" />
    <path d="M14 44h72c0 22-16 38-36 38S14 66 14 44z" fill="#FFB020" />
    <path d="M14 44h72" />
    <ellipse cx="50" cy="44" rx="36" ry="6" fill="#E8503A" />
    <x-sticker-face y="64" />
</g>
```

📄 **`web/resources/views/components/stickers/panqueque.blade.php`** · 9 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <ellipse cx="50" cy="78" rx="34" ry="8" fill="#fff" />
    <rect x="20" y="58" width="60" height="14" rx="7" fill="#F2B26B" />
    <rect x="22" y="46" width="56" height="14" rx="7" fill="#F6C27E" />
    <rect x="24" y="34" width="52" height="14" rx="7" fill="#F2B26B" />
    <path d="M28 36c6-6 38-6 44 0 0 6-4 4-5 10-1 4-5 4-5 0 0-4-6-4-8 0-2 6-6 6-6 0 0-4-8-2-10 2-2 3-6 2-5-3 1-4-5-4-5-9z" fill="#8A4B1E" />
    <rect x="44" y="22" width="12" height="9" rx="2" fill="#FFE9A8" />
    <x-sticker-face y="62" s="0.85" />
</g>
```

📄 **`web/resources/views/components/stickers/palta.blade.php`** · 6 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 12c14 0 18 18 24 30 8 16 4 44-24 44S18 58 26 42c6-12 10-30 24-30z" fill="#3F8F4E" />
    <path d="M50 20c10 0 13 14 18 24 6 13 3 34-18 34S26 57 32 44c5-10 8-24 18-24z" fill="#CDE69A" />
    <circle cx="50" cy="58" r="11" fill="#9A5A2C" />
    <x-sticker-face y="42" s="0.75" />
</g>
```

📄 **`web/resources/views/components/stickers/pan.blade.php`** · 5 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
    <path d="M14 58c0-18 16-28 36-28s36 10 36 28c0 12-10 18-36 18S14 70 14 58z" fill="#E7A35B" />
    <path d="M34 36c4 6 4 12 0 18M50 32v22M66 36c-4 6-4 12 0 18" fill="none" stroke="#B86E2C" />
    <x-sticker-face y="64" s="0.85" />
</g>
```

📄 **`web/resources/views/components/stickers/olla.blade.php`** · 8 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
    <path d="M34 26c-4-6 4-8 0-14M50 24c-4-6 4-8 0-14M66 26c-4-6 4-8 0-14" fill="none" opacity="0.5" />
    <path d="M10 46h10M80 46h10" />
    <path d="M20 40h60v26c0 10-8 18-18 18H38c-10 0-18-8-18-18z" fill="#E8503A" />
    <rect x="16" y="34" width="68" height="10" rx="5" fill="#FF7A5C" />
    <rect x="44" y="28" width="12" height="6" rx="3" fill="#2E2B28" />
    <x-sticker-face y="64" />
</g>
```

📄 **`web/resources/views/components/stickers/olla2.blade.php`** · 7 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
    <path d="M38 24l3-8 3 8-8-3 8-1zM60 18l2-6 2 6-6-2 6-1z" fill="#FFC23D" />
    <path d="M10 46h10M80 46h10" />
    <path d="M20 40h60v26c0 10-8 18-18 18H38c-10 0-18-8-18-18z" fill="#7C6CD8" />
    <rect x="16" y="34" width="68" height="10" rx="5" fill="#A99CF0" />
    <x-sticker-face y="64" />
</g>
```

📄 **`web/resources/views/components/stickers/choclo.blade.php`** · 6 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 12c12 0 16 18 16 36S62 84 50 84 34 66 34 48s4-36 16-36z" fill="#FFD233" />
    <path d="M40 30h20M37 42h26M36 54h28M38 66h24M50 14v68" fill="none" stroke="#E0A800" stroke-width="2" />
    <path d="M34 50C22 56 20 74 32 88c6-4 14-10 18-4-6-10-10-24-16-34zM66 50c12 6 14 24 2 38-6-4-14-10-18-4 6-10 10-24 16-34z" fill="#3F8F4E" />
    <x-sticker-face y="46" s="0.75" />
</g>
```

📄 **`web/resources/views/components/stickers/zapallo.blade.php`** · 7 líneas

```blade
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 18c-2-6 4-8 8-6" fill="none" stroke="#3F8F4E" stroke-width="4" stroke-linecap="round" />
    <ellipse cx="34" cy="56" rx="18" ry="26" fill="#F28A2E" />
    <ellipse cx="66" cy="56" rx="18" ry="26" fill="#F28A2E" />
    <ellipse cx="50" cy="56" rx="16" ry="28" fill="#FF9F43" />
    <x-sticker-face y="60" s="0.9" />
</g>
```

📄 **`web/resources/views/components/stickers/estrella.blade.php`** · 6 líneas

```blade
{{-- Sticker genérico: lo usan las recetas que todavía no tienen dibujo propio. --}}
<g stroke="#2E2B28" stroke-width="3" stroke-linejoin="round">
    <path d="M50 12l11 23 25 3-18 18 5 25-23-12-23 12 5-25-18-18 25-3z" fill="#FFC23D" />
    <path d="M36 40c2-4 5-7 9-8" stroke="#fff" stroke-width="4" stroke-linecap="round" fill="none" opacity="0.6" />
    <x-sticker-face y="54" s="0.8" />
</g>
```

</details>

`estrella` no está en el mockup: es el sticker de las 9 recetas que todavía no tienen dibujo propio (en el mockup esas mostraban un «?» incluso desbloqueadas).

## Paso 4 · El sticker con borde blanco

**Crea:**

📄 **`web/resources/views/components/sticker.blade.php`** · 31 líneas

```blade
@props(['kind', 'size' => 88, 'locked' => false, 'rotate' => 0])

@php
    // Cada dibujo es un archivo en components/stickers/. Para agregar un
    // sticker nuevo basta con crear su archivo: no hay que tocar este.
    $exists = view()->exists('components.stickers.'.$kind);
    $filter = 'cut-'.Str::random(8);
@endphp

@if ($locked || ! $exists)
    {{-- Bloqueado: círculo punteado con un signo de pregunta. --}}
    <svg width="{{ $size }}" height="{{ $size }}" viewBox="0 0 100 100" aria-hidden="true">
        <circle cx="50" cy="50" r="38" fill="#F3E7D4" stroke="#D9C5A6" stroke-width="3" stroke-dasharray="6 6" />
        <text x="50" y="62" text-anchor="middle" font-family="Nunito" font-weight="900" font-size="34" fill="#C9B394">?</text>
    </svg>
@else
    {{-- El filtro dibuja el borde blanco de «sticker recortado». --}}
    <svg width="{{ $size }}" height="{{ $size }}" viewBox="0 0 100 100" style="transform: rotate({{ $rotate }}deg); filter: drop-shadow(0 4px 6px rgb(46 43 40 / .18))" aria-hidden="true">
        <defs>
            <filter id="{{ $filter }}" x="-20%" y="-20%" width="140%" height="140%">
                <feMorphology in="SourceAlpha" operator="dilate" radius="5" result="d" />
                <feFlood flood-color="#fff" />
                <feComposite in2="d" operator="in" result="o" />
                <feMerge><feMergeNode in="o" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
        </defs>
        <g filter="url(#{{ $filter }})">
            <x-dynamic-component :component="'stickers.'.$kind" />
        </g>
    </svg>
@endif
```

**Entiende**
- `view()->exists(...)` pregunta si existe el archivo del dibujo. Si no existe (o si el sticker está bloqueado) se dibuja el círculo punteado con «?».
- `<x-dynamic-component :component="'stickers.'.$kind" />` incluye el componente cuyo nombre se arma en ese momento: `stickers.tomate`, `stickers.palta`…
- **Para agregar un sticker nuevo basta con crear su archivo** en `components/stickers/`: no hay que tocar nada más.
- El `<filter>` es el truco del borde blanco de «sticker recortado»: engorda la silueta 5 px, la pinta blanca y dibuja el original encima. Cada sticker necesita un `id` distinto para su filtro: por eso `Str::random(8)`.

## Paso 5 · Mirar íconos y stickers

Crea `resources/views/muestra.blade.php` (está en `.gitignore`: **no se sube**) y abre `http://localhost:8000/muestra`:

📄 **`web/resources/views/muestra.blade.php`** · 39 líneas · **versión provisional**

```blade
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Muestra · YouCook</title>

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="space-y-8 p-8">
        <x-logo />

        <section>
            <h2 class="text-2xl font-black">Íconos</h2>
            <div class="mt-3 flex flex-wrap gap-4 text-tomato-600">
                @foreach (['search', 'bookmark', 'clock', 'flame', 'users', 'wallet', 'check', 'sparkle', 'send', 'alert', 'info', 'arrow-left', 'arrow-right', 'x', 'refresh', 'lock', 'home', 'chat', 'user', 'swap', 'mail', 'eye', 'pencil', 'logout'] as $nombre)
                    <span class="flex flex-col items-center gap-1 text-xs text-charcoal-soft">
                        <x-icon :name="$nombre" size="24" class="text-tomato-600" /> {{ $nombre }}
                    </span>
                @endforeach
                <x-icon name="bookmark" size="24" filled />
            </div>
        </section>

        <section>
            <h2 class="text-2xl font-black">Stickers</h2>
            <div class="mt-3 flex flex-wrap gap-4">
                @foreach (['tomate', 'huevo', 'huevo2', 'tallarin', 'panqueque', 'palta', 'pan', 'olla', 'olla2', 'choclo', 'zapallo', 'estrella'] as $i => $tipo)
                    <span class="flex flex-col items-center gap-1 text-xs text-charcoal-soft">
                        <x-sticker :kind="$tipo" :rotate="$i % 2 ? 6 : -6" /> {{ $tipo }}
                    </span>
                @endforeach
                <x-sticker kind="tomate" locked />
                <x-sticker kind="no-existe" />
            </div>
        </section>
    </body>
</html>
```

- [ ] Se ven los 24 íconos, el marcador relleno y el logo.
- [ ] Se ven los 12 stickers con borde blanco y carita, y dos «?» (el bloqueado y el que no existe).
- [ ] Compara con el mockup: en `mockup/Mockup de YouCook/` ejecuta `npm install && npm run dev` y ábrelo en el navegador, o usa el enlace de Figma.

## Paso 6 · Layout de ingreso

En el mockup, registro e ingreso son la misma pantalla (`screens/Auth.tsx`): una foto a la izquierda y el formulario a la derecha. Eso es un **layout**: el marco que comparten varias páginas. **Crea:**

📄 **`web/resources/views/layouts/guest.blade.php`** · parte 1 de 2 (líneas 1–34) · empieza el archivo

```blade
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('titulo') · {{ config('app.name') }}</title>
        <link rel="icon" href="/favicon.png" type="image/png">

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body>
        <div class="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
            {{-- --- Mitad izquierda: foto y frase (solo en pantallas grandes) --- --}}
            <aside class="relative hidden overflow-hidden lg:block">
                <img
                    src="https://images.unsplash.com/photo-1653233797467-1a528819fd4f?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=1400"
                    alt="Persona picando verduras en una tabla"
                    class="absolute inset-0 size-full object-cover"
                >
                <div class="absolute inset-0 bg-gradient-to-t from-[#2E2B28]/85 via-[#2E2B28]/25 to-transparent"></div>
                <div class="absolute top-10 left-10 rounded-2xl bg-cream px-4 py-3"><x-logo /></div>
                <div class="absolute right-12 bottom-12 left-12 text-white">
                    <div class="mb-6 flex gap-2">
                        <x-sticker kind="huevo" size="76" rotate="-8" />
                        <x-sticker kind="tallarin" size="76" rotate="6" />
                        <x-sticker kind="palta" size="76" rotate="-4" />
                    </div>
                    <h2 class="max-w-md text-[44px] leading-[1.05] font-black">Cocina rico con lo que tienes en el refri.</h2>
                    <p class="mt-4 max-w-md text-lg text-white/85">Recetas simples, alternativas para ingredientes que te faltan y un asistente que responde en segundos.</p>
                </div>
            </aside>
```

📄 **`web/resources/views/layouts/guest.blade.php`** · parte 2 de 2 (líneas 36–45) · sigue debajo de la parte anterior

```blade
            {{-- --- Mitad derecha: el formulario de cada página --- --}}
            <main class="flex items-center justify-center px-6 py-12 sm:px-12">
                <div class="w-full max-w-[420px]">
                    <x-logo class="mb-10 lg:hidden" />
                    @yield('contenido')
                </div>
            </main>
        </div>
    </body>
</html>
```

**Entiende**
- Es un layout como el de la clase 9: el HTML que se repite, con huecos. `@yield('contenido')` es el hueco del formulario y `@yield('titulo')` el del título de la pestaña. Cada página dice `@extends('layouts.guest')` y llena los huecos con `@section`.
- `@vite(...)` carga nuestro CSS y JavaScript. `@fonts` carga Nunito e Inter. Las dos líneas van en el `<head>` de todo layout.
- `hidden lg:block`: oculto en teléfonos y visible desde 1024 px. Al revés, `lg:hidden` es «solo en pantallas chicas». Tailwind parte del teléfono y los prefijos (`sm:`, `md:`, `lg:`) agregan cambios para pantallas más grandes.
- `<x-logo />` y `<x-sticker />` son tus componentes de los pasos 2 y 4.
- La etiqueta `<meta name="csrf-token">` la usa el JavaScript de Sebastián.

## Paso 7 · Botón, campos y errores con nuestro estilo

Cuatro componentes chicos que usan el ingreso, el registro y (el domingo) el perfil. **Crea** cada uno:

📄 **`web/resources/views/components/primary-button.blade.php`** · 3 líneas

```blade
<button {{ $attributes->merge(['type' => 'submit', 'class' => 'h-13 w-full rounded-2xl bg-tomato-500 px-6 font-display text-[17px] font-extrabold text-white shadow-[inset_0_-4px_0_rgb(0_0_0/0.14)] transition hover:bg-tomato-600 active:translate-y-px']) }}>
    {{ $slot }}
</button>
```

📄 **`web/resources/views/components/text-input.blade.php`** · 3 líneas

```blade
@props(['disabled' => false])

<input @disabled($disabled) {{ $attributes->merge(['class' => 'h-13 rounded-2xl border-2 border-cream-300 bg-white px-4 text-[15px] outline-none transition placeholder:text-[#B3A99D] focus:border-tomato-500 focus:ring-4 focus:ring-tomato-100']) }}>
```

📄 **`web/resources/views/components/input-label.blade.php`** · 5 líneas

```blade
@props(['value'])

<label {{ $attributes->merge(['class' => 'mb-2 block text-sm font-semibold']) }}>
    {{ $value ?? $slot }}
</label>
```

📄 **`web/resources/views/components/input-error.blade.php`** · 9 líneas

```blade
@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'space-y-1 text-sm font-medium text-tomato-600']) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>
@endif
```

**Entiende**
- `$attributes->merge([...])` pone valores por defecto (`type="submit"`, las clases) que quien use el componente puede ampliar.
- `{{ $slot }}` es lo que va entre la etiqueta de apertura y la de cierre: en `<x-primary-button>Iniciar sesión</x-primary-button>`, el texto del botón.
- `input-error` recibe la lista de mensajes de un campo (`$errors->get('email')`) y dibuja uno por línea. Si no hay errores, no dibuja nada.
- `shadow-[inset_0_-4px_0_rgb(0_0_0/0.14)]` es una clase con un valor a la medida entre corchetes: la sombra interior que le da volumen al botón del mockup.

## Paso 8 · Campo con ícono

En el mockup es `Field` (dentro de `Auth.tsx`). **Crea:**

📄 **`web/resources/views/components/auth-field.blade.php`** · 29 líneas

```blade
@props(['label', 'name', 'icon', 'type' => 'text', 'hint' => null])

{{-- Campo de los formularios de ingreso: ícono, input y, en las contraseñas, el ojo para verla. --}}
<label class="block" x-data="{ ver: false }">
    <span class="mb-2 block text-sm font-semibold">{{ $label }}</span>
    <span class="flex h-13 items-center gap-3 rounded-2xl border-2 bg-white px-4 transition focus-within:border-tomato-500 focus-within:ring-4 focus-within:ring-tomato-100 {{ $errors->has($name) ? 'border-tomato-500' : 'border-cream-300' }}">
        <x-icon :name="$icon" size="19" class="text-charcoal-soft" />
        <input
            name="{{ $name }}"
            @if ($type === 'password')
                :type="ver ? 'text' : 'password'"
            @else
                type="{{ $type }}"
                value="{{ old($name) }}"
            @endif
            required
            {{ $attributes->class('h-12 w-full bg-transparent text-[15px] outline-none placeholder:text-[#B3A99D]') }}
        >
        @if ($type === 'password')
            <button type="button" x-on:click="ver = ! ver" class="text-charcoal-soft hover:text-charcoal" aria-label="Mostrar contraseña">
                <x-icon name="eye" size="19" />
            </button>
        @endif
    </span>
    @if ($hint && ! $errors->has($name))
        <span class="mt-1.5 block text-xs text-charcoal-soft">{{ $hint }}</span>
    @endif
    <x-input-error :messages="$errors->get($name)" class="mt-1.5" />
</label>
```

**Entiende**
- `x-data="{ ver: false }"` es **Alpine**: crea un dato para este campo. El botón del ojo lo cambia (`x-on:click="ver = ! ver"`) y el campo reacciona (`:type="ver ? 'text' : 'password'"`). Es lo que en React era `useState`.
- `old($name)` recupera lo que la persona escribió si el formulario volvió con errores (las contraseñas nunca se devuelven).
- `$errors->has($name)` y `$errors->get($name)`: los errores de validación que Laravel deja disponibles en todas las vistas. Si hay error, el borde queda rojo y el mensaje aparece abajo.
- `focus-within:` aplica el estilo al contenedor cuando el campo de adentro tiene el foco.

## Paso 9 · Ingreso y registro

**Reemplaza todo** en los dos (son las versiones provisionales de Sebastián):

📄 **`web/resources/views/auth/login.blade.php`** · 26 líneas

```blade
@extends('layouts.guest')

@section('titulo', 'Iniciar sesión')

@section('contenido')
    <h1 class="text-[34px] leading-tight font-black">¡Hola de nuevo!</h1>
    <p class="mt-2 text-charcoal-soft">Ingresa para ver tus recetas guardadas.</p>

    <form method="POST" action="{{ route('login') }}" class="mt-8 space-y-5">
        @csrf

        <x-auth-field label="Correo" type="email" name="email" icon="mail" placeholder="camila@uni.cl" autofocus autocomplete="username" />
        <x-auth-field label="Contraseña" type="password" name="password" icon="lock" placeholder="••••••••" autocomplete="current-password" />

        <label class="flex items-center gap-2 text-sm">
            <input type="checkbox" name="remember" class="size-4 accent-tomato-500"> Recordarme
        </label>

        <x-primary-button>Iniciar sesión</x-primary-button>
    </form>

    <p class="mt-8 text-center text-[15px] text-charcoal-soft">
        ¿Primera vez en YouCook?
        <a href="{{ route('registro') }}" class="font-bold text-tomato-600 hover:underline">Regístrate gratis</a>
    </p>
@endsection
```

📄 **`web/resources/views/auth/registro.blade.php`** · 23 líneas

```blade
@extends('layouts.guest')

@section('titulo', 'Crear cuenta')

@section('contenido')
    <h1 class="text-[34px] leading-tight font-black">Crea tu cuenta</h1>
    <p class="mt-2 text-charcoal-soft">Guarda recetas, colecciona stickers y pregúntale todo al asistente.</p>

    <form method="POST" action="{{ route('registro') }}" class="mt-8 space-y-5">
        @csrf

        <x-auth-field label="Nombre" name="name" icon="user" placeholder="Camila Rojas" autofocus autocomplete="name" />
        <x-auth-field label="Correo" type="email" name="email" icon="mail" placeholder="camila@uni.cl" autocomplete="username" />
        <x-auth-field label="Contraseña" type="password" name="password" icon="lock" placeholder="••••••••" hint="Mínimo 8 caracteres." autocomplete="new-password" />

        <x-primary-button>Crear cuenta</x-primary-button>
    </form>

    <p class="mt-8 text-center text-[15px] text-charcoal-soft">
        ¿Ya tienes cuenta?
        <a href="{{ route('login') }}" class="font-bold text-tomato-600 hover:underline">Inicia sesión</a>
    </p>
@endsection
```

**Entiende**
- `@extends('layouts.guest')` usa tu layout del paso 6. `@section('titulo', 'Iniciar sesión')` llena el hueco del título en una línea; `@section('contenido') ... @endsection` llena el del formulario.
- `action="{{ route('login') }}"` y `route('registro')`: las rutas que Sebastián escribió en `routes/auth.php`. El controlador que los recibe (`AuthController`) ya existe.
- `@csrf` es obligatorio en todo formulario `POST`: sin él, Laravel responde 419.
- Los `name` de los campos (`name`, `email`, `password`, `remember`) son los que lee `AuthController`: no se pueden cambiar.
- `autofocus` y `autocomplete="…"` no están en `@props` de `auth-field`, así que llegan al `<input>` por `$attributes`.
- El mockup tenía «¿Olvidaste tu contraseña?». No lo ponemos: recuperar la contraseña necesita enviar correos, y eso no está en el alcance.

Revisa en el navegador (cierra sesión primero) y sube el **PR 1**:

- [ ] `/login` y `/registro` se ven como el mockup, también en ancho de teléfono (ahí desaparece la foto y aparece el logo).
- [ ] El ojo muestra y oculta la contraseña.
- [ ] Una contraseña incorrecta muestra el error bajo el correo, y el correo escrito se conserva.

```bash
php artisan test
git add . && git commit -m "Íconos, stickers, ingreso y registro"
git push -u origin emma/dia1-ingreso
```

---

## Tarde: la barra de navegación

Necesitas en `main` el PR 1 de Miguel (los modelos, ~13:00): el layout cuenta las recetas guardadas y cocinadas con sus relaciones. Rama nueva:

```bash
git switch main && git pull && php artisan migrate
git switch -c emma/dia1-layout
```

## Paso 10 · Avatar

**Crea:**

📄 **`web/resources/views/components/avatar.blade.php`** · 9 líneas

```blade
@props(['size' => 40])

{{-- Círculo con la inicial de quien inició sesión. --}}
<span
    {{ $attributes->class('grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-[#FFC23D] to-tomato-500 font-display font-black text-white ring-2 ring-white') }}
    style="width: {{ $size }}px; height: {{ $size }}px; font-size: {{ $size * 0.4 }}px"
>
    {{ auth()->user()->initial }}
</span>
```

**Entiende**
- `auth()->user()` es la persona que inició sesión. `initial` es un atributo que Miguel agregó al modelo `User` («Camila Rojas» → «C»).
- `style="…"` se usa aquí porque el tamaño es un número cualquiera que llega por `size`; Tailwind solo sirve para clases escritas de antemano.

## Paso 11 · Barra de navegación

En el mockup: `Nav.tsx`. Arriba, la barra con el logo, los tres enlaces y el perfil; abajo, solo en el teléfono, la barra de cuatro íconos. **Crea:**

📄 **`web/resources/views/components/nav.blade.php`** · parte 1 de 2 (líneas 1–50) · empieza el archivo

```blade
@props(['user', 'saved' => 0, 'cooked' => 0, 'total' => 20])

@php
    $links = [
        ['route' => 'recetas.index', 'match' => 'recetas.*', 'label' => 'Recetas', 'icon' => 'home'],
        ['route' => 'guardados.index', 'match' => 'guardados.*', 'label' => 'Guardados', 'icon' => 'bookmark'],
        ['route' => 'asistente.show', 'match' => 'asistente.*', 'label' => 'Asistente', 'icon' => 'chat'],
    ];
    $enPerfil = request()->routeIs('perfil.*');
@endphp

{{-- --- Barra superior --- --}}
<header class="fixed inset-x-0 top-0 z-40 border-b border-cream-300/70 bg-cream/85 backdrop-blur-md">
    <nav class="mx-auto flex h-[72px] max-w-[1280px] items-center gap-8 px-5 md:px-10">
        <x-logo />

        <ul class="ml-4 hidden items-center gap-1 md:flex">
            @foreach ($links as $link)
                @php $activo = request()->routeIs($link['match']); @endphp
                <li>
                    <a
                        href="{{ route($link['route']) }}"
                        @if ($activo) aria-current="page" @endif
                        class="relative flex items-center gap-2 rounded-full px-4 py-2 font-display text-[15px] font-bold transition {{ $activo ? 'bg-tomato-50 text-tomato-600' : 'text-charcoal-soft hover:bg-cream-200 hover:text-charcoal' }}"
                    >
                        {{ $link['label'] }}
                        @if ($link['icon'] === 'bookmark' && $saved > 0)
                            <span class="grid h-5 min-w-5 place-items-center rounded-full bg-tomato-500 px-1.5 text-[11px] font-bold text-white">{{ $saved }}</span>
                        @endif
                        @if ($link['icon'] === 'chat')
                            <span class="rounded-full bg-basil-100 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-basil-600">IA</span>
                        @endif
                    </a>
                </li>
            @endforeach
        </ul>

        <a
            href="{{ route('perfil.show') }}"
            class="ml-auto flex items-center gap-3 rounded-full p-1 pr-1 transition md:pr-4 {{ $enPerfil ? 'bg-tomato-50' : 'hover:bg-cream-200' }}"
            aria-label="Perfil"
        >
            <x-avatar />
            <span class="hidden text-left leading-tight md:block">
                <span class="block font-display text-sm font-bold">{{ $user->short_name }}</span>
                <span class="block text-xs text-charcoal-soft">{{ $cooked }} de {{ $total }} recetas</span>
            </span>
        </a>
    </nav>
</header>
```

**Entiende**
- `$links` es la lista de enlaces, igual que `const links` del mockup.
- `request()->routeIs('recetas.*')` es verdadero en cualquier ruta cuyo nombre empiece con `recetas.` (catálogo y detalle). Con eso se marca el enlace activo.
- `{{ $activo ? 'clases A' : 'clases B' }}` elige clases según una condición. Es lo que en React se escribía con `${ ... ? ... : ... }`.
- `$saved`, `$cooked` y `$total` llegan desde el layout, que los cuenta con los modelos de Miguel.

📄 **`web/resources/views/components/nav.blade.php`** · parte 2 de 2 (líneas 52–63) · sigue debajo de la parte anterior

```blade
{{-- --- Barra inferior (solo en el teléfono) --- --}}
<nav class="fixed inset-x-0 bottom-0 z-40 grid grid-cols-4 border-t border-cream-300 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
    @foreach ([...$links, ['route' => 'perfil.show', 'match' => 'perfil.*', 'label' => 'Perfil', 'icon' => 'user']] as $link)
        <a
            href="{{ route($link['route']) }}"
            class="flex flex-col items-center gap-1 py-2.5 text-[11px] font-semibold {{ request()->routeIs($link['match']) ? 'text-tomato-600' : 'text-charcoal-soft' }}"
        >
            <x-icon :name="$link['icon']" size="22" />
            {{ $link['label'] }}
        </a>
    @endforeach
</nav>
```

**Entiende**
- `md:hidden`: la barra de abajo solo existe en pantallas chicas. La lista de arriba es `hidden md:flex`: lo contrario.
- `[...$links, [...]]` copia la lista y le agrega «Perfil» al final.
- `pb-[env(safe-area-inset-bottom)]` deja espacio para la barra de gestos de los teléfonos.

## Paso 12 · Aviso (toast)

En el mockup: `Toast` en `App.tsx`. **Crea:**

📄 **`web/resources/views/components/toast.blade.php`** · 21 líneas

```blade
@props(['toast'])

{{-- Aviso que aparece abajo y se va solo a los 3,8 segundos. --}}
<div
    x-data="{ visible: true }"
    x-init="setTimeout(() => visible = false, 3800)"
    x-show="visible"
    x-transition.opacity
    role="status"
    class="rise fixed bottom-24 left-1/2 z-50 flex w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 items-center gap-4 rounded-3xl bg-charcoal p-4 pr-6 text-white shadow-lift md:bottom-8"
>
    @isset($toast['sticker'])
        <div class="pop"><x-sticker :kind="$toast['sticker']" size="64" rotate="-8" /></div>
    @endisset
    <div>
        <p class="font-display text-lg font-black">{{ $toast['title'] }}</p>
        @isset($toast['body'])
            <p class="text-sm text-white/75">{{ $toast['body'] }}</p>
        @endisset
    </div>
</div>
```

**Entiende**
- Recibe un arreglo con `title` y, si los hay, `body` y `sticker`. Lo arma el controlador de Miguel cuando se marca una receta como cocinada.
- `x-init` se ejecuta al aparecer: programa que `visible` pase a `false` a los 3,8 segundos (el mismo tiempo del mockup). `x-show` lo oculta y `x-transition.opacity` lo desvanece.
- `@isset($toast['sticker'])`: el sticker se dibuja solo si viene.

## Paso 13 · Layout de la app

**Crea:**

📄 **`web/resources/views/layouts/app.blade.php`** · 31 líneas

```blade
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('titulo') · {{ config('app.name') }}</title>
        <link rel="icon" href="/favicon.png" type="image/png">

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body>
        {{-- Los números de la barra se cuentan aquí: este layout lo usan todas las páginas con sesión. --}}
        <x-nav
            :user="auth()->user()"
            :saved="auth()->user()->savedRecipes()->count()"
            :cooked="auth()->user()->cookedRecipes()->count()"
            :total="\App\Models\Recipe::count()"
        />

        <main class="mx-auto max-w-[1280px] px-5 pt-[96px] pb-28 md:px-10 md:pt-[104px] md:pb-16">
            @yield('contenido')
        </main>

        @if (session('toast'))
            <x-toast :toast="session('toast')" />
        @endif
    </body>
</html>
```

**Entiende**
- Es el marco de todas las páginas con sesión: barra, contenido (`@yield('contenido')`) y aviso. Cada pantalla empieza con `@extends('layouts.app')`, igual que el layout de la clase 9.
- `auth()->user()` es la persona con la sesión iniciada. `auth()->user()->savedRecipes()->count()` cuenta sus recetas guardadas con la relación que Miguel escribió en `User`: son tres consultas `count()` por página, y para una app de este tamaño está bien.
- `:user="..."` (con dos puntos) pasa una **variable de PHP** al componente. Sin los dos puntos (`kind="tomate"`) se pasa un texto.
- `pt-[96px]` deja libre el alto de la barra de arriba, que es fija; `pb-28` hace lo mismo con la de abajo en el teléfono.
- `session('toast')` lee el aviso que el controlador dejó para **esta** carga de página. Al recargar, ya no está.

## Paso 14 · «En construcción» con el layout

Para ver tu barra en todas las rutas provisionales, **reemplaza todo:**

📄 **`web/resources/views/pendiente.blade.php`** · 16 líneas · **versión provisional**

```blade
@extends('layouts.app')

@section('titulo', 'En construcción')

@section('contenido')
    <div class="mx-auto max-w-md rounded-3xl bg-white p-8 text-center shadow-soft">
        <div class="mx-auto w-fit"><x-sticker kind="olla" size="96" /></div>
        <h1 class="mt-4 text-3xl font-black">En construcción</h1>
        <p class="mt-2 text-charcoal-soft">Esta pantalla todavía no existe: <code>/{{ request()->path() }}</code></p>

        <form method="POST" action="{{ route('logout') }}" class="mt-6">
            @csrf
            <button class="text-sm font-semibold text-charcoal-soft underline">Cerrar sesión</button>
        </form>
    </div>
@endsection
```

- [ ] Con sesión iniciada, cualquier página muestra la barra: logo, tres enlaces (con «IA» en Asistente) y tu nombre corto con «0 de 20 recetas» (o «0 de 0» si los seeders de Miguel aún no están integrados).
- [ ] El enlace de la página actual queda marcado.
- [ ] En ancho de teléfono desaparecen los enlaces de arriba y aparece la barra de abajo.

## Cierre del día

```bash
npm run build && php artisan test
git add -A && git commit -m "Barra de navegación, aviso y layout"
git push -u origin emma/dia1-layout
```

- [ ] Dos PR abiertos (ingreso y layout). Sebastián los integra.
- [ ] Check-in de las 21:00.
