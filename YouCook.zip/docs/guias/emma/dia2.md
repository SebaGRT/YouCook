<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Emma · Día 2 (sábado 14): catálogo y detalle de receta

**Meta del día:** las dos pantallas principales, iguales al mockup y con datos reales: el catálogo (buscador, filtros, tarjetas y paginación) y el detalle de receta.

← [Día 1](dia1.md) · [Índice de guías](../README.md) · Siguiente: [Día 3](dia3.md)

## Mapa del día

| Paso | Qué haces | Archivo | Depende de |
|---|---|---|---|
| 1 | Dificultad | `components/difficulty.blade.php` | — |
| 2 | Foto de la receta | `components/recipe-photo.blade.php` | — |
| 3 | Botón de guardar | `components/bookmark-button.blade.php` | — |
| 4 | Tarjeta de receta | `components/recipe-card.blade.php` | — |
| 5 | Selector de los filtros | `components/select.blade.php` | — |
| 6 | Paginación | `pagination/youcook.blade.php` | — |
| 7 | Catálogo | `recetas/index.blade.php` | Catálogo provisional de Miguel (viernes) · **PR 1** |
| 8 | Detalle de receta | `recetas/show.blade.php` | **`<x-ingredient-row>` de Sebastián (12:00)** · **PR 2** |

**Tiempo:** unas 3 h 30 (~470 líneas).

Rama: `git switch main && git pull && composer install && npm install && php artisan migrate:fresh --seed && git switch -c emma/dia2-catalogo`. Entra con `camila.rojas@uni.cl` / `password`: es la cuenta del mockup.

Las vistas `recetas/index.blade.php` y `recetas/show.blade.php` ya existen: son las **provisionales** de Miguel. Ábrelas antes de empezar: muestran qué variables entrega cada controlador. Hoy las reemplazas.

---

## Paso 1 · Dificultad

En el mockup: `DifficultyPill` en `RecipeCard.tsx`. **Crea:**

📄 **`web/resources/views/components/difficulty.blade.php`** · 6 líneas

```blade
@props(['level'])

<span class="inline-flex items-center gap-1">
    <x-icon name="flame" size="15" class="{{ $level === 'Fácil' ? 'text-basil-500' : 'text-[#E39A1B]' }}" />
    {{ $level }}
</span>
```

## Paso 2 · Foto de la receta

**Crea:**

📄 **`web/resources/views/components/recipe-photo.blade.php`** · 10 líneas

```blade
@props(['recipe', 'sticker' => 120])

{{-- La foto de la receta. Si todavía no tiene, se muestra su sticker sobre un fondo crema. --}}
@if ($recipe->image)
    <img src="{{ $recipe->image }}" alt="{{ $recipe->title }}" {{ $attributes }}>
@else
    <div {{ $attributes->class('grid place-items-center bg-cream-200') }}>
        <x-sticker :kind="$recipe->sticker" :size="$sticker" />
    </div>
@endif
```

**Entiende**
- Las 8 recetas del mockup tienen foto. Las otras 12 todavía no: en su lugar se dibuja su sticker sobre fondo crema, y la tarjeta se ve completa igual.
- Las clases que se le pasen (`class="size-full object-cover"`) van a la `<img>` o al `<div>`, según el caso.

## Paso 3 · Botón de guardar

En el mockup: `BookmarkButton`. Allá cambiaba una lista en la memoria; aquí es un **formulario**, porque guardar es un cambio en la base de datos. **Crea:**

📄 **`web/resources/views/components/bookmark-button.blade.php`** · 14 líneas

```blade
@props(['recipe', 'saved' => false, 'size' => 'size-10'])

{{-- Guardar o quitar de guardados. Es un formulario: el cambio lo hace el servidor. --}}
<form method="POST" action="{{ route('recetas.guardar', $recipe) }}" {{ $attributes }}>
    @csrf
    <button
        type="submit"
        aria-pressed="{{ $saved ? 'true' : 'false' }}"
        aria-label="{{ $saved ? 'Quitar de guardados' : 'Guardar receta' }}"
        class="grid {{ $size }} place-items-center rounded-full shadow-soft transition active:scale-90 {{ $saved ? 'bg-tomato-500 text-white' : 'bg-white/95 text-charcoal hover:text-tomato-500' }}"
    >
        <x-icon name="bookmark" size="18" :filled="$saved" />
    </button>
</form>
```

**Entiende**
- Al tocar el botón, el navegador envía un `POST` a `/recetas/charquican/guardar`. El controlador de Miguel guarda (o quita) y devuelve a la misma página, que se dibuja de nuevo con el botón en su otro estado.
- `route('recetas.guardar', $recipe)`: al pasarle la receta, Laravel pone su slug en la URL.
- `aria-pressed` y `aria-label` le dicen a un lector de pantalla si está guardada y qué hace el botón.

## Paso 4 · Tarjeta de receta

En el mockup: `RecipeCard`. **Crea:**

📄 **`web/resources/views/components/recipe-card.blade.php`** · 26 líneas

```blade
@props(['recipe', 'saved' => false, 'cooked' => false])

<article id="receta-{{ $recipe->slug }}" class="group relative flex scroll-mt-24 flex-col overflow-hidden rounded-3xl bg-white shadow-soft transition duration-300 hover:-translate-y-1 hover:shadow-lift">
    <div class="relative aspect-[4/3] overflow-hidden bg-cream-200">
        <x-recipe-photo :recipe="$recipe" loading="lazy" class="size-full object-cover transition duration-500 group-hover:scale-105" />
        <x-bookmark-button :recipe="$recipe" :saved="$saved" class="absolute top-3 right-3 z-10" />
        <span class="absolute bottom-3 left-3 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-charcoal">{{ $recipe->category }}</span>
        @if ($cooked)
            <span class="absolute top-3 left-3 rounded-full bg-basil-500 px-2.5 py-1 text-[11px] font-bold text-white">Cocinada</span>
        @endif
    </div>
    <div class="flex flex-1 flex-col gap-3 p-5">
        <h3 class="text-[19px] leading-snug font-extrabold">
            {{-- after:inset-0 estira el enlace para que toda la tarjeta lleve al detalle. --}}
            <a href="{{ route('recetas.show', $recipe) }}" class="after:absolute after:inset-0">{{ $recipe->title }}</a>
        </h3>
        <div class="mt-auto flex items-center gap-4 text-[13px] font-medium text-charcoal-soft">
            <span class="inline-flex items-center gap-1">
                <x-icon name="clock" size="15" />
                {{ $recipe->minutes }} min
            </span>
            <x-difficulty :level="$recipe->difficulty" />
            <span class="ml-auto font-semibold text-charcoal">{{ $recipe->cost_label }}</span>
        </div>
    </div>
</article>
```

**Entiende**
- En el mockup toda la tarjeta era un enlace `<a>` con el botón adentro. En HTML un formulario no puede ir dentro de un enlace, así que la tarjeta es un `<article>` y el enlace está en el título. `after:absolute after:inset-0` estira el área del enlace sobre toda la tarjeta, y `z-10` deja el botón de guardar por encima.
- `group` y `group-hover:scale-105`: al pasar el mouse por la tarjeta (el grupo), la foto se agranda.
- `id="receta-…"` y `scroll-mt-24`: después de guardar, la página vuelve a esta tarjeta sin que la tape la barra de arriba.
- `$recipe->cost_label` es el atributo de Miguel que entrega «$3.500».

## Paso 5 · Selector de los filtros

En el mockup: `Select` en `Catalog.tsx`. **Crea:**

📄 **`web/resources/views/components/select.blade.php`** · 15 líneas

```blade
@props(['label', 'name', 'options', 'value' => null])

{{-- Selector redondeado de los filtros. $options es ['valor' => 'Texto']. --}}
<label class="relative flex items-center">
    <span class="sr-only">{{ $label }}</span>
    <select
        name="{{ $name }}"
        {{ $attributes->class('h-11 appearance-none rounded-full border-2 border-cream-300 bg-white pr-10 pl-4 text-sm font-semibold outline-none hover:border-cream-300 focus:border-tomato-500') }}
    >
        @foreach ($options as $optionValue => $optionLabel)
            <option value="{{ $optionValue }}" @selected((string) $value === (string) $optionValue)>{{ $optionLabel }}</option>
        @endforeach
    </select>
    <svg class="pointer-events-none absolute right-4" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m2 4 4 4 4-4" /></svg>
</label>
```

**Entiende**
- `$options` es un arreglo `['valor' => 'Texto']`. `@selected(...)` marca la opción que coincide con el filtro actual.
- `appearance-none` quita la flecha del navegador; la nuestra es el `<svg>` de al lado.

## Paso 6 · Paginación

El mockup dibuja círculos con el número de página y un botón «Siguiente». Laravel deja escribir nuestra propia vista de paginación. **Crea:**

📄 **`web/resources/views/pagination/youcook.blade.php`** · 27 líneas

```blade
{{-- Paginación del mockup: un círculo por página y el botón «Siguiente». --}}
@if ($paginator->hasPages())
    <nav class="mt-10 flex items-center justify-center gap-2" aria-label="Paginación">
        @foreach ($elements as $element)
            @if (is_string($element))
                <span class="px-1 text-charcoal-soft">{{ $element }}</span>
            @endif

            @if (is_array($element))
                @foreach ($element as $page => $url)
                    @php $actual = $page === $paginator->currentPage(); @endphp
                    <a
                        href="{{ $url }}"
                        @if ($actual) aria-current="page" @endif
                        class="grid size-10 place-items-center rounded-full font-display font-bold {{ $actual ? 'bg-tomato-500 text-white' : 'bg-white text-charcoal shadow-soft hover:text-tomato-600' }}"
                    >{{ $page }}</a>
                @endforeach
            @endif
        @endforeach

        @if ($paginator->hasMorePages())
            <a href="{{ $paginator->nextPageUrl() }}" rel="next" class="ml-1 flex h-10 items-center gap-1 rounded-full bg-white px-4 font-display font-bold shadow-soft hover:text-tomato-600">
                Siguiente <x-icon name="arrow-right" size="16" />
            </a>
        @endif
    </nav>
@endif
```

**Entiende**
- `$paginator` y `$elements` los entrega Laravel. `$elements` trae los números de página con su URL (y `...` cuando hay muchas).
- `hasPages()`: si todo cabe en una página, no se dibuja nada.
- Se usa desde el catálogo con `{{ $recipes->links('pagination.youcook') }}`.

## Paso 7 · Catálogo

En el mockup: `screens/Catalog.tsx`. La diferencia grande: allá los filtros cambiaban una lista en la memoria; aquí **cada filtro es un parámetro de la URL** (`/recetas?q=arroz&categoria=Rápidas`) y quien filtra es la base de datos. **Reemplaza todo:**

📄 **`web/resources/views/recetas/index.blade.php`** · parte 1 de 4 (líneas 1–50) · empieza el archivo

```blade
@extends('layouts.app')

@section('titulo', 'Recetas')

@section('contenido')
    @php
        $categoria = $filters['categoria'] ?? null;
        $hayFiltros = collect($filters)->filter()->isNotEmpty();
    @endphp

    {{-- --- Buscador --- --}}
    <section class="relative overflow-hidden rounded-[32px] bg-tomato-500 px-6 py-10 text-white md:px-12 md:py-14">
        <div class="pointer-events-none absolute -top-24 -right-20 size-80 rounded-full bg-[#FF7A5C]"></div>
        <div class="pointer-events-none absolute -right-6 -bottom-28 size-64 rounded-full bg-tomato-600"></div>
        <div class="pointer-events-none absolute top-8 right-16 hidden gap-3 lg:flex">
            <x-sticker kind="tomate" size="92" rotate="-10" />
            <x-sticker kind="choclo" size="92" rotate="8" />
        </div>
        <div class="pointer-events-none absolute right-40 bottom-6 hidden lg:block"><x-sticker kind="panqueque" size="84" rotate="-6" /></div>

        <div class="relative max-w-[640px]">
            <p class="font-display text-sm font-extrabold tracking-wider text-white/80 uppercase">Hola, {{ auth()->user()->first_name }}</p>
            <h1 class="mt-2 text-[34px] leading-[1.05] font-black md:text-[48px]">¿Qué cocinamos hoy?</h1>

            {{-- Un solo formulario GET para todos los filtros. Los selectores de más
                 abajo no están dentro de él: se le unen con form="filtros". --}}
            <form id="filtros" role="search" method="GET" action="{{ route('recetas.index') }}" class="mt-7">
                @if ($categoria)
                    <input type="hidden" name="categoria" value="{{ $categoria }}">
                @endif
                <label class="flex h-15 items-center gap-3 rounded-2xl bg-white pr-2 pl-5 text-charcoal shadow-lift">
                    <x-icon name="search" size="22" class="text-charcoal-soft" />
                    <input
                        name="q"
                        value="{{ $filters['q'] ?? '' }}"
                        placeholder="Busca por plato o ingrediente: huevo, arroz, zapallo…"
                        class="h-14 w-full bg-transparent text-[16px] outline-none placeholder:text-[#B3A99D]"
                    >
                    <button class="hidden h-11 shrink-0 rounded-xl bg-charcoal px-5 font-display font-bold text-white sm:block">Buscar</button>
                </label>
            </form>

            <p class="mt-4 text-sm text-white/85">
                Populares:
                @foreach (['huevo', 'arroz', 'zapallo'] as $popular)
                    <a href="{{ route('recetas.index', ['q' => $popular]) }}" class="font-semibold underline-offset-2 hover:underline">{{ $popular }}</a>{{ $loop->last ? '' : ' ·' }}
                @endforeach
            </p>
        </div>
    </section>
```

**Entiende**
- `$filters` viene del controlador de Miguel: los filtros validados de la URL. `?? null` evita un error cuando un filtro no viene.
- El buscador es un formulario `GET`: al enviarlo, lo escrito queda en la URL (`?q=zapallo`). Por eso una búsqueda se puede compartir o guardar en favoritos.
- El campo oculto `categoria` hace que, al buscar, no se pierda la categoría elegida.
- «Populares» son enlaces normales a `/recetas?q=huevo`.

📄 **`web/resources/views/recetas/index.blade.php`** · parte 2 de 4 (líneas 52–82) · sigue debajo de la parte anterior

```blade
    {{-- --- Filtros --- --}}
    <section class="mt-10 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div class="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 lg:mx-0 lg:px-0">
            @foreach (['Todas', ...App\Models\Recipe::CATEGORIES] as $nombre)
                @php
                    $valor = $nombre === 'Todas' ? null : $nombre;
                    $activa = $categoria === $valor;
                @endphp
                {{-- Cambia la categoría y conserva los demás filtros; vuelve a la página 1. --}}
                <a
                    href="{{ request()->fullUrlWithQuery(['categoria' => $valor, 'page' => null]) }}"
                    @if ($activa) aria-current="true" @endif
                    class="flex h-11 shrink-0 items-center rounded-full px-5 font-display text-[15px] font-bold transition {{ $activa ? 'bg-charcoal text-white' : 'border-2 border-cream-300 bg-white text-charcoal hover:border-tomato-200' }}"
                >
                    {{ $nombre }}
                </a>
            @endforeach
        </div>
        <div class="flex gap-2">
            <x-select
                form="filtros" onchange="this.form.submit()"
                label="Tiempo" name="tiempo" :value="$filters['tiempo'] ?? null"
                :options="['' => 'Cualquier tiempo', '15' => 'Hasta 15 min', '30' => 'Hasta 30 min', '60' => 'Hasta 1 hora']"
            />
            <x-select
                form="filtros" onchange="this.form.submit()"
                label="Dificultad" name="dificultad" :value="$filters['dificultad'] ?? null"
                :options="['' => 'Toda dificultad', 'Fácil' => 'Fácil', 'Media' => 'Media']"
            />
        </div>
    </section>
```

**Entiende**
- Las categorías son enlaces. `request()->fullUrlWithQuery([...])` toma la URL actual y le cambia solo esos parámetros: cambia la categoría, conserva los demás filtros y, con `'page' => null`, vuelve a la página 1.
- `App\Models\Recipe::CATEGORIES` es la lista de categorías del modelo de Miguel: un solo lugar para agregar o quitar una.
- Los dos `<x-select>` están fuera del `<form>`, pero `form="filtros"` los une a él. `onchange="this.form.submit()"` envía el formulario apenas se elige una opción.

📄 **`web/resources/views/recetas/index.blade.php`** · partes 3 a 4 de 4 (líneas 84–122) · sigue debajo de la parte anterior

```blade
    {{-- --- Resultados --- --}}
    <div class="mt-8 mb-5 flex items-baseline justify-between">
        <h2 class="text-2xl font-black">{{ $categoria ?? 'Todas las recetas' }}</h2>
        <span class="text-sm text-charcoal-soft">{{ $recipes->count() }} de {{ $total }} recetas</span>
    </div>

    @if ($recipes->isNotEmpty())
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            @foreach ($recipes as $recipe)
                <x-recipe-card
                    :recipe="$recipe"
                    :saved="in_array($recipe->id, $savedIds)"
                    :cooked="in_array($recipe->id, $cookedIds)"
                />
            @endforeach
        </div>

        {{ $recipes->links('pagination.youcook') }}
    @else
        <div class="rounded-3xl border-2 border-dashed border-cream-300 px-6 py-16 text-center">
            <div class="mx-auto w-fit"><x-sticker kind="olla" size="96" /></div>
            <h3 class="mt-4 text-xl font-extrabold">No encontramos recetas con esos filtros</h3>
            <p class="mt-1 text-charcoal-soft">Prueba con otro ingrediente o quita algún filtro.</p>
            @if ($hayFiltros)
                <a href="{{ route('recetas.index') }}" class="mt-5 inline-block rounded-full bg-charcoal px-5 py-2.5 font-display font-bold text-white">Limpiar filtros</a>
            @endif
        </div>
    @endif

    {{-- --- Invitación al asistente --- --}}
    <a href="{{ route('asistente.show') }}" class="mt-14 flex flex-col items-start gap-5 rounded-[28px] bg-basil-500 p-7 text-white sm:flex-row sm:items-center md:p-9">
        <span class="grid size-14 shrink-0 place-items-center rounded-2xl bg-white/15"><x-icon name="sparkle" size="28" /></span>
        <span class="flex-1">
            <span class="block font-display text-2xl font-black">¿No sabes qué hacer con lo que tienes?</span>
            <span class="mt-1 block text-white/85">Cuéntale al asistente qué hay en tu refri y te sugiere una receta en segundos.</span>
        </span>
        <span class="flex items-center gap-2 rounded-full bg-white px-5 py-3 font-display font-extrabold text-basil-600">Abrir asistente <x-icon name="arrow-right" size="18" /></span>
    </a>
@endsection
```

**Entiende**
- `$recipes` es una página de resultados: `count()` son las que se ven ahora (8) y `$total`, todas las de la app (20). `links(...)` dibuja la paginación del paso 6.
- `in_array($recipe->id, $savedIds)` responde si **esta** receta está entre las guardadas. `:saved="…"` le pasa ese verdadero o falso a la tarjeta.
- `@if … @else`: con resultados, la grilla; sin resultados, el estado vacío del mockup.
- `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`: una columna en el teléfono, dos en tablet y cuatro en escritorio.

Revisa y sube el **PR 1**:

- [ ] Se ve igual al mockup: 8 tarjetas, «8 de 20 recetas», páginas 1-2-3 y «Siguiente».
- [ ] Buscar «zapallo», elegir una categoría, un tiempo y una dificultad: se combinan y la URL lo refleja.
- [ ] Una búsqueda sin resultados muestra la olla y «Limpiar filtros».
- [ ] El marcador de una tarjeta guarda (cuando el controlador de Miguel esté integrado; antes solo recarga) y la tarjeta entera lleva al detalle.
- [ ] Las recetas de la página 2 y 3 sin foto muestran su sticker.

```bash
npm run build && php artisan test      # las pruebas del catálogo de Miguel deben seguir en verde
git add . && git commit -m "Catálogo del mockup"
git push -u origin emma/dia2-catalogo
```

## Paso 8 · Detalle de receta

Rama nueva: `git switch main && git pull && git switch -c emma/dia2-detalle`. Necesitas que `<x-ingredient-row>` de Sebastián esté en `main`.

En el mockup: `screens/Detail.tsx`. **Reemplaza todo:**

📄 **`web/resources/views/recetas/show.blade.php`** · parte 1 de 4 (líneas 1–48) · empieza el archivo

```blade
@extends('layouts.app')

@section('titulo', $recipe->title)

@section('contenido')
    <article>
        <a href="{{ route('recetas.index') }}" class="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-charcoal-soft hover:text-charcoal">
            <x-icon name="arrow-left" size="17" /> Volver a recetas
        </a>

        {{-- --- Foto y resumen --- --}}
        <div class="grid gap-8 lg:grid-cols-[1.15fr_1fr] lg:gap-12">
            <div class="relative overflow-hidden rounded-[32px] bg-cream-200 shadow-soft">
                <x-recipe-photo :recipe="$recipe" sticker="220" class="aspect-[4/3] size-full object-cover lg:aspect-auto lg:h-[520px]" />
                <x-bookmark-button :recipe="$recipe" :saved="$isSaved" size="size-12" class="absolute top-5 right-5 lg:hidden" />
            </div>

            <div class="flex flex-col">
                <span class="w-fit rounded-full bg-tomato-50 px-3 py-1 text-sm font-bold text-tomato-600">{{ $recipe->category }}</span>
                <h1 class="mt-4 text-[38px] leading-[1.05] font-black md:text-[52px]">{{ $recipe->title }}</h1>
                <p class="mt-4 text-lg leading-relaxed text-charcoal-soft">{{ $recipe->description }}</p>

                <dl class="mt-7 grid grid-cols-2 gap-2 gap-y-4 rounded-3xl bg-white p-4 shadow-soft sm:grid-cols-4">
                    <div class="text-center">
                        <dt class="text-xs text-charcoal-soft">Tiempo</dt>
                        <dd class="mt-1 flex items-center justify-center gap-1 font-display text-[17px] font-extrabold">
                            <x-icon name="clock" size="15" class="text-tomato-500" /> {{ $recipe->minutes }} min
                        </dd>
                    </div>
                    <div class="text-center">
                        <dt class="text-xs text-charcoal-soft">Dificultad</dt>
                        <dd class="mt-1 flex items-center justify-center gap-1 font-display text-[17px] font-extrabold">
                            <x-difficulty :level="$recipe->difficulty" />
                        </dd>
                    </div>
                    <div class="text-center">
                        <dt class="text-xs text-charcoal-soft">Porciones</dt>
                        <dd class="mt-1 flex items-center justify-center gap-1 font-display text-[17px] font-extrabold">
                            <x-icon name="users" size="15" class="text-tomato-500" /> {{ $recipe->servings }}
                        </dd>
                    </div>
                    <div class="text-center">
                        <dt class="text-xs text-charcoal-soft">Costo aprox.</dt>
                        <dd class="mt-1 flex items-center justify-center gap-1 font-display text-[17px] font-extrabold">
                            <x-icon name="wallet" size="15" class="text-tomato-500" /> {{ $recipe->cost_label }}
                        </dd>
                    </div>
                </dl>
```

**Entiende**
- `:title="$recipe->title"` pone el nombre de la receta en la pestaña del navegador.
- El botón de guardar sobre la foto es `lg:hidden`: solo en pantallas chicas. En escritorio se usa el botón «Guardar» de más abajo.
- `<dl>`, `<dt>` y `<dd>` son la lista de datos (tiempo, dificultad, porciones y costo): dos columnas en el teléfono y cuatro desde `sm:`.

📄 **`web/resources/views/recetas/show.blade.php`** · parte 2 de 4 (líneas 50–83) · sigue debajo de la parte anterior

```blade
                {{-- --- Cocinada y Guardar: dos formularios POST --- --}}
                <div class="mt-5 flex gap-3">
                    <form method="POST" action="{{ route('recetas.cocinada', $recipe) }}" class="flex-1">
                        @csrf
                        <button class="flex h-14 w-full items-center justify-center gap-2 rounded-2xl font-display text-[17px] font-extrabold transition active:translate-y-px {{ $isCooked ? 'bg-basil-100 text-basil-600' : 'bg-basil-500 text-white shadow-[inset_0_-4px_0_rgb(0_0_0/0.14)] hover:bg-basil-600' }}">
                            <x-icon name="check" size="20" stroke="2.6" />
                            {{ $isCooked ? '¡Ya la cocinaste!' : 'Marcar como cocinada' }}
                        </button>
                    </form>
                    <form method="POST" action="{{ route('recetas.guardar', $recipe) }}">
                        @csrf
                        <button
                            aria-pressed="{{ $isSaved ? 'true' : 'false' }}"
                            class="flex h-14 items-center gap-2 rounded-2xl border-2 px-5 font-display font-extrabold transition {{ $isSaved ? 'border-tomato-500 bg-tomato-50 text-tomato-600' : 'border-cream-300 bg-white hover:border-tomato-200' }}"
                        >
                            <x-icon name="bookmark" size="19" :filled="$isSaved" />
                            <span class="hidden sm:inline">{{ $isSaved ? 'Guardada' : 'Guardar' }}</span>
                        </button>
                    </form>
                </div>

                <div class="mt-5 flex gap-3 rounded-2xl border border-[#F3D18A] bg-[#FFF4D6] p-4">
                    <x-icon name="alert" size="20" class="mt-0.5 shrink-0 text-[#B07A0B]" />
                    <div class="text-[15px]">
                        <p class="font-bold text-[#7A5304]">Alérgenos</p>
                        <p class="mt-0.5 text-[#7A5304]/90">
                            {{ implode(' · ', $recipe->allergens) }}. Revisa las etiquetas de tus productos: pueden contener trazas.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-12 grid gap-8 lg:grid-cols-[1fr_1.15fr] lg:gap-12">
```

**Entiende**
- «Marcar como cocinada» y «Guardar» son dos formularios `POST`, cada uno a su ruta. `$isCooked` e `$isSaved` vienen del controlador y deciden el texto y los colores.
- Al marcar como cocinada, el controlador deja un aviso en la sesión y tu layout lo muestra con el sticker de la receta.
- La caja amarilla de alérgenos es uno de los riesgos de la propuesta. `implode(' · ', …)` une la lista con puntos.

📄 **`web/resources/views/recetas/show.blade.php`** · partes 3 a 4 de 4 (líneas 84–138) · sigue debajo de la parte anterior

```blade
            {{-- --- Ingredientes --- --}}
            <section class="h-fit rounded-[28px] bg-white p-6 shadow-soft md:p-8">
                <div class="flex items-baseline justify-between">
                    <h2 class="text-2xl font-black">Ingredientes</h2>
                    <span class="text-sm text-charcoal-soft">{{ $recipe->servings }} {{ $recipe->servings === 1 ? 'porción' : 'porciones' }}</span>
                </div>
                <p class="mt-1 mb-3 text-sm text-charcoal-soft">¿Te falta algo? Toca «No lo tengo» y la IA te sugiere un reemplazo.</p>
                <ul>
                    @foreach ($recipe->ingredients as $ingredient)
                        <x-ingredient-row :ingredient="$ingredient" :recipe="$recipe" />
                    @endforeach
                </ul>
            </section>

            {{-- --- Preparación --- --}}
            {{-- «hechos» cuenta los pasos marcados; cada paso recuerda si está «listo». --}}
            <section x-data="{ hechos: 0 }">
                <div class="flex items-baseline justify-between">
                    <h2 class="text-2xl font-black">Preparación</h2>
                    <span class="text-sm text-charcoal-soft"><span x-text="hechos">0</span> de {{ count($recipe->steps) }} pasos</span>
                </div>
                <ol class="mt-5 space-y-3">
                    @foreach ($recipe->steps as $step)
                        <li x-data="{ listo: false }">
                            <button
                                type="button"
                                x-on:click="listo = ! listo; hechos += listo ? 1 : -1"
                                class="flex w-full gap-4 rounded-2xl bg-white p-4 text-left shadow-soft transition hover:shadow-lift"
                                :class="{ 'bg-basil-50': listo, 'bg-white shadow-soft hover:shadow-lift': ! listo }"
                            >
                                <span
                                    class="grid size-10 shrink-0 place-items-center rounded-full bg-tomato-50 font-display text-lg font-black text-tomato-600"
                                    :class="{ 'bg-basil-500 text-white': listo, 'bg-tomato-50 text-tomato-600': ! listo }"
                                >
                                    <x-icon name="check" size="18" stroke="3" x-show="listo" x-cloak />
                                    <span x-show="! listo">{{ $loop->iteration }}</span>
                                </span>
                                <span class="pt-1.5 text-[16px] leading-relaxed" :class="{ 'text-charcoal-soft': listo }">{{ $step }}</span>
                            </button>
                        </li>
                    @endforeach
                </ol>

                <a href="{{ route('asistente.show', ['receta' => $recipe->slug]) }}" class="mt-6 flex items-center gap-4 rounded-2xl border-2 border-dashed border-basil-100 bg-basil-50/60 p-5 transition hover:border-basil-500">
                    <span class="grid size-11 place-items-center rounded-xl bg-basil-500 text-white"><x-icon name="chat" size="20" /></span>
                    <span class="flex-1">
                        <span class="block font-display font-extrabold">¿Dudas con algún paso?</span>
                        <span class="block text-sm text-charcoal-soft">Pregúntale al asistente sobre {{ mb_strtolower($recipe->title) }}.</span>
                    </span>
                    <x-icon name="arrow-right" size="18" class="text-basil-600" />
                </a>
            </section>
        </div>
    </article>
@endsection
```

**Entiende**
- Cada ingrediente es un `<x-ingredient-row>` de Sebastián: la casilla, «No lo tengo» y el panel de la IA viven ahí.
- Los pasos se marcan **solo en el navegador** (no se guardan): es Alpine. `x-data="{ hechos: 0 }"` es el contador de la sección y cada paso tiene su propio `listo`. Al tocar un paso, cambia `listo` y suma o resta 1 a `hechos`.
- `:class="{ 'clases': condición }"` pone esas clases cuando la condición es verdadera y las quita cuando es falsa. Las del estado inicial también están en `class`, para que se vea bien antes de que Alpine cargue.
- `$loop->iteration` es el número de vuelta del `@foreach`, partiendo en 1.
- El enlace final lleva al asistente con `?receta=charquican`, para que la conversación sea sobre esta receta.

Revisa:

- [ ] `/recetas/charquican` se ve igual al mockup, en escritorio y en teléfono.
- [ ] Los pasos se marcan y el contador «2 de 6 pasos» cambia.
- [ ] «Marcar como cocinada» muestra el aviso con el sticker y cambia a «¡Ya la cocinaste!».
- [ ] `/recetas/pure` (sin foto) muestra el sticker grande.
- [ ] «No lo tengo» muestra el panel de la IA (con error o con respuestas, según cuánto haya avanzado Sebastián).

## Cierre del día

```bash
npm run build && php artisan test
git add . && git commit -m "Detalle de receta del mockup"
git push -u origin emma/dia2-detalle
```

- [ ] Dos PR abiertos (catálogo y detalle).
- [ ] Check-in de las 21:00.
