<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Sebastián · Día 2 (sábado 14): alternativas con IA y el asistente

**Meta del día:** que el botón «No lo tengo» y el chat del asistente funcionen con la IA real, con sus estados de carga y de error iguales a los del mockup.

← [Día 1](dia1.md) · [Índice de guías](../README.md) · Siguiente: [Día 3](dia3.md)

## Mapa del día

| Paso | Qué haces | Archivo | Depende de |
|---|---|---|---|
| 1 | Enviar JSON a Laravel desde JavaScript | `resources/js/ia.js` | — |
| 2 | El estado de una fila de ingrediente | `resources/js/ingrediente.js`, `resources/js/app.js` ① | — |
| 3 | «Cargando» y «error» de la IA | `components/ia-loading.blade.php`, `ia-error.blade.php` | Íconos de Emma (viernes) |
| 4 | La fila de ingrediente | `components/ingredient-row.blade.php` | **📣 Emma la espera a las 12:00** |
| 5 | Las preguntas a la IA | `app/Services/AsistenteIA.php` (partes 3 a 5) | Modelos de Miguel (viernes) |
| 6 | Controlador de «No lo tengo» | `IngredientAlternativeController.php` | — |
| 7 | Controlador del asistente | `AssistantController.php` | — |
| 8 | Rutas definitivas de la IA | `routes/ia.php` | — |
| 9 | El estado del chat | `resources/js/chat.js`, `resources/js/app.js` ② | — |
| 10 | La pantalla del asistente | `resources/views/asistente/show.blade.php` | Layout de Emma (viernes) |
| 11 | Pruebas | `AsistenteIATest.php` (parte 2), `AssistantTest.php` | Factories de Miguel (10:00) |
| 12 | Prueba con la IA real | (navegador) | Detalle de Emma (tarde) |

`app.js` cambia **dos veces** hoy (①②).

**Tiempo:** unas 4 h (~620 líneas). Es tu día más largo: los pasos 1 a 4 van primero porque Emma los necesita.

Rama de la mañana: `git switch main && git pull && git switch -c sebastian/dia2-ingrediente`.

---

## Cómo se reparte el trabajo entre el servidor y el navegador

En el mockup todo pasa en el navegador (React) y la IA es de mentira. Aquí la IA es real y la clave no puede salir del servidor:

1. La persona toca «No lo tengo». **Alpine** (JavaScript) cambia el estado de esa fila a `cargando` y hace un `fetch` a nuestra ruta de Laravel.
2. **Laravel** recibe la petición, le pregunta a Groq con la clave secreta y responde JSON.
3. Alpine recibe el JSON, cambia el estado a `listo` (o `error`) y la página se redibuja sola, sin recargar.

## Paso 1 · Enviar JSON a Laravel desde JavaScript

**Crea:**

📄 **`web/resources/js/ia.js`** · 20 líneas

```js
// Envía un POST con JSON a una ruta de Laravel y devuelve la respuesta como objeto.
// Si el servidor responde con error (503 cuando la IA no está, 429 si hay
// demasiadas consultas), lanza una excepción: quien llama muestra «Reintentar».
export async function postJson(url, datos = {}) {
    const respuesta = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify(datos),
    });

    if (!respuesta.ok) {
        throw new Error(`Error ${respuesta.status}`);
    }

    return respuesta.json();
}
```

**Entiende**
- `fetch` hace una petición sin recargar la página. `await` espera la respuesta sin congelar el navegador.
- `X-CSRF-TOKEN`: el mismo código secreto de `@csrf`, pero enviado como encabezado. Sale de la etiqueta `<meta name="csrf-token">` que el layout pone en el `<head>`. Sin él, Laravel responde 419.
- `Accept: application/json` le pide a Laravel que, si algo falla, responda JSON y no una página HTML.
- `respuesta.ok` es falso cuando el código es 4xx o 5xx. Ahí lanzamos un error para que quien llamó muestre «Reintentar».

## Paso 2 · El estado de una fila de ingrediente

En el mockup, cada fila (`IngredientRow` en `Detail.tsx`) tiene dos estados de React: `have` y `state`. En Alpine es un objeto con datos y funciones. **Crea:**

📄 **`web/resources/js/ingrediente.js`** · 33 líneas

```js
import { postJson } from './ia';

// Una fila de ingrediente del detalle de receta.
// estado: 'inactivo' → 'cargando' → 'listo' | 'error'
export default (url) => ({
    tengo: false,
    estado: 'inactivo',
    alternativas: [],

    async pedir() {
        this.estado = 'cargando';

        try {
            const datos = await postJson(url);

            // "Sin zapallo → zanahoria rallada" se separa en dos partes para darles estilo.
            this.alternativas = datos.alternativas.map((texto) => {
                const [desde, ...resto] = texto.split('→');

                return resto.length
                    ? { desde: desde.trim(), hacia: resto.join('→').trim() }
                    : { desde: null, hacia: texto };
            });
            this.estado = 'listo';
        } catch {
            this.estado = 'error';
        }
    },

    cerrar() {
        this.estado = 'inactivo';
    },
});
```

**Entiende**
- La función devuelve el estado inicial de **una** fila. Alpine la llama una vez por cada fila, así que cada ingrediente tiene su propio `tengo` y su propio `estado`.
- `estado` recorre el mismo camino del mockup: `inactivo → cargando → listo` o `error`. La vista muestra una cosa distinta según su valor.
- La IA responde «Sin zapallo → zanahoria rallada». `split('→')` lo separa para pintar la primera parte en gris y la segunda en negrita. Si la respuesta no trae flecha, se muestra completa.
- `try / catch`: cualquier error (sin internet, 503, 429) termina en `estado = 'error'`.

Registra el componente en Alpine. **Reemplaza todo:**

📄 **`web/resources/js/app.js`** · 9 líneas · **versión provisional**

```js
import Alpine from 'alpinejs';
import ingrediente from './ingrediente';

// Componentes de Alpine que usan las vistas con x-data="ingrediente(...)".
Alpine.data('ingrediente', ingrediente);

window.Alpine = Alpine;

Alpine.start();
```

## Paso 3 · «Cargando» y «error» de la IA

Dos componentes que usan la fila de ingrediente y el chat. **Crea:**

📄 **`web/resources/views/components/ia-loading.blade.php`** · 15 líneas

```blade
@props(['label'])

{{-- Estado «cargando» de la IA: tres puntos que saltan y dos líneas grises. --}}
<div role="status" class="space-y-3">
    <p class="flex items-center gap-2 text-sm font-semibold text-basil-600">
        <span class="flex gap-1">
            <span class="dot size-1.5 rounded-full bg-basil-500"></span>
            <span class="dot size-1.5 rounded-full bg-basil-500 [animation-delay:.15s]"></span>
            <span class="dot size-1.5 rounded-full bg-basil-500 [animation-delay:.3s]"></span>
        </span>
        {{ $label }}
    </p>
    <div class="skeleton h-3.5 w-11/12 rounded-full"></div>
    <div class="skeleton h-3.5 w-2/3 rounded-full"></div>
</div>
```

📄 **`web/resources/views/components/ia-error.blade.php`** · 12 líneas

```blade
{{-- Estado «error» de la IA. Lo que se le pase al componente (por ejemplo
     x-on:click="pedir()") queda en el botón «Reintentar». --}}
<div role="alert" class="flex items-start gap-3">
    <span class="grid size-9 shrink-0 place-items-center rounded-full bg-tomato-100 text-tomato-600"><x-icon name="alert" size="18" /></span>
    <div class="flex-1">
        <p class="font-semibold text-charcoal">El asistente no está disponible</p>
        <p class="text-sm text-charcoal-soft">Intenta de nuevo en un momento.</p>
    </div>
    <button type="button" {{ $attributes->class('flex items-center gap-1.5 rounded-full border-2 border-tomato-200 px-3.5 py-1.5 text-sm font-bold text-tomato-600 hover:bg-tomato-50') }}>
        <x-icon name="refresh" size="15" /> Reintentar
    </button>
</div>
```

**Entiende**
- `@props(['label'])` declara lo que recibe el componente: `<x-ia-loading label="Buscando…" />`.
- `{{ $attributes }}` son todos los atributos que **no** están en `@props`. En `ia-error` van a parar al botón: `<x-ia-error x-on:click="pedir()" />` deja el `x-on:click` en «Reintentar». Así el mismo componente sirve para reintentar cosas distintas.
- `role="status"` y `role="alert"` hacen que un lector de pantalla anuncie el cambio.

## Paso 4 · La fila de ingrediente

**Crea:**

📄 **`web/resources/views/components/ingredient-row.blade.php`** · parte 1 de 2 (líneas 1–42) · empieza el archivo

```blade
@props(['ingredient', 'recipe'])

{{-- Una fila de ingrediente. El estado (tengo, estado, alternativas) vive en
     resources/js/ingrediente.js; aquí solo se dibuja según ese estado. --}}
<li
    class="border-b border-cream-200 last:border-0"
    x-data="ingrediente(@js(route('recetas.alternativas', [$recipe, $ingredient])))"
>
    {{-- --- La fila --- --}}
    <div class="flex items-center gap-3 py-3.5">
        <button
            type="button"
            x-on:click="tengo = ! tengo"
            :aria-pressed="tengo.toString()"
            aria-label="Marcar {{ $ingredient->name }}"
            class="grid size-6 shrink-0 place-items-center rounded-lg border-2 border-cream-300 bg-white transition"
            :class="{ 'border-basil-500 bg-basil-500 text-white': tengo, 'border-cream-300 bg-white': ! tengo }"
        >
            <x-icon name="check" size="14" stroke="3" x-show="tengo" x-cloak />
        </button>
        <div class="flex-1" :class="{ 'text-charcoal-soft line-through decoration-cream-300': tengo }">
            <span class="font-semibold">{{ $ingredient->name }}</span><span class="ml-2 text-charcoal-soft">{{ $ingredient->quantity }}</span>
        </div>
        <button
            type="button"
            x-show="estado === 'inactivo'"
            x-on:click="pedir()"
            class="flex shrink-0 items-center gap-1.5 rounded-full bg-cream-200 px-3 py-1.5 text-[13px] font-bold text-charcoal transition hover:bg-basil-100 hover:text-basil-600"
        >
            <x-icon name="swap" size="14" /> No lo tengo
        </button>
        <button
            type="button"
            x-show="estado !== 'inactivo'"
            x-cloak
            x-on:click="cerrar()"
            class="grid size-8 place-items-center rounded-full text-charcoal-soft hover:bg-cream-200"
            aria-label="Cerrar alternativas"
        >
            <x-icon name="x" size="16" />
        </button>
    </div>
```

**Entiende**
- `x-data="ingrediente(...)"` conecta este `<li>` con el objeto del paso 2. `@js(...)` convierte un valor de PHP (la URL de la ruta) en un valor de JavaScript seguro.
- `route('recetas.alternativas', [$recipe, $ingredient])` arma `/recetas/charquican/ingredientes/3/alternativas`.
- `x-on:click="tengo = ! tengo"` cambia el dato. `:class="{ 'clases': condición }"` pone o quita clases según el dato. La clase por defecto también está en `class="..."`, para que la fila se vea bien antes de que Alpine cargue.
- `x-show` muestra u oculta. `x-cloak` evita que lo que parte oculto se alcance a ver mientras Alpine carga.

📄 **`web/resources/views/components/ingredient-row.blade.php`** · parte 2 de 2 (líneas 44–73) · sigue debajo de la parte anterior

```blade
    {{-- --- El panel de la IA --- --}}
    <div x-show="estado !== 'inactivo'" x-cloak class="rise mb-4 rounded-2xl border border-basil-100 bg-basil-50 p-4">
        <p class="mb-3 flex items-center gap-1.5 text-xs font-extrabold tracking-wide text-basil-600 uppercase">
            <x-icon name="sparkle" size="14" /> Alternativas sugeridas por IA
        </p>

        <div x-show="estado === 'cargando'">
            <x-ia-loading label="Buscando reemplazos para {{ mb_strtolower($ingredient->name) }}…" />
        </div>

        <div x-show="estado === 'error'">
            <x-ia-error x-on:click="pedir()" />
        </div>

        <div x-show="estado === 'listo'">
            <ul class="space-y-2">
                <template x-for="alternativa in alternativas" :key="alternativa.hacia">
                    <li class="flex items-start gap-3 rounded-xl bg-white p-3 text-[15px] shadow-soft">
                        <x-icon name="arrow-right" size="16" class="mt-1 shrink-0 text-basil-500" />
                        <span>
                            <span class="text-charcoal-soft" x-show="alternativa.desde" x-text="alternativa.desde + ' → '"></span>
                            <span class="font-semibold" x-text="alternativa.hacia"></span>
                        </span>
                    </li>
                </template>
            </ul>
            <p class="mt-3 text-xs text-charcoal-soft">Sugerencia generada por IA para «{{ $recipe->title }}». Revisa alérgenos antes de reemplazar.</p>
        </div>
    </div>
</li>
```

**Entiende**
- Son los tres estados del mockup, uno por `x-show`: cargando, error y listo.
- `<template x-for="...">` repite el `<li>` por cada alternativa. `x-text` escribe el texto escapado: aunque la IA respondiera con HTML, se vería como texto y no se ejecutaría.
- El aviso «Revisa alérgenos antes de reemplazar» responde a uno de los riesgos de la propuesta.

Para mirarla antes de que exista el detalle, crea `resources/views/muestra.blade.php` (no se sube) y abre `http://localhost:8000/muestra`:

```blade
@extends('layouts.app')

@section('titulo', 'Muestra')

@section('contenido')
    @php $recipe = App\Models\Recipe::with('ingredients')->first(); @endphp
    <ul class="max-w-xl rounded-[28px] bg-white p-6 shadow-soft">
        @foreach ($recipe->ingredients as $ingredient)
            <x-ingredient-row :ingredient="$ingredient" :recipe="$recipe" />
        @endforeach
    </ul>
@endsection
```

- [ ] La casilla marca y tacha el ingrediente.
- [ ] «No lo tengo» muestra los puntos saltando y luego **el error con «Reintentar»** (es lo esperado: la ruta todavía es la provisional y responde 503).

```bash
npm run build && php artisan test
git add . && git commit -m "Fila de ingrediente con sus estados de IA"
git push -u origin sebastian/dia2-ingrediente
```

Integra el PR y avisa: **📣 «Emma: `<x-ingredient-row :ingredient :recipe />` está en main»**.

---

## Tarde: la IA de verdad

Rama nueva: `git switch main && git pull && git switch -c sebastian/dia2-asistente`.

## Paso 5 · Las preguntas a la IA

Abre `app/Services/AsistenteIA.php`. **Borra la `}` final** y sigue escribiendo debajo:

📄 **`web/app/Services/AsistenteIA.php`** · partes 3 a 5 de 5 (líneas 74–151) · sigue debajo de la parte anterior

```php
    // --- Conversación del chat ---
    /**
     * @param  array<int, array{role: string, content: string}>  $historial
     */
    public function conversar(array $historial, ?Recipe $recipe, string $nombre): string
    {
        $contexto = self::REGLAS."\nLa persona se llama {$nombre}.";

        if ($recipe) {
            $contexto .= "\nEstá viendo esta receta:\n".$this->describir($recipe);
        }

        return $this->preguntar([
            ['role' => 'system', 'content' => $contexto],
            ...$historial,
        ]);
    }

    // --- Reemplazos de un ingrediente ---
    /**
     * @return array<int, string> Por ejemplo: ["Sin zapallo → zanahoria rallada (2 unidades)"]
     */
    public function alternativas(Recipe $recipe, Ingredient $ingredient): array
    {
        $pregunta = <<<TXT
        Para esta receta me falta un ingrediente: {$ingredient->name} ({$ingredient->quantity}).
        Dame 2 reemplazos fáciles de conseguir en Chile.
        Responde SOLO con 2 líneas, una por reemplazo, con este formato exacto:
        Sin {$ingredient->name} → reemplazo y cantidad
        No escribas introducción, numeración ni Markdown.

        {$this->describir($recipe)}
        TXT;

        $respuesta = $this->preguntar([
            ['role' => 'system', 'content' => self::REGLAS],
            ['role' => 'user', 'content' => $pregunta],
        ]);

        // Una alternativa por línea, sin viñetas ni números al comienzo.
        $alternativas = collect(preg_split('/\R/u', $respuesta))
            ->map(fn (string $linea) => trim(preg_replace('/^[\s\-\*•\d\.\)]+/u', '', $linea)))
            ->filter()
            ->take(3)
            ->values()
            ->all();

        if ($alternativas === []) {
            throw new IaNoDisponible('La IA respondió sin alternativas.');
        }

        return $alternativas;
    }

    // --- Texto de la receta para el modelo ---
    private function describir(Recipe $recipe): string
    {
        $ingredientes = $recipe->ingredients
            ->map(fn (Ingredient $i) => "{$i->name} ({$i->quantity})")
            ->join(', ');

        $pasos = collect($recipe->steps)
            ->map(fn (string $paso, int $i) => ($i + 1).'. '.$paso)
            ->join(' ');

        return <<<TXT
        Receta: {$recipe->title} ({$recipe->minutes} min, {$recipe->servings} porciones).
        Ingredientes: {$ingredientes}.
        Pasos: {$pasos}
        Alérgenos: {$this->lista($recipe->allergens)}.
        TXT;
    }

    private function lista(array $items): string
    {
        return implode(', ', $items);
    }
}
```

**Entiende**
- `conversar()` arma la lista de mensajes: primero el de sistema (las reglas, el nombre de la persona y, si hay, la receta) y después el historial. `...$historial` «desarma» el arreglo dentro del otro.
- La IA no tiene memoria: en cada pregunta le enviamos la conversación de nuevo. Por eso el controlador solo manda los últimos mensajes.
- `alternativas()` pide un formato exacto («SOLO 2 líneas», «Sin X → Y») para poder convertir la respuesta en una lista. `preg_split('/\R/u', ...)` corta por saltos de línea y `preg_replace` quita viñetas o números si el modelo los pone igual.
- Si después de limpiar no queda nada, se trata como una falla: es mejor mostrar «Reintentar» que una lista vacía.
- `describir()` convierte la receta en texto. Darle la receta completa al modelo evita que invente ingredientes o pasos.

## Paso 6 · Controlador de «No lo tengo»

**Crea:**

📄 **`web/app/Http/Controllers/IngredientAlternativeController.php`** · 31 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Exceptions\IaNoDisponible;
use App\Models\Ingredient;
use App\Models\Recipe;
use App\Services\AsistenteIA;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;

class IngredientAlternativeController extends Controller
{
    // Botón «No lo tengo»: responde JSON con los reemplazos que sugiere la IA.
    public function __invoke(Recipe $recipe, Ingredient $ingredient, AsistenteIA $ia): JsonResponse
    {
        try {
            // La misma pregunta da la misma respuesta: se guarda una semana
            // para no gastar el límite gratis de la API.
            $alternativas = Cache::remember(
                "alternativas:{$ingredient->id}",
                now()->addWeek(),
                fn () => $ia->alternativas($recipe, $ingredient),
            );
        } catch (IaNoDisponible) {
            return response()->json(['error' => 'El asistente no está disponible.'], 503);
        }

        return response()->json(['alternativas' => $alternativas]);
    }
}
```

**Entiende**
- Un controlador con un solo método `__invoke` es un controlador de una sola acción: en la ruta se escribe solo la clase.
- `Recipe $recipe, Ingredient $ingredient`: Laravel busca los dos modelos a partir de la URL. `AsistenteIA $ia`: Laravel crea el servicio y lo entrega (inyección de dependencias).
- `Cache::remember(clave, tiempo, función)`: si ya hay una respuesta guardada para ese ingrediente, la devuelve sin llamar a la IA. Si no, ejecuta la función y guarda el resultado por una semana. Cuando la función lanza una excepción, no se guarda nada.
- Con la IA caída responde **503** con un JSON. `ia.js` ve que la respuesta no es `ok` y la fila muestra «Reintentar».

## Paso 7 · Controlador del asistente

**Crea:**

📄 **`web/app/Http/Controllers/AssistantController.php`** · 74 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Exceptions\IaNoDisponible;
use App\Models\Recipe;
use App\Services\AsistenteIA;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AssistantController extends Controller
{
    // La conversación vive en la sesión:
    //   asistente.receta_id → receta de la que se está hablando (o null)
    //   asistente.mensajes  → [['role' => 'user'|'assistant', 'content' => '...'], ...]

    // Pantalla del chat: /asistente o /asistente?receta=charquican
    public function show(Request $request): View
    {
        $recipe = Recipe::where('slug', $request->query('receta'))->first();

        // Llegar desde otra receta empieza una conversación nueva.
        if ($recipe && $recipe->id !== session('asistente.receta_id')) {
            session(['asistente' => ['receta_id' => $recipe->id, 'mensajes' => []]]);
        }

        $recipe ??= Recipe::find(session('asistente.receta_id'));

        return view('asistente.show', [
            'recipe' => $recipe,
            'mensajes' => session('asistente.mensajes', []),
            'sugerencias' => $recipe
                ? ['¿Cómo sé si está cocido?', '¿Puedo congelarlo?', '¿Con qué lo acompaño?', '¿Lo puedo hacer sin carne?']
                : ['¿Qué hago con arroz, huevo y cebolla?', '¿Cuánto dura el arroz en el refri?', 'Se me pasó de sal, ¿cómo lo arreglo?'],
        ]);
    }

    // Recibe un mensaje y responde JSON con la respuesta de la IA.
    public function send(Request $request, AsistenteIA $ia): JsonResponse
    {
        $datos = $request->validate([
            'mensaje' => ['required', 'string', 'max:500'],
        ]);

        $historial = session('asistente.mensajes', []);
        $historial[] = ['role' => 'user', 'content' => $datos['mensaje']];

        try {
            $respuesta = $ia->conversar(
                array_slice($historial, -10),   // solo los últimos mensajes: menos tokens
                Recipe::with('ingredients')->find(session('asistente.receta_id')),
                $request->user()->first_name,
            );
        } catch (IaNoDisponible) {
            // No se guarda nada: «Reintentar» vuelve a enviar la misma pregunta.
            return response()->json(['error' => 'El asistente no está disponible.'], 503);
        }

        $historial[] = ['role' => 'assistant', 'content' => $respuesta];
        session(['asistente.mensajes' => array_slice($historial, -30)]);

        return response()->json(['respuesta' => $respuesta]);
    }

    // Botón «Nueva conversación»: borra los mensajes y conserva la receta.
    public function reset(): RedirectResponse
    {
        session()->forget('asistente.mensajes');

        return redirect()->route('asistente.show');
    }
}
```

**Entiende**
- La conversación se guarda en la **sesión** (`session(...)`): dura mientras la persona tenga la sesión abierta y no necesita una tabla.
- `show`: si se llega con `?receta=charquican` y es una receta distinta de la anterior, empieza una conversación nueva sobre esa receta. `??=` asigna solo si la variable es `null`.
- `send`: valida el mensaje (obligatorio, máximo 500 caracteres) y envía a la IA los últimos 10 mensajes. La respuesta se guarda **solo si la IA respondió**: por eso «Reintentar» puede enviar la misma pregunta sin que quede repetida.
- `first_name` es el atributo que Miguel agregó a `User` («Camila Rojas» → «Camila»).
- `reset` borra los mensajes y conserva la receta, igual que «Nueva conversación» en el mockup.

## Paso 8 · Rutas definitivas de la IA

**Reemplaza todo:**

📄 **`web/routes/ia.php`** · 19 líneas

```php
<?php

use App\Http\Controllers\AssistantController;
use App\Http\Controllers\IngredientAlternativeController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth')->group(function () {
    Route::get('/asistente', [AssistantController::class, 'show'])->name('asistente.show');
    Route::delete('/asistente', [AssistantController::class, 'reset'])->name('asistente.reset');

    // Las dos rutas que llaman a la IA: máximo 20 consultas por minuto por persona.
    Route::middleware('throttle:20,1')->group(function () {
        Route::post('/asistente', [AssistantController::class, 'send'])->name('asistente.send');

        Route::post('/recetas/{recipe}/ingredientes/{ingredient}/alternativas', IngredientAlternativeController::class)
            ->scopeBindings()
            ->name('recetas.alternativas');
    });
});
```

**Entiende**
- `throttle:20,1`: máximo 20 peticiones por minuto por persona. A la número 21, Laravel responde 429 sin llamar a la IA. Protege el límite del plan gratuito de Groq, que es por minuto y por día para toda la clave.
- `scopeBindings()`: el ingrediente tiene que pertenecer a la receta de la URL. `/recetas/charquican/ingredientes/999/alternativas` con un ingrediente de otra receta responde 404.
- Misma URL `/asistente` con tres verbos: `GET` muestra, `POST` envía un mensaje y `DELETE` borra la conversación.

## Paso 9 · El estado del chat

En el mockup es `Assistant.tsx` (`msgs`, `text`, `send`, `retry`). **Crea:**

📄 **`web/resources/js/chat.js`** · parte 1 de 2 (líneas 1–39) · empieza el archivo

```js
import { postJson } from './ia';

// La pantalla del asistente.
// Cada mensaje: { id, de: 'usuario' | 'ia', texto, estado: null | 'cargando' | 'error' }
export default ({ url, mensajes }) => ({
    mensajes: mensajes.map((m, i) => ({
        id: i + 1,
        de: m.role === 'user' ? 'usuario' : 'ia',
        texto: m.content,
        estado: null,
    })),
    texto: '',
    caida: false,

    init() {
        this.bajar();
    },

    get ocupado() {
        return this.mensajes.some((m) => m.estado === 'cargando');
    },

    // --- Enviar una pregunta ---
    enviar(pregunta = this.texto) {
        pregunta = pregunta.trim();

        if (!pregunta || this.ocupado) {
            return;
        }

        const id = Date.now();

        // Dos burbujas: la pregunta y la respuesta, que parte «pensando».
        this.mensajes.push({ id: id - 1, de: 'usuario', texto: pregunta, estado: null });
        this.mensajes.push({ id, de: 'ia', texto: '', pregunta, estado: 'cargando' });
        this.texto = '';

        this.responder(id);
    },
```

📄 **`web/resources/js/chat.js`** · parte 2 de 2 (líneas 41–66) · sigue debajo de la parte anterior

```js
    // --- Pedir la respuesta (también lo usa «Reintentar») ---
    async responder(id) {
        const burbuja = this.mensajes.find((m) => m.id === id);

        burbuja.estado = 'cargando';
        this.bajar();

        try {
            const datos = await postJson(url, { mensaje: burbuja.pregunta });

            burbuja.texto = datos.respuesta;
            burbuja.estado = null;
            this.caida = false;
        } catch {
            burbuja.estado = 'error';
            this.caida = true;
        }

        this.bajar();
    },

    // Baja el chat hasta el último mensaje.
    bajar() {
        this.$nextTick(() => this.$refs.fin.scrollIntoView({ behavior: 'smooth', block: 'nearest' }));
    },
});
```

**Entiende**
- `mensajes` parte con lo que había en la sesión (por si se recarga la página). El servidor los guarda como `{role, content}`; aquí se convierten a `{id, de, texto, estado}`.
- `get ocupado()` es un dato calculado: es verdadero mientras alguna burbuja esté `cargando`. La vista lo usa para desactivar el botón y las sugerencias.
- `enviar()` agrega **dos** burbujas de inmediato (la pregunta y una respuesta «pensando») y después pide la respuesta. Así la pantalla reacciona al instante, como en el mockup.
- La burbuja de la IA guarda la `pregunta` que la originó. «Reintentar» llama a `responder(id)` y vuelve a enviar esa misma pregunta.
- `caida` cambia el texto de arriba a «Sin conexión con la IA».
- `$refs.fin` es el elemento marcado con `x-ref="fin"`, al final de los mensajes. `$nextTick` espera a que Alpine termine de dibujar antes de bajar.

Agrega el chat a Alpine. **Reemplaza todo** (versión definitiva):

📄 **`web/resources/js/app.js`** · 11 líneas

```js
import Alpine from 'alpinejs';
import chat from './chat';
import ingrediente from './ingrediente';

// Componentes de Alpine que usan las vistas con x-data="chat(...)" e x-data="ingrediente(...)".
Alpine.data('chat', chat);
Alpine.data('ingrediente', ingrediente);

window.Alpine = Alpine;

Alpine.start();
```

## Paso 10 · La pantalla del asistente

En el mockup: `screens/Assistant.tsx`. **Crea:**

📄 **`web/resources/views/asistente/show.blade.php`** · parte 1 de 4 (líneas 1–30) · empieza el archivo

```blade
@extends('layouts.app')

@section('titulo', 'Asistente')

@section('contenido')
    <div class="grid gap-8 lg:grid-cols-[300px_1fr]">
        {{-- --- Columna izquierda (solo en pantallas grandes) --- --}}
        <aside class="hidden space-y-5 lg:block">
            <div>
                <h1 class="text-[32px] leading-tight font-black">Asistente</h1>
                <p class="mt-1 text-charcoal-soft">Respuestas cortas, sin videos de 15 minutos.</p>
            </div>
            @if ($recipe)
                <a href="{{ route('recetas.show', $recipe) }}" class="block overflow-hidden rounded-3xl bg-white shadow-soft">
                    <x-recipe-photo :recipe="$recipe" class="aspect-[16/10] w-full object-cover" />
                    <div class="p-4">
                        <p class="text-xs font-bold tracking-wide text-charcoal-soft uppercase">Hablando sobre</p>
                        <p class="font-display text-lg font-extrabold">{{ $recipe->title }}</p>
                    </div>
                </a>
            @endif
            <div class="rounded-3xl bg-cream-200 p-5 text-sm">
                <p class="font-display font-extrabold">Puedes preguntar cosas como</p>
                <ul class="mt-2 list-disc space-y-1.5 pl-4 text-charcoal-soft">
                    <li>¿Qué hago con arroz, huevo y cebolla?</li>
                    <li>¿Cuánto dura en el refri?</li>
                    <li>Se me pasó de sal, ¿cómo lo arreglo?</li>
                </ul>
            </div>
        </aside>
```

**Entiende**
- `@extends('layouts.app')` usa el layout de Emma (barra de navegación, contenido y avisos), y `@section('titulo', 'Asistente')` llena el título de la pestaña.
- `@if ($recipe)`: la tarjeta «Hablando sobre» solo aparece si se llegó desde una receta. `<x-recipe-photo>` es de Emma (lo escribe hoy en la mañana): si a esta hora no está en `main`, usa por mientras `<img src="{{ $recipe->image }}" alt="" class="aspect-[16/10] w-full object-cover">`.

📄 **`web/resources/views/asistente/show.blade.php`** · parte 2 de 4 (líneas 32–51) · sigue debajo de la parte anterior

```blade
        {{-- --- El chat: su estado vive en resources/js/chat.js --- --}}
        <section
            x-data="chat({ url: @js(route('asistente.send')), mensajes: @js($mensajes) })"
            class="flex h-[calc(100vh-170px)] min-h-[560px] flex-col overflow-hidden rounded-[32px] bg-cream-200/60 ring-1 ring-cream-300 md:h-[calc(100vh-150px)]"
        >
            <header class="flex items-center gap-3 border-b border-cream-300 bg-white/70 px-6 py-4">
                <span class="grid size-11 place-items-center rounded-2xl bg-basil-500 text-white"><x-icon name="sparkle" size="22" /></span>
                <div class="flex-1">
                    <p class="font-display text-lg font-extrabold">Asistente YouCook</p>
                    <p class="flex items-center gap-1.5 text-xs font-semibold text-basil-600" :class="{ 'text-tomato-600': caida, 'text-basil-600': ! caida }">
                        <span class="size-2 rounded-full bg-basil-500" :class="{ 'bg-tomato-500': caida, 'bg-basil-500': ! caida }"></span>
                        <span x-text="caida ? 'Sin conexión con la IA' : 'En línea · responde en segundos'">En línea · responde en segundos</span>
                    </p>
                </div>
                <form method="POST" action="{{ route('asistente.reset') }}">
                    @csrf
                    @method('DELETE')
                    <button class="rounded-full px-3 py-1.5 text-sm font-semibold text-charcoal-soft hover:bg-cream-200">Nueva conversación</button>
                </form>
            </header>
```

**Entiende**
- `x-data="chat({...})"` entrega al componente la URL y los mensajes guardados. Todo lo que está dentro de esta `<section>` puede usar `mensajes`, `texto`, `caida`, `enviar()`…
- El texto «En línea» está escrito dos veces: dentro de la etiqueta (lo que se ve antes de que Alpine cargue) y en `x-text` (lo que Alpine pone después).
- «Nueva conversación» es un formulario. HTML solo sabe enviar `GET` y `POST`: `@method('DELETE')` agrega un campo oculto para que Laravel lo trate como `DELETE`.

📄 **`web/resources/views/asistente/show.blade.php`** · parte 3 de 4 (líneas 53–103) · sigue debajo de la parte anterior

```blade
            {{-- --- Mensajes --- --}}
            <div class="flex-1 space-y-5 overflow-y-auto px-4 py-6 md:px-8" aria-live="polite">
                <p class="mx-auto w-fit rounded-full bg-white/80 px-3 py-1 text-xs text-charcoal-soft">Hoy, {{ now()->format('H:i') }}</p>

                {{-- El saludo siempre va primero y no se guarda en la conversación. --}}
                <div class="flex gap-3">
                    <span class="grid size-[34px] shrink-0 place-items-center rounded-full bg-basil-500 text-white"><x-icon name="sparkle" size="17" /></span>
                    <p class="max-w-[78%] rounded-3xl rounded-bl-md bg-white px-5 py-3 text-[15px] leading-relaxed shadow-soft">
                        ¡Hola, {{ auth()->user()->first_name }}! Soy tu asistente de cocina.
                        @if ($recipe)
                            Estás viendo {{ mb_strtolower($recipe->title) }}: pregúntame lo que necesites, te respondo corto y al grano.
                        @else
                            Cuéntame qué tienes en el refri o pregúntame lo que necesites: te respondo corto y al grano.
                        @endif
                    </p>
                </div>

                <template x-for="m in mensajes" :key="m.id">
                    <div>
                        {{-- Burbuja de la persona --}}
                        <div x-show="m.de === 'usuario'" class="rise flex justify-end gap-3">
                            <p class="max-w-[78%] rounded-3xl rounded-br-md bg-tomato-500 px-5 py-3 text-[15px] leading-relaxed text-white" x-text="m.texto"></p>
                            <x-avatar size="34" />
                        </div>

                        {{-- Burbuja de la IA: pensando, error o respuesta --}}
                        <div x-show="m.de === 'ia'" class="rise flex gap-3">
                            <span class="grid size-[34px] shrink-0 place-items-center rounded-full bg-basil-500 text-white"><x-icon name="sparkle" size="17" /></span>
                            <div
                                class="max-w-[78%] rounded-3xl rounded-bl-md px-5 py-3 text-[15px] leading-relaxed"
                                :class="m.estado === 'error' ? 'border border-tomato-100 bg-tomato-50/60' : 'bg-white shadow-soft'"
                            >
                                <span x-show="m.estado === 'cargando'" role="status" class="flex items-center gap-3 py-1 text-sm text-charcoal-soft">
                                    <span class="flex gap-1">
                                        <span class="dot size-2 rounded-full bg-basil-500"></span>
                                        <span class="dot size-2 rounded-full bg-basil-500 [animation-delay:.15s]"></span>
                                        <span class="dot size-2 rounded-full bg-basil-500 [animation-delay:.3s]"></span>
                                    </span>
                                    Pensando la respuesta…
                                </span>
                                <div x-show="m.estado === 'error'">
                                    <x-ia-error x-on:click="responder(m.id)" />
                                </div>
                                <span x-show="! m.estado" class="whitespace-pre-line" x-text="m.texto"></span>
                            </div>
                        </div>
                    </div>
                </template>

                <div x-ref="fin"></div>
            </div>
```

**Entiende**
- El saludo lo escribe Blade (en el servidor) y no va a la IA. Los demás mensajes los dibuja Alpine con `x-for`.
- Cada mensaje es de la persona o de la IA: se dibujan las dos burbujas y `x-show` deja visible solo la que corresponde.
- La burbuja de la IA tiene tres caras según `m.estado`: `cargando` (puntos), `error` (con «Reintentar», que llama a `responder(m.id)`) o la respuesta.
- `whitespace-pre-line` respeta los saltos de línea que traiga la respuesta.

📄 **`web/resources/views/asistente/show.blade.php`** · parte 4 de 4 (líneas 105–141) · sigue debajo de la parte anterior

```blade
            {{-- --- Sugerencias y caja de texto --- --}}
            <div class="border-t border-cream-300 bg-white px-4 pt-4 pb-3 md:px-6">
                <div class="-mx-1 mb-3 flex gap-2 overflow-x-auto px-1 pb-1">
                    @foreach ($sugerencias as $sugerencia)
                        <button
                            type="button"
                            :disabled="ocupado"
                            x-on:click="enviar(@js($sugerencia))"
                            class="shrink-0 rounded-full border-2 border-basil-100 bg-basil-50 px-4 py-2 text-sm font-semibold text-basil-600 transition hover:border-basil-500 disabled:opacity-50"
                        >
                            {{ $sugerencia }}
                        </button>
                    @endforeach
                </div>
                <form
                    x-on:submit.prevent="enviar()"
                    class="flex items-center gap-2 rounded-2xl border-2 border-cream-300 bg-cream/60 p-1.5 pl-4 focus-within:border-tomato-500"
                >
                    <input
                        name="mensaje"
                        x-model="texto"
                        maxlength="500"
                        autocomplete="off"
                        placeholder="Escribe tu duda de cocina…"
                        class="h-11 flex-1 bg-transparent text-[15px] outline-none placeholder:text-[#B3A99D]"
                    >
                    <button :disabled="! texto.trim() || ocupado" class="grid size-11 place-items-center rounded-xl bg-tomato-500 text-white transition hover:bg-tomato-600 disabled:bg-cream-300" aria-label="Enviar">
                        <x-icon name="send" size="19" />
                    </button>
                </form>
                <p class="mt-2.5 flex items-center justify-center gap-1.5 text-xs text-charcoal-soft">
                    <x-icon name="info" size="13" /> La IA puede equivocarse. Verifica alérgenos y tiempos de cocción.
                </p>
            </div>
        </section>
    </div>
@endsection
```

**Entiende**
- Las sugerencias vienen del controlador (`$sugerencias`) y cambian según haya receta o no. `@js($sugerencia)` pasa el texto a JavaScript con sus comillas bien escapadas.
- `x-on:submit.prevent="enviar()"`: al enviar el formulario (Enter o el botón), se ejecuta `enviar()` y `.prevent` evita que la página se recargue.
- `x-model="texto"` une el campo con el dato: lo que se escribe queda en `texto`, y cuando `enviar()` lo vacía, el campo se vacía.
- `:disabled="! texto.trim() || ocupado"`: no se puede enviar un mensaje vacío ni dos a la vez.

## Paso 11 · Pruebas

Necesitas las factories de Miguel (`Recipe::factory()`), que llegan a las 10:00.

Abre `tests/Feature/AsistenteIATest.php`. **Borra la `}` final** y sigue debajo:

📄 **`web/tests/Feature/AsistenteIATest.php`** · parte 2 de 2 (líneas 80–121) · sigue debajo de la parte anterior

```php
    // --- Día 2: reemplazos y conversación ---
    public function test_alternativas_devuelve_una_por_linea_y_sin_vinetas(): void
    {
        $recipe = Recipe::factory()->create(['title' => 'Charquicán']);
        $zapallo = Ingredient::factory()->for($recipe)->create(['name' => 'Zapallo', 'quantity' => '300 g']);
        Http::fake(['api.groq.com/*' => Http::response($this->respuesta(
            "- Sin Zapallo → zanahoria rallada (2 unidades)\n\n2. Sin Zapallo → 1 papa más"
        ))]);

        $alternativas = app(AsistenteIA::class)->alternativas($recipe, $zapallo);

        $this->assertSame([
            'Sin Zapallo → zanahoria rallada (2 unidades)',
            'Sin Zapallo → 1 papa más',
        ], $alternativas);
        Http::assertSent(fn (Request $request) => str_contains($request['messages'][1]['content'], 'Zapallo (300 g)')
            && str_contains($request['messages'][1]['content'], 'Charquicán'));
    }

    public function test_conversar_envia_las_reglas_la_receta_y_el_historial(): void
    {
        $recipe = Recipe::factory()->create(['title' => 'Charquicán']);
        Http::fake(['api.groq.com/*' => Http::response($this->respuesta('Unos 15 minutos.'))]);

        $texto = app(AsistenteIA::class)->conversar(
            [['role' => 'user', 'content' => '¿Cuánto se demora?']],
            $recipe,
            'Camila',
        );

        $this->assertSame('Unos 15 minutos.', $texto);
        Http::assertSent(function (Request $request) {
            [$sistema, $pregunta] = $request['messages'];

            return $sistema['role'] === 'system'
                && str_contains($sistema['content'], 'YouCook')
                && str_contains($sistema['content'], 'Camila')
                && str_contains($sistema['content'], 'Charquicán')
                && $pregunta['content'] === '¿Cuánto se demora?';
        });
    }
}
```

Y las pruebas de las rutas. **Crea:**

📄 **`web/tests/Feature/AssistantTest.php`** · 136 líneas

```php
<?php

namespace Tests\Feature;

use App\Models\Ingredient;
use App\Models\Recipe;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class AssistantTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        config([
            'services.groq.key' => 'clave-groq',
        ]);
    }

    private function iaResponde(string $texto): void
    {
        Http::fake(['*' => Http::response(['choices' => [['message' => ['content' => $texto]]]])]);
    }

    public function test_la_pantalla_del_asistente_saluda_por_el_nombre(): void
    {
        $user = User::factory()->create(['name' => 'Camila Rojas']);

        $this->actingAs($user)->get('/asistente')
            ->assertOk()
            ->assertSee('¡Hola, Camila!');
    }

    public function test_llegar_desde_una_receta_la_deja_como_tema(): void
    {
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create(['slug' => 'charquican', 'title' => 'Charquicán']);

        $this->actingAs($user)->get('/asistente?receta=charquican')
            ->assertOk()
            ->assertSee('Hablando sobre')
            ->assertSessionHas('asistente.receta_id', $recipe->id);
    }

    public function test_enviar_un_mensaje_responde_y_guarda_la_conversacion(): void
    {
        $this->iaResponde('Sí, hasta 2 meses.');
        $user = User::factory()->create();

        $this->actingAs($user)->postJson('/asistente', ['mensaje' => '¿Puedo congelarlo?'])
            ->assertOk()
            ->assertExactJson(['respuesta' => 'Sí, hasta 2 meses.'])
            ->assertSessionHas('asistente.mensajes', [
                ['role' => 'user', 'content' => '¿Puedo congelarlo?'],
                ['role' => 'assistant', 'content' => 'Sí, hasta 2 meses.'],
            ]);
    }

    public function test_un_mensaje_vacio_no_se_envia_a_la_ia(): void
    {
        Http::fake();
        $user = User::factory()->create();

        $this->actingAs($user)->postJson('/asistente', ['mensaje' => ''])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('mensaje');

        Http::assertNothingSent();
    }

    public function test_si_la_ia_no_responde_devuelve_503_y_no_guarda_nada(): void
    {
        Http::fake(['*' => Http::response('Error', 500)]);
        $user = User::factory()->create();

        $this->actingAs($user)->postJson('/asistente', ['mensaje' => 'Hola'])
            ->assertStatus(503)
            ->assertSessionMissing('asistente.mensajes');
    }

    public function test_nueva_conversacion_borra_los_mensajes(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession(['asistente' => ['receta_id' => null, 'mensajes' => [['role' => 'user', 'content' => 'Hola']]]])
            ->delete('/asistente')
            ->assertRedirect('/asistente')
            ->assertSessionMissing('asistente.mensajes');
    }

    public function test_no_lo_tengo_devuelve_alternativas_y_las_guarda_en_cache(): void
    {
        $this->iaResponde("Sin zapallo → zanahoria rallada\nSin zapallo → una papa más");
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create();
        $ingredient = Ingredient::factory()->for($recipe)->create(['name' => 'Zapallo']);
        $url = "/recetas/{$recipe->slug}/ingredientes/{$ingredient->id}/alternativas";

        $this->actingAs($user)->postJson($url)
            ->assertOk()
            ->assertExactJson(['alternativas' => ['Sin zapallo → zanahoria rallada', 'Sin zapallo → una papa más']]);

        // La segunda vez responde la caché: no hay otra llamada a la API.
        $this->actingAs($user)->postJson($url)->assertOk();
        Http::assertSentCount(1);
    }

    public function test_alternativas_con_la_ia_caida_devuelve_503(): void
    {
        Http::fake(['*' => Http::response('Error', 500)]);
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create();
        $ingredient = Ingredient::factory()->for($recipe)->create();

        $this->actingAs($user)
            ->postJson("/recetas/{$recipe->slug}/ingredientes/{$ingredient->id}/alternativas")
            ->assertStatus(503);
    }

    public function test_un_ingrediente_de_otra_receta_responde_404(): void
    {
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create();
        $ajeno = Ingredient::factory()->create();

        $this->actingAs($user)
            ->postJson("/recetas/{$recipe->slug}/ingredientes/{$ajeno->id}/alternativas")
            ->assertNotFound();
    }
}
```

```bash
php artisan test     # 36 pruebas en verde si ya está integrado todo lo de hoy
```

**Entiende**
- `actingAs($user)` hace la petición como si esa persona hubiera iniciado sesión. `postJson` envía JSON, igual que nuestro `fetch`.
- `test_no_lo_tengo_devuelve_alternativas_y_las_guarda_en_cache` llama dos veces a la ruta y comprueba que a la IA se le preguntó **una sola vez**.
- `test_si_la_ia_no_responde_devuelve_503_y_no_guarda_nada` es la base de «Reintentar»: la pregunta fallida no queda en la conversación.
- `test_un_ingrediente_de_otra_receta_responde_404` prueba `scopeBindings()`.

## Paso 12 · Prueba con la IA real

Con la clave de Groq en tu `.env`, `php artisan serve` y `npm run dev`:

- [ ] `php artisan ia:probar` responde con Groq.
- [ ] En `/recetas/charquican`, «No lo tengo» en el zapallo muestra 2 reemplazos con sentido. Al cerrar y volver a pedir, responde al instante (caché).
- [ ] En `/asistente?receta=charquican`: el saludo nombra el charquicán; una sugerencia y una pregunta escrita reciben respuestas cortas y en español.
- [ ] Pregunta algo que no sea de cocina («¿quién ganó el mundial?»): debe negarse.
- [ ] Recarga la página: la conversación sigue. «Nueva conversación» la borra.
- [ ] **Estado de error:** borra `GROQ_API_KEY` de `.env` y repite. Deben verse «El asistente no está disponible», «Reintentar» y «Sin conexión con la IA». Vuelve a poner la clave.
- [ ] Guarda dos capturas de respuestas reales en `docs/evidencia/` (una de alternativas y una del chat).

Si las respuestas salen largas, con Markdown o en otro formato, ajusta el texto de `REGLAS` o el de `alternativas()` y vuelve a probar: es normal tener que afinarlo. Para repetir una pregunta de alternativas que quedó guardada: `php artisan cache:clear`.

## Cierre del día

```bash
vendor/bin/pint && npm run build && php artisan test
git add . && git commit -m "Alternativas con IA y asistente"
git push -u origin sebastian/dia2-asistente
```

- [ ] PR integrado, junto con los de Emma (catálogo y detalle) y Miguel (guardar, cocinada, perfil y textos en español).
- [ ] En `main`: `php artisan migrate:fresh --seed`, entrar como `camila.rojas@uni.cl` / `password` y recorrer todo.
- [ ] Check-in de las 21:00: lista de lo que falta para mañana.
