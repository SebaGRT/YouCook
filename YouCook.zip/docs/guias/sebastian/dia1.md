<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Sebastián · Día 1 (viernes 13): el proyecto desde cero y la conexión con Groq

**Meta del día:** que exista el proyecto Laravel en `main` antes de las 10:30, con el tema del mockup, las cuentas (registro, ingreso y salida, escritos a mano como en la clase 11) y todas las rutas (provisionales), para que Emma y Miguel puedan trabajar en paralelo. En la tarde, la primera respuesta real de Groq.

← [Índice de guías](../README.md) · Siguiente: [Día 2](dia2.md)

## Mapa del día

| Paso | Qué haces | Archivo | Entrega |
|---|---|---|---|
| 1 | Crear el proyecto Laravel | (comandos) | |
| 2 | Instalar Alpine.js | `resources/js/app.js` | |
| 3 | El tema del mockup | `resources/css/app.css`, `vite.config.js` | |
| 4 | Sacar lo que no usamos | (comandos) | |
| 5 | Nombre, idioma, zona horaria y favicon | `.env`, `config/app.php` | |
| 6 | Las cuentas: registro, ingreso, salida y sus pruebas | `AuthController.php`, `routes/auth.php`, `auth/login`, `auth/registro`, `tests/Feature/Auth/*` | |
| 7 | Rutas provisionales y pantalla «En construcción» | `routes/web.php`, `routes/ia.php`, `pendiente.blade.php` | |
| 8 | Verificar y subir | (comandos) | **Esqueleto en `main` (~10:30)** |
| 9 | La clave y la configuración de Groq | `.env`, `config/services.php` | |
| 10 | El servicio que habla con Groq | `app/Services/AsistenteIA.php` | |
| 11 | Comando para probar la conexión | `routes/console.php` | |
| 12 | Pruebas del servicio (sin gastar cuota) | `tests/Feature/AsistenteIATest.php` | **Servicio de IA en PR (fin del día)** |

**Tiempo:** unas 3 h 30 (2 h el esqueleto, 1 h 30 la IA). Lo que más importa es el paso 8: hasta que no subas el esqueleto, nadie más puede empezar.

Antes de partir, lee [cómo leer los bloques de código](../README.md#cómo-leer-los-bloques-de-código).

---

## Paso 1 · Crear el proyecto

Desde la raíz del repo (la carpeta que tiene `docs/` y `mockup/`):

```bash
laravel new web --no-authentication --database=sqlite --phpunit --npm --no-boost
cd web
rm AGENTS.md CLAUDE.md
```

- `--no-authentication`: sin kit de inicio (*starter kit*: «None», como en la clase 9). El registro y el login los escribimos nosotros en el paso 6, igual que en la clase 11.
- `--database=sqlite`: la base de datos es un archivo (`database/database.sqlite`). No hay que instalar ni levantar un servidor de base de datos.
- `--phpunit --npm --no-boost`: pruebas con PHPUnit, dependencias con npm y sin Laravel Boost.
- `AGENTS.md` y `CLAUDE.md` son instrucciones genéricas para asistentes de IA (piden instalar Boost). No las usamos.

Si el comando `laravel` no existe: `composer global require laravel/installer`.

Todo lo que sigue se ejecuta **dentro de `web/`**, y todas las rutas de archivos de las guías parten de ahí.

## Paso 2 · Alpine.js

Lo interactivo de la app (el ojo de la contraseña, «No lo tengo», el chat, el aviso que desaparece solo) lo hacemos con **Alpine.js**, una librería chica de JavaScript que se escribe directo en el HTML. No la vimos en clases: cada guía explica cada atributo de Alpine la primera vez que aparece.

```bash
npm install -D alpinejs
```

**Reemplaza todo** (mañana le agregas dos componentes):

📄 **`web/resources/js/app.js`** · 6 líneas · **versión provisional**

```js
import Alpine from 'alpinejs';

// Alpine se encarga de lo interactivo de las vistas: x-data, x-show, x-on:click.
window.Alpine = Alpine;

Alpine.start();
```

**Entiende**
- `import Alpine from 'alpinejs'` trae la librería que acabas de instalar; `Alpine.start()` la pone a revisar la página.
- Desde ahí, cualquier etiqueta con `x-data="{ ver: false }"` tiene sus propios datos, y `x-show`, `x-on:click` o `:class` reaccionan a ellos. Es lo que en React del mockup era `useState`.
- Vite junta este archivo con todo lo que importa y lo carga en cada página con `@vite(...)`.

## Paso 3 · El tema del mockup

`laravel new` ya trae **Tailwind 4**, la misma versión del mockup: sus colores están definidos con `@theme` y usa clases como `h-13`, `size-9` o `bg-cream/85`. Así podemos copiar las clases del mockup tal cual.

En Tailwind 4 no hay archivo de configuración: todo va en el CSS. **Reemplaza todo** el archivo con el tema del mockup (viene de `mockup/Mockup de YouCook/src/index.css`):

📄 **`web/resources/css/app.css`** · parte 1 de 3 (líneas 1–27) · empieza el archivo

```css
@import 'tailwindcss';

@source '../../vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php';
@source '../../storage/framework/views/*.php';

/* --- Tema: los colores, letras y sombras del mockup --- */
@theme {
    --font-display: 'Nunito', ui-rounded, system-ui, sans-serif;
    --font-sans: 'Inter', system-ui, sans-serif;
    --color-tomato-50: #fff1ec;
    --color-tomato-100: #ffdfd4;
    --color-tomato-200: #ffbea8;
    --color-tomato-500: #e8503a;
    --color-tomato-600: #d23f2a;
    --color-tomato-700: #ad311f;
    --color-cream: #fff8ee;
    --color-cream-200: #f8ecd9;
    --color-cream-300: #efdcc0;
    --color-basil-50: #eef6ee;
    --color-basil-100: #d7ebd8;
    --color-basil-500: #3f8f4e;
    --color-basil-600: #2f7540;
    --color-charcoal: #2e2b28;
    --color-charcoal-soft: #6b645d;
    --shadow-soft: 0 1px 2px rgb(46 43 40 / 0.04), 0 8px 24px -8px rgb(46 43 40 / 0.12);
    --shadow-lift: 0 2px 4px rgb(46 43 40 / 0.05), 0 18px 40px -14px rgb(173 49 31 / 0.28);
}
```

**Entiende**
- Cada variable de `@theme` crea clases. `--color-tomato-500` crea `bg-tomato-500`, `text-tomato-500`, `border-tomato-500`… `--font-display` crea `font-display` y `--shadow-soft` crea `shadow-soft`.
- Las dos líneas `@source` le dicen a Tailwind que también busque clases en las vistas de paginación de Laravel y en las vistas compiladas.
- Tailwind solo genera el CSS de las clases que encuentra escritas en los archivos. Por eso `npm run dev` tiene que estar corriendo mientras se trabaja.

📄 **`web/resources/css/app.css`** · partes 2 a 3 de 3 (líneas 29–67) · sigue debajo de la parte anterior

```css
/* --- Estilos base --- */
@layer base {
    body {
        background: var(--color-cream);
        color: var(--color-charcoal);
        font-family: var(--font-sans);
        -webkit-font-smoothing: antialiased;
    }
    h1, h2, h3, h4 {
        font-family: var(--font-display);
        letter-spacing: -0.01em;
    }
    :focus-visible {
        outline: 3px solid var(--color-tomato-200);
        outline-offset: 2px;
    }
    button:not(:disabled), select {
        cursor: pointer;
    }
    /* Alpine: lo que tiene x-cloak queda oculto hasta que Alpine carga. */
    [x-cloak] {
        display: none !important;
    }
}

/* --- Animaciones --- */
@keyframes bounce-dot { 0%, 80%, 100% { transform: translateY(0); opacity: .4 } 40% { transform: translateY(-5px); opacity: 1 } }
@keyframes shimmer { 0% { background-position: -400px 0 } 100% { background-position: 400px 0 } }
@keyframes pop-in { 0% { transform: scale(.6) rotate(-12deg); opacity: 0 } 70% { transform: scale(1.08) rotate(3deg) } 100% { transform: scale(1) rotate(0); opacity: 1 } }
@keyframes rise { from { transform: translateY(8px); opacity: 0 } to { transform: none; opacity: 1 } }

@utility dot { animation: bounce-dot 1.2s infinite ease-in-out; }
@utility skeleton {
    background: linear-gradient(90deg, #e5efe5 0%, #f6fbf6 50%, #e5efe5 100%);
    background-size: 800px 100%;
    animation: shimmer 1.4s infinite linear;
}
@utility pop { animation: pop-in .6s cubic-bezier(.2,.9,.3,1.3) both; }
@utility rise { animation: rise .35s ease-out both; }
```

**Entiende**
- `@layer base` son los estilos por defecto de las etiquetas: fondo crema, letra Inter y títulos con Nunito. Al estar en una capa, cualquier clase de Tailwind les gana.
- `[x-cloak]` es de Alpine: lo que lleve ese atributo queda oculto hasta que Alpine termina de cargar. Así no se ve un parpadeo de cosas que debían partir escondidas.
- `@utility` crea clases propias: `dot` (puntos que saltan), `skeleton` (línea gris que brilla), `pop` (el sticker que aparece) y `rise` (entrar subiendo). Son las mismas animaciones del mockup.

Ahora Vite. **Reemplaza todo:**

📄 **`web/vite.config.js`** · 27 líneas

```js
import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import { bunny } from 'laravel-vite-plugin/fonts';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
            fonts: [
                bunny('Nunito', {
                    weights: [600, 700, 800, 900],
                }),
                bunny('Inter', {
                    weights: [400, 500, 600],
                }),
            ],
        }),
        tailwindcss(),
    ],
    server: {
        watch: {
            ignored: ['**/storage/framework/views/**'],
        },
    },
});
```

**Entiende**
- Es el archivo que trae Laravel, con nuestras dos fuentes. `bunny(...)` descarga Nunito e Inter al compilar y las sirve desde nuestro propio sitio.
- Para que las fuentes carguen, cada página lleva `@fonts` en su `<head>`, junto a `@vite(...)`.
- `tailwindcss()` es el plugin de Tailwind 4: por eso no hace falta `tailwind.config.js`.

## Paso 4 · Sacar lo que no usamos

No tendremos la portada de Laravel (`/` lleva a las recetas) ni sus pruebas de ejemplo (la de `/` espera la portada y fallaría). Borra:

```bash
rm resources/views/welcome.blade.php
rm tests/Feature/ExampleTest.php tests/Unit/ExampleTest.php
```

## Paso 5 · Nombre, idioma, zona horaria y favicon

En **`.env`** y también en **`.env.example`**, cambia estas tres líneas:

```ini
APP_NAME=YouCook
APP_LOCALE=es
APP_FAKER_LOCALE=es_ES
```

En `config/app.php`, la zona horaria:

```php
'timezone' => 'America/Santiago',
```

El favicon es el del mockup, y `.gitignore` gana dos líneas al final:

```bash
cp "../mockup/Mockup de YouCook/public/favicon.png" public/favicon.png
printf '\n# Página de pruebas visuales de cada integrante\n/resources/views/muestra.blade.php\n' >> .gitignore
```

**Entiende**
- `.env` tiene la configuración de **tu** computador y nunca se sube (está en `.gitignore`). `.env.example` es la plantilla que sí se sube: de ahí Emma y Miguel copian su propio `.env`.
- `APP_LOCALE=es` hace que las fechas salgan en español («Noviembre 2026»). Los mensajes de validación en español los escribe Miguel el sábado.
- Con la zona horaria de Santiago, la hora que muestra el chat es la nuestra y no la de Londres.

## Paso 6 · Las cuentas: registro, ingreso y salida

Es el `AuthController` de la clase 11, con nuestras rutas. La tabla `users` y el modelo `User` ya vienen con Laravel (con el *cast* `'password' => 'hashed'`, que guarda la contraseña encriptada).

```bash
php artisan make:controller AuthController
```

**Reemplaza todo:**

📄 **`web/app/Http/Controllers/AuthController.php`** · 66 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // --- Crear la cuenta ---
    public function mostrarRegistro()
    {
        return view('auth.registro');
    }

    public function registrar(Request $request)
    {
        $datos = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|string|min:8',
        ]);

        $usuario = User::create($datos);

        Auth::login($usuario);
        $request->session()->regenerate();

        return redirect()->route('recetas.index');
    }

    // --- Entrar y salir ---
    public function mostrarLogin()
    {
        return view('auth.login');
    }

    public function entrar(Request $request)
    {
        $credenciales = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if (! Auth::attempt($credenciales, $request->boolean('remember'))) {
            return back()
                ->withErrors(['email' => 'Esas credenciales no coinciden con ninguna cuenta.'])
                ->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()->intended(route('recetas.index'));
    }

    public function salir(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
```

**Entiende**
- `$request->validate([...])` valida antes de hacer nada: si una regla falla, Laravel vuelve al formulario con los errores y el resto del método no se ejecuta. Devuelve **solo** los campos validados, por eso `User::create($datos)` no puede recibir un campo colado desde el navegador.
- `unique:users`: el correo no puede estar ya en la tabla `users`. `min:8`: la contraseña tiene al menos 8 caracteres. El mockup pide la contraseña **una vez**, así que no usamos `confirmed` (que exigiría un segundo campo `password_confirmation`).
- `Auth::login($usuario)` deja la sesión iniciada; `$request->session()->regenerate()` cambia el identificador de la sesión al entrar, para que nadie pueda reusar uno anterior.
- `Auth::attempt($credenciales, $request->boolean('remember'))` busca el correo, compara la contraseña encriptada y, si coinciden, inicia la sesión. El segundo argumento es la casilla «Recordarme»: la sesión dura aunque se cierre el navegador.
- `->onlyInput('email')`: al volver con el error, se conserva el correo escrito, pero nunca la contraseña.
- `redirect()->intended(...)`: si alguien quiso abrir `/perfil` sin sesión, después de entrar vuelve a `/perfil`; si no, va a las recetas.
- `salir` cierra la sesión, la invalida y cambia el código de `@csrf`.

**Crea** el archivo de rutas de las cuentas (lo carga la última línea de `routes/web.php` del paso 7):

📄 **`web/routes/auth.php`** · 16 líneas

```php
<?php

use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

// Las cuentas. Solo para quien NO tiene sesión: el middleware guest.
Route::middleware('guest')->group(function () {
    Route::get('/registro', [AuthController::class, 'mostrarRegistro'])->name('registro');
    Route::post('/registro', [AuthController::class, 'registrar']);
    Route::get('/login', [AuthController::class, 'mostrarLogin'])->name('login');

    // Máximo 6 intentos por minuto: así nadie prueba contraseñas sin parar.
    Route::post('/login', [AuthController::class, 'entrar'])->middleware('throttle:6,1');
});

Route::post('/logout', [AuthController::class, 'salir'])->middleware('auth')->name('logout');
```

**Entiende**
- `middleware('guest')`: solo quien **no** tiene sesión puede ver el registro y el login. Si ya entraste, Laravel te manda a las recetas.
- La ruta `POST` de cada formulario no necesita nombre: el formulario usa `route('registro')` y `route('login')`, que tienen la misma dirección.
- `throttle:6,1`: máximo 6 intentos de ingreso por minuto. Al séptimo, Laravel responde 429 sin revisar la contraseña.
- Salir es un `POST` (no un enlace) con `middleware('auth')`: un enlace en otro sitio no puede cerrarte la sesión.

Las vistas, por ahora **provisionales** (Emma las reemplaza hoy por las del mockup). **Crea** las dos:

📄 **`web/resources/views/auth/login.blade.php`** · 32 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para poder entrar. Emma la reemplaza. --}}
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Iniciar sesión · {{ config('app.name') }}</title>

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="grid min-h-screen place-items-center p-6">
        <main class="w-full max-w-md rounded-3xl bg-white p-8 shadow-soft">
            <h1 class="text-3xl font-black">Iniciar sesión</h1>

            <form method="POST" action="{{ route('login') }}" class="mt-6 space-y-4">
                @csrf

                <input type="email" name="email" value="{{ old('email') }}" placeholder="Correo" required class="w-full rounded-xl border p-3">
                @error('email') <p class="text-sm text-tomato-600">{{ $message }}</p> @enderror

                <input type="password" name="password" placeholder="Contraseña" required class="w-full rounded-xl border p-3">

                <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="remember"> Recordarme</label>

                <button class="w-full rounded-xl bg-tomato-500 p-3 font-bold text-white">Entrar</button>
            </form>

            <p class="mt-6 text-sm">¿No tienes cuenta? <a href="{{ route('registro') }}" class="font-bold underline">Regístrate</a></p>
        </main>
    </body>
</html>
```

📄 **`web/resources/views/auth/registro.blade.php`** · 34 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para poder crear una cuenta. Emma la reemplaza. --}}
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Crear cuenta · {{ config('app.name') }}</title>

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="grid min-h-screen place-items-center p-6">
        <main class="w-full max-w-md rounded-3xl bg-white p-8 shadow-soft">
            <h1 class="text-3xl font-black">Crear cuenta</h1>

            <form method="POST" action="{{ route('registro') }}" class="mt-6 space-y-4">
                @csrf

                <input name="name" value="{{ old('name') }}" placeholder="Nombre" required class="w-full rounded-xl border p-3">
                @error('name') <p class="text-sm text-tomato-600">{{ $message }}</p> @enderror

                <input type="email" name="email" value="{{ old('email') }}" placeholder="Correo" required class="w-full rounded-xl border p-3">
                @error('email') <p class="text-sm text-tomato-600">{{ $message }}</p> @enderror

                <input type="password" name="password" placeholder="Contraseña (mínimo 8)" required class="w-full rounded-xl border p-3">
                @error('password') <p class="text-sm text-tomato-600">{{ $message }}</p> @enderror

                <button class="w-full rounded-xl bg-tomato-500 p-3 font-bold text-white">Crear cuenta</button>
            </form>

            <p class="mt-6 text-sm">¿Ya tienes cuenta? <a href="{{ route('login') }}" class="font-bold underline">Inicia sesión</a></p>
        </main>
    </body>
</html>
```

**Entiende**
- `@error('email') ... @enderror` muestra el mensaje de error de ese campo (en `$message`) si la validación falló.
- `old('email')` recupera lo que la persona escribió.
- Los `name` de los campos (`name`, `email`, `password`, `remember`) son los que lee `AuthController`. Emma tiene que usar los mismos.

Por último, las pruebas de las cuentas. Además de cuidar el login, sirven para que `php artisan test` tenga algo que correr desde el primer commit: sin ninguna prueba, el comando termina con error y corta el `pint && build && test` que todos corren antes de cada commit. **Crea** la carpeta `tests/Feature/Auth/` y los dos archivos:

📄 **`web/tests/Feature/Auth/AuthenticationTest.php`** · 67 líneas

```php
<?php

namespace Tests\Feature\Auth;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_screen_can_be_rendered(): void
    {
        $response = $this->get('/login');

        $response->assertStatus(200);
    }

    public function test_users_can_authenticate_using_the_login_screen(): void
    {
        $user = User::factory()->create();

        $response = $this->post('/login', [
            'email' => $user->email,
            'password' => 'password',
        ]);

        $this->assertAuthenticated();
        $response->assertRedirect(route('recetas.index', absolute: false));
    }

    public function test_users_can_not_authenticate_with_invalid_password(): void
    {
        $user = User::factory()->create();

        $response = $this->from('/login')->post('/login', [
            'email' => $user->email,
            'password' => 'wrong-password',
        ]);

        $this->assertGuest();
        $response->assertRedirect('/login')->assertSessionHasErrors('email');
    }

    public function test_after_login_goes_back_to_the_page_it_asked_for(): void
    {
        $user = User::factory()->create();

        $this->get('/perfil')->assertRedirect('/login');

        $this->post('/login', [
            'email' => $user->email,
            'password' => 'password',
        ])->assertRedirect('/perfil');
    }

    public function test_users_can_logout(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->post('/logout');

        $this->assertGuest();
        $response->assertRedirect('/login');
    }
}
```

📄 **`web/tests/Feature/Auth/RegistrationTest.php`** · 57 líneas

```php
<?php

namespace Tests\Feature\Auth;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RegistrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_registration_screen_can_be_rendered(): void
    {
        $response = $this->get('/registro');

        $response->assertStatus(200);
    }

    public function test_new_users_can_register(): void
    {
        $response = $this->post('/registro', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => 'password',
        ]);

        $this->assertAuthenticated();
        $response->assertRedirect(route('recetas.index', absolute: false));
    }

    public function test_the_password_needs_at_least_8_characters(): void
    {
        $this->from('/registro')->post('/registro', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => '1234',
        ])->assertSessionHasErrors('password');

        $this->assertGuest();
    }

    public function test_the_email_can_not_be_used_twice(): void
    {
        $this->post('/registro', [
            'name' => 'Otra Persona',
            'email' => 'camila@uni.cl',
            'password' => 'password',
        ]);
        auth()->logout();

        $this->from('/registro')->post('/registro', [
            'name' => 'Camila Rojas',
            'email' => 'camila@uni.cl',
            'password' => 'password',
        ])->assertSessionHasErrors('email');
    }
}
```

**Entiende**
- Cada método `test_…` es una prueba. `$this->get(...)` y `$this->post(...)` hacen una petición como el navegador, sin levantar el servidor; `RefreshDatabase` deja la base vacía antes de cada una.
- `assertAuthenticated()` y `assertGuest()` preguntan si quedó una sesión iniciada o no.
- `test_after_login_goes_back_to_the_page_it_asked_for`: quien abre `/perfil` sin sesión va a `/login` y, después de entrar, vuelve a `/perfil` (es el `redirect()->intended(...)`). Hoy `/perfil` es provisional, y la prueba funciona igual.
- Las de registro revisan las dos reglas que más importan: contraseña de al menos 8 caracteres y correo que no se repite (`unique:users`).
- `User::factory()->create()` crea una persona con la contraseña `password` (viene en `database/factories/UserFactory.php`).

## Paso 7 · Rutas provisionales y pantalla «En construcción»

Todas las rutas de la app existen **desde hoy**, aunque todavía no hagan nada. Así, cuando Emma escriba `route('recetas.guardar', $recipe)` en una vista, la ruta ya existe y la página no falla. **Reemplaza todo:**

📄 **`web/routes/web.php`** · 28 líneas · **versión provisional**

```php
<?php

use Illuminate\Support\Facades\Route;

Route::redirect('/', '/recetas');

// Rutas provisionales: existen desde el primer día para que los enlaces y los
// formularios de todos funcionen. Miguel reemplaza cada una por su controlador.
Route::middleware('auth')->group(function () {
    Route::view('/recetas', 'pendiente')->name('recetas.index');
    Route::view('/recetas/{recipe}', 'pendiente')->name('recetas.show');
    Route::post('/recetas/{recipe}/guardar', fn () => back())->name('recetas.guardar');
    Route::post('/recetas/{recipe}/cocinada', fn () => back())->name('recetas.cocinada');

    Route::view('/guardados', 'pendiente')->name('guardados.index');

    Route::view('/perfil', 'pendiente')->name('perfil.show');
    Route::patch('/perfil', fn () => back())->name('perfil.update');
});

// Página de pruebas visuales, solo en tu computador: crea
// resources/views/muestra.blade.php (está en .gitignore y no se sube).
if (app()->isLocal()) {
    Route::view('/muestra', 'muestra')->middleware('auth');
}

require __DIR__.'/ia.php';
require __DIR__.'/auth.php';
```

**Entiende**
- `->name('recetas.index')` le pone nombre a la ruta. En las vistas se usa `route('recetas.index')` en vez de escribir la URL a mano: si mañana cambia la URL, no hay que tocar ninguna vista.
- `middleware('auth')`: todo lo que está dentro del grupo exige haber iniciado sesión. Si no, Laravel redirige a la ruta llamada `login`.
- `Route::view(url, vista)` muestra una vista sin pasar por un controlador. `fn () => back()` es una ruta que solo devuelve a la página anterior.
- `{recipe}` es un parámetro: `/recetas/charquican`. Cuando Miguel conecte el controlador, Laravel buscará sola la receta con ese slug.
- `/muestra` solo existe en tu computador (`isLocal()`): es para mirar componentes sueltos mientras se construyen.
- `require __DIR__.'/auth.php'` suma las rutas de las cuentas del paso 6.

**Crea** el archivo de rutas de la IA (tuyo; mañana lo reemplazas por el definitivo):

📄 **`web/routes/ia.php`** · 15 líneas · **versión provisional**

```php
<?php

use Illuminate\Support\Facades\Route;

// Rutas provisionales del asistente: Sebastián las reemplaza el sábado.
Route::middleware('auth')->group(function () {
    Route::view('/asistente', 'pendiente')->name('asistente.show');
    Route::delete('/asistente', fn () => back())->name('asistente.reset');

    Route::post('/asistente', fn () => response()->json(['error' => 'Todavía no hay IA.'], 503))
        ->name('asistente.send');

    Route::post('/recetas/{recipe}/ingredientes/{ingredient}/alternativas', fn () => response()->json(['error' => 'Todavía no hay IA.'], 503))
        ->name('recetas.alternativas');
});
```

Y **crea** la pantalla que muestran todas las rutas provisionales:

📄 **`web/resources/views/pendiente.blade.php`** · 29 líneas · **versión provisional**

```blade
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>En construcción · {{ config('app.name') }}</title>

        @fonts
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="grid min-h-screen place-items-center p-6">
        <main class="w-full max-w-md rounded-3xl bg-white p-8 text-center shadow-soft">
            <p class="font-display text-sm font-extrabold tracking-wider text-tomato-600 uppercase">YouCook</p>
            <h1 class="mt-2 text-3xl font-black">En construcción</h1>
            <p class="mt-2 text-charcoal-soft">Esta pantalla todavía no existe: <code>/{{ request()->path() }}</code></p>

            <nav class="mt-6 flex flex-wrap justify-center gap-2 text-sm font-bold">
                @foreach (['recetas.index' => 'Recetas', 'guardados.index' => 'Guardados', 'asistente.show' => 'Asistente', 'perfil.show' => 'Perfil'] as $ruta => $nombre)
                    <a href="{{ route($ruta) }}" class="rounded-full bg-cream-200 px-4 py-2 hover:bg-tomato-50 hover:text-tomato-600">{{ $nombre }}</a>
                @endforeach
            </nav>

            <form method="POST" action="{{ route('logout') }}" class="mt-6">
                @csrf
                <button class="text-sm font-semibold text-charcoal-soft underline">Cerrar sesión ({{ auth()->user()->name }})</button>
            </form>
        </main>
    </body>
</html>
```

**Entiende**
- `{{ ... }}` imprime un valor (escapando el HTML, por seguridad). `@foreach`, `@csrf` y las demás palabras con `@` son directivas de Blade.
- `@csrf` agrega un campo oculto con un código secreto. Laravel rechaza cualquier formulario `POST` que no lo traiga: así otro sitio no puede enviar formularios a nombre tuyo.
- Esta página lleva su propio `<head>` porque el layout todavía no existe. Emma la cambia esta tarde por una versión con `@extends('layouts.app')`.

## Paso 8 · Verificar y subir

```bash
php artisan migrate      # si pregunta por crear database.sqlite, responde «yes»
npm run build
php artisan test         # 9 pruebas en verde
```

Y mirar en el navegador. Igual que en la clase 9, con `composer run dev` se levantan juntos el servidor y Vite; si prefieres verlos por separado, usa **dos terminales** abiertas en `web/`:

```bash
php artisan serve        # terminal 1: el servidor, en http://localhost:8000
npm run dev              # terminal 2: Vite recompila el CSS y el JS al guardar
```

- [ ] `http://localhost:8000` redirige a `/login` (todavía con el formulario provisional).
- [ ] En `/registro` puedes crear una cuenta y llegas a «En construcción», con el fondo crema y la letra Nunito en el título.
- [ ] Una contraseña de 4 letras o un correo repetido muestran el error bajo el campo.
- [ ] Los cuatro enlaces, «Cerrar sesión» y volver a entrar en `/login` funcionan.

Sube a `main` y avisa en el chat: **«Esqueleto en main»**.

```bash
cd ..
git add web
git status               # NO deben aparecer web/vendor, web/node_modules ni web/.env
git commit -m "Esqueleto: Laravel + cuentas + Tailwind 4 + rutas provisionales"
git push
```

---

## Tarde: la conexión con la IA

Rama nueva: `git switch -c sebastian/dia1-ia`. Nada de esto depende de Emma ni de Miguel.

## Paso 9 · La clave y la configuración de Groq

Igual que en el traductor de la clase 9. Saca la clave (es gratis y no pide tarjeta) con la cuenta del grupo:

- **Groq:** <https://console.groq.com/keys> → *Create API Key*. Empieza con `gsk_` y Groq la muestra **una sola vez**.

En **`.env.example`**, agrega al final (sin la clave):

📄 **`web/.env.example`** · agrega este bloque (3 líneas)

```ini
# --- IA (nunca subas las claves al repositorio: .env está en .gitignore) ---
GROQ_API_KEY=
GROQ_MODEL=openai/gpt-oss-20b
```

En **tu `.env`**, agrega lo mismo **con** la clave. Pásasela a Emma y Miguel por mensaje privado: **nunca** por el repositorio (o que cada uno cree la suya).

En `config/services.php`, antes del `];` final:

📄 **`web/config/services.php`** · agrega este bloque (7 líneas)

```php
    // --- YouCook: la IA (Groq) ---
    // La clave y el modelo salen del .env. El código los lee con
    // config('services.groq.key') y config('services.groq.model'), nunca con env().
    'groq' => [
        'key' => env('GROQ_API_KEY'),
        'model' => env('GROQ_MODEL', 'openai/gpt-oss-20b'),
    ],
```

Comprueba que llegó:

```bash
php artisan config:show services.groq
```

**Entiende**
- `env('GROQ_API_KEY')` lee el valor de `.env`, y `config/services.php` lo lleva a la configuración de la app. El código nunca usa `env()` directamente: siempre `config('services.groq.key')`. Si borras la entrada `'groq'`, `config:show` dice que no existe y la clave nunca llega al código.
- `openai/gpt-oss-20b` es un modelo rápido del plan gratuito (el mismo de la clase). Cambiar de modelo es cambiar `GROQ_MODEL` en `.env`, sin tocar código.
- Groq retira modelos de vez en cuando (los Llama que ofrecía se retiraron en agosto de 2026): si un día contesta `model_not_found`, elige uno vigente en <https://console.groq.com/docs/models>.

## Paso 10 · El servicio que habla con Groq

Primero, la excepción propia. **Crea:**

📄 **`web/app/Exceptions/IaNoDisponible.php`** · 8 líneas

```php
<?php

namespace App\Exceptions;

use RuntimeException;

// Se lanza cuando Groq no pudo responder (sin clave, sin internet o con error).
class IaNoDisponible extends RuntimeException {}
```

Ahora el servicio. Hoy escribes las dos primeras partes (las reglas y la llamada); mañana, las preguntas. **Crea:**

📄 **`web/app/Services/AsistenteIA.php`** · partes 1 a 2 de 5 (líneas 1–72) · empieza el archivo · la `}` final cierra la clase por hoy

```php
<?php

namespace App\Services;

use App\Exceptions\IaNoDisponible;
use App\Models\Ingredient;
use App\Models\Recipe;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AsistenteIA
{
    // --- Reglas del asistente ---
    private const REGLAS = <<<'TXT'
    Eres el asistente de cocina de YouCook, una app chilena de recetas simples para estudiantes.
    Responde siempre en español de Chile, en máximo 3 frases cortas y al grano, en texto plano (sin Markdown ni listas).
    Solo hablas de cocina: recetas, ingredientes, reemplazos, técnicas, conservación y seguridad de los alimentos.
    Si te piden otra cosa, responde que solo puedes ayudar con temas de cocina.
    Si un alimento o un reemplazo puede afectar a personas con alergias o intolerancias, adviértelo.
    Si no sabes algo, dilo: no inventes datos.
    TXT;

    // --- Llamada a la API de Groq ---
    /**
     * Le manda los mensajes a Groq y devuelve el texto de la respuesta.
     *
     * @param  array<int, array{role: string, content: string}>  $mensajes
     */
    public function preguntar(array $mensajes): string
    {
        // Sin clave, ni lo intentamos.
        if (blank(config('services.groq.key'))) {
            Log::warning('Falta GROQ_API_KEY en el .env.');

            throw new IaNoDisponible('Falta la clave de Groq.');
        }

        try {
            $respuesta = Http::withToken(config('services.groq.key'))
                ->timeout(20)
                ->post('https://api.groq.com/openai/v1/chat/completions', [
                    'model' => config('services.groq.model'),
                    'messages' => $mensajes,
                    'temperature' => 0.4,
                ]);
        } catch (ConnectionException $e) {
            // Sin internet, o Groq tardó más de 20 segundos.
            Log::error('No se pudo conectar con Groq', ['error' => $e->getMessage()]);

            throw new IaNoDisponible('Groq no respondió.');
        }

        if ($respuesta->failed()) {
            Log::error('Groq devolvió un error', [
                'status' => $respuesta->status(),
                'body' => $respuesta->json(),
            ]);

            throw new IaNoDisponible('Groq devolvió un error.');
        }

        $texto = $respuesta->json('choices.0.message.content');

        if (blank($texto)) {
            Log::warning('Groq respondió sin texto', ['body' => $respuesta->json()]);

            throw new IaNoDisponible('Groq respondió vacío.');
        }

        return trim($texto);
    }
}
```

**Entiende**
- `REGLAS` es el *mensaje de sistema* (el `role` `system` del traductor de la clase 9): las instrucciones que el modelo recibe antes de cada conversación. Ahí están tres de nuestros riesgos: que hable solo de cocina, que advierta sobre alérgenos y que no invente. `<<<'TXT' ... TXT` es un texto de varias líneas (*nowdoc*).
- `preguntar()` es el mismo pedido del traductor: `Http::withToken(config('services.groq.key'))` arma el encabezado `Authorization: Bearer <clave>` y `->post(...)` envía el modelo y los mensajes a `https://api.groq.com/openai/v1/chat/completions`.
- Lo que agregamos al traductor: `blank(config('services.groq.key'))` no llama a Groq si falta la clave (la tarea 3 del ejercicio del traductor), `->timeout(20)` corta la espera a los 20 segundos y `temperature` baja la «creatividad» para que responda parejo.
- `try { ... } catch (ConnectionException $e)`: si no hay internet o Groq no contesta a tiempo, `post()` no devuelve una respuesta sino que **lanza** una excepción. El `catch` la atrapa para que la app no se caiga.
- `$respuesta->failed()` es `true` ante cualquier error de Groq (clave mala 401, límite 429, modelo retirado 404). `Log::error(...)` deja el detalle en `storage/logs/laravel.log`: el primer lugar donde mirar cuando algo falla.
- `->json('choices.0.message.content')` saca el texto de la respuesta: `{"choices": [{"message": {"content": "..."}}]}`.
- En vez de volver al formulario (como el traductor), el servicio lanza `IaNoDisponible`. Los controladores de mañana la atrapan y muestran «El asistente no está disponible», con el botón «Reintentar» del mockup.
- Los `use` de `Ingredient` y `Recipe` todavía no se usan: son para las partes de mañana.

## Paso 11 · Comando para probar la conexión

En `routes/console.php`, agrega arriba dos líneas `use`, junto a las que ya están:

```php
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
```

Y al final del archivo:

📄 **`web/routes/console.php`** · agrega este bloque (28 líneas)

```php
// php artisan ia:probar → le pregunta algo corto a Groq, con la clave y el modelo del .env.
Artisan::command('ia:probar', function () {
    if (blank(config('services.groq.key'))) {
        $this->error('Falta GROQ_API_KEY en el .env.');

        return;
    }

    $modelo = config('services.groq.model');
    $inicio = microtime(true);

    $respuesta = Http::withToken(config('services.groq.key'))
        ->timeout(20)
        ->post('https://api.groq.com/openai/v1/chat/completions', [
            'model' => $modelo,
            'messages' => [['role' => 'user', 'content' => 'Responde solo con la palabra: listo']],
        ]);

    $segundos = round(microtime(true) - $inicio, 1);

    if ($respuesta->failed()) {
        $this->error("Groq ({$modelo}): error {$respuesta->status()} · ".Str::limit($respuesta->body(), 200));

        return;
    }

    $this->info("Groq ({$modelo}): «{$respuesta->json('choices.0.message.content')}» en {$segundos} s");
})->purpose('Prueba la conexión con Groq');
```

Pruébalo con tu clave:

```bash
php artisan ia:probar
```

Debería responder algo así:

```text
Groq (openai/gpt-oss-20b): «listo» en 0.6 s
```

**Si da error 404 o 400**, lo más probable es que el modelo ya no exista. Pide la lista de modelos vigentes y pon uno en `GROQ_MODEL` de tu `.env` (y en `.env.example`, y avisa en el chat):

```bash
curl -s https://api.groq.com/openai/v1/models -H "Authorization: Bearer TU_CLAVE_GROQ"
```

**Error 401:** la clave está mal copiada. **Error 429:** se acabó el límite gratis por ahora (el plan gratuito da unas 1.000 consultas al día y 8.000 *tokens* por minuto); anota a qué hora pasó.

Y una pregunta de verdad, usando el servicio:

```bash
php artisan tinker --execute="echo app(App\Services\AsistenteIA::class)->preguntar([['role' => 'user', 'content' => 'No tengo zapallo para el charquicán. ¿Con qué lo reemplazo?']]);"
```

> ⚠️ Los nombres de modelo y la conexión real **no se pudieron probar al preparar esta guía** (no había claves). Este paso es justamente esa prueba: si algo no calza, corrígelo aquí.

## Paso 12 · Pruebas del servicio

Las pruebas no llaman a la API real: `Http::fake()` responde en su lugar. Así no gastan cuota y funcionan sin internet. Hoy escribes las cuatro primeras. **Crea:**

📄 **`web/tests/Feature/AsistenteIATest.php`** · parte 1 de 2 (líneas 1–78) · empieza el archivo · la `}` final cierra la clase por hoy

```php
<?php

namespace Tests\Feature;

use App\Exceptions\IaNoDisponible;
use App\Models\Ingredient;
use App\Models\Recipe;
use App\Services\AsistenteIA;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

// Ninguna prueba llama a la API real: Http::fake() responde en lugar de Groq.
class AsistenteIATest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        config([
            'services.groq.key' => 'clave-groq',
            'services.groq.model' => 'openai/gpt-oss-20b',
        ]);
    }

    private function respuesta(string $texto): array
    {
        return ['choices' => [['message' => ['role' => 'assistant', 'content' => $texto]]]];
    }

    // --- Día 1: la llamada a la API ---
    public function test_le_pregunta_a_groq_con_la_clave_y_el_modelo(): void
    {
        Http::fake(['api.groq.com/*' => Http::response($this->respuesta('Sí, queda bien.'))]);

        $texto = app(AsistenteIA::class)->preguntar([['role' => 'user', 'content' => 'Hola']]);

        $this->assertSame('Sí, queda bien.', $texto);
        Http::assertSentCount(1);
        Http::assertSent(fn (Request $request) => $request->url() === 'https://api.groq.com/openai/v1/chat/completions'
            && $request->hasHeader('Authorization', 'Bearer clave-groq')
            && $request['model'] === 'openai/gpt-oss-20b'
            && $request['messages'][0]['content'] === 'Hola');
    }

    public function test_si_groq_devuelve_un_error_lanza_ia_no_disponible(): void
    {
        Http::fake(['api.groq.com/*' => Http::response(['error' => 'rate limit'], 429)]);

        $this->expectException(IaNoDisponible::class);

        app(AsistenteIA::class)->preguntar([['role' => 'user', 'content' => 'Hola']]);
    }

    public function test_si_groq_responde_vacio_lanza_ia_no_disponible(): void
    {
        Http::fake(['api.groq.com/*' => Http::response($this->respuesta('   '))]);

        $this->expectException(IaNoDisponible::class);

        app(AsistenteIA::class)->preguntar([['role' => 'user', 'content' => 'Hola']]);
    }

    public function test_sin_clave_no_llama_a_groq(): void
    {
        config(['services.groq.key' => null]);
        Http::fake();

        try {
            app(AsistenteIA::class)->preguntar([['role' => 'user', 'content' => 'Hola']]);
            $this->fail('Debió lanzar IaNoDisponible.');
        } catch (IaNoDisponible) {
            Http::assertNothingSent();
        }
    }
}
```

```bash
php artisan test --filter=AsistenteIATest     # 4 pruebas en verde
```

**Entiende**
- `setUp()` se ejecuta antes de cada prueba. Pone una clave falsa con `config([...])`, así la prueba no depende de tu `.env`.
- `Http::fake([...])` recibe «para esta URL, responde esto». `Http::assertSent(...)` revisa lo que se envió: la dirección de Groq, la clave, el modelo y el mensaje.
- Las otras tres simulan lo que puede salir mal: Groq sin cuota (error 429), una respuesta vacía y la clave que falta (`Http::assertNothingSent()`: ni siquiera se intentó). En los tres casos el servicio lanza `IaNoDisponible`.
- Los `use` de `Ingredient` y `Recipe` son para las pruebas de mañana.

## Cierre del día

```bash
vendor/bin/pint            # ordena el formato del código PHP
php artisan test           # 13 pruebas en verde
git add . && git commit -m "Servicio de IA con Groq y comando ia:probar"
git push -u origin sebastian/dia1-ia
```

- [ ] PR abierto e integrado por ti mismo (no hay conflictos: son archivos nuevos).
- [ ] Integrados los PR de Miguel (modelos, recetas, catálogo provisional) y de Emma (ingreso, registro y barra de navegación), en el orden en que llegaron.
- [ ] Después de integrar: `git pull && composer install && npm install && php artisan migrate:fresh --seed && php artisan test`.
- [ ] Check-in de las 21:00: ¿quedó algo de hoy para mañana?
