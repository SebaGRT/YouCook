<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Miguel · Día 1 (viernes 13): la base de datos, los modelos y las 20 recetas

**Meta del día:** que las recetas vivan en la base de datos y que `/recetas` y `/recetas/charquican` muestren datos reales (todavía sin diseño: eso es de Emma).

← [Índice de guías](../README.md) · Siguiente: [Día 2](dia2.md)

## Mapa del día

| Paso | Qué haces | Archivo | Entrega |
|---|---|---|---|
| 0 | Clonar y dejar el proyecto andando | (comandos) | Necesita el esqueleto de Sebastián (~10:30) |
| 1 | Tablas de recetas e ingredientes | `database/migrations/…create_recipes_table.php` | |
| 2 | Tablas de guardadas y cocinadas | `database/migrations/…create_saved_and_cooked_recipes_tables.php` | |
| 3 | Modelos `Recipe` e `Ingredient` | `app/Models/Recipe.php`, `Ingredient.php` | |
| 4 | Relaciones y atributos de `User` | `app/Models/User.php` | **📣 PR 1 a las 13:00 (Emma lo espera)** |
| 5 | Las 20 recetas | `database/data/recetas.php` | |
| 6 | Seeders | `RecipeSeeder.php`, `DatabaseSeeder.php` | **PR 2 a las 15:00** |
| 7 | Controlador del catálogo | `app/Http/Controllers/RecipeController.php` | |
| 8 | Rutas del catálogo | `routes/web.php` | |
| 9 | Vistas provisionales | `recetas/index.blade.php`, `recetas/show.blade.php` | **PR 3 (fin del día)** |

**Tiempo:** unas 3 h 30 (~450 líneas escritas; los datos del paso 5 se copian). Antes de empezar, lee [cómo leer los bloques de código](../README.md#cómo-leer-los-bloques-de-código).

Mientras esperas el esqueleto puedes adelantar leyendo `mockup/Mockup de YouCook/src/data.ts`: de ahí salen las tablas.

---

## Paso 0 · Clonar y dejar el proyecto andando

Cuando Sebastián avise «Esqueleto en main»:

```bash
git clone <url-del-repo> && cd YouCook/web
composer install
npm install
cp .env.example .env
php artisan key:generate
php artisan migrate          # responde «yes» si pregunta por crear database.sqlite
git switch -c miguel/dia1-modelos
```

Para trabajar, dos terminales en `web/`: `php artisan serve` y `npm run dev`.

## Paso 1 · Tablas de recetas e ingredientes

```bash
php artisan make:migration create_recipes_table
```

Se crea un archivo en `database/migrations/` con la fecha en el nombre. **Reemplaza todo** su contenido:

📄 **`web/database/migrations/(fecha)_create_recipes_table.php`** · 44 líneas

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('recipes', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('title');
            $table->string('category');
            $table->unsignedSmallInteger('minutes');
            $table->string('difficulty');
            $table->unsignedTinyInteger('servings');
            $table->unsignedInteger('cost');
            $table->string('image')->nullable();
            $table->text('description');
            $table->json('allergens');
            $table->json('steps');
            $table->string('sticker');
            $table->string('sticker_name');
            $table->timestamps();
        });

        Schema::create('ingredients', function (Blueprint $table) {
            $table->id();
            $table->foreignId('recipe_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('quantity');
            $table->unsignedTinyInteger('position');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ingredients');
        Schema::dropIfExists('recipes');
    }
};
```

**Entiende**
- Una migración es la receta para crear tablas: `up()` las crea y `down()` las deshace. Así los tres tenemos la misma base de datos con `php artisan migrate`.
- `slug` es el nombre de la receta para la URL (`charquican`). `unique()` impide que haya dos iguales.
- `cost` es un número (3500), no un texto: el formato «$3.500» se arma al mostrarlo.
- `allergens` y `steps` son listas guardadas como JSON en una columna. Los ingredientes, en cambio, tienen tabla propia porque la IA necesita referirse a **un** ingrediente por su `id`.
- `foreignId('recipe_id')->constrained()->cascadeOnDelete()`: cada ingrediente pertenece a una receta; si se borra la receta, se borran sus ingredientes.

## Paso 2 · Tablas de guardadas y cocinadas

```bash
php artisan make:migration create_saved_and_cooked_recipes_tables
```

**Reemplaza todo:**

📄 **`web/database/migrations/(fecha)_create_saved_and_cooked_recipes_tables.php`** · 27 líneas

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Las dos tablas son iguales: unen a una persona con una receta.
        foreach (['saved_recipes', 'cooked_recipes'] as $name) {
            Schema::create($name, function (Blueprint $table) {
                $table->foreignId('user_id')->constrained()->cascadeOnDelete();
                $table->foreignId('recipe_id')->constrained()->cascadeOnDelete();
                $table->timestamps();
                $table->primary(['user_id', 'recipe_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('cooked_recipes');
        Schema::dropIfExists('saved_recipes');
    }
};
```

**Entiende**
- Son **tablas pivote**: cada fila une a una persona con una receta. Una persona guarda muchas recetas y una receta es guardada por muchas personas (relación «muchos a muchos»).
- `primary(['user_id', 'recipe_id'])`: la pareja no se puede repetir, así que nadie guarda dos veces la misma receta.
- En el mockup esto era `saved: string[]` y `cooked: string[]` en la memoria del navegador (`store.tsx`). Aquí queda guardado por persona.

```bash
php artisan migrate
```

## Paso 3 · Modelos `Recipe` e `Ingredient`

**Crea:**

📄 **`web/app/Models/Recipe.php`** · 63 líneas

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Recipe extends Model
{
    use HasFactory;

    public const CATEGORIES = ['Chilenas', 'Pastas', 'Rápidas', 'Dulces', 'Vegetarianas'];

    public const DIFFICULTIES = ['Fácil', 'Media'];

    protected $fillable = [
        'slug', 'title', 'category', 'minutes', 'difficulty', 'servings', 'cost',
        'image', 'description', 'allergens', 'steps', 'sticker', 'sticker_name',
    ];

    protected function casts(): array
    {
        return [
            'allergens' => 'array',
            'steps' => 'array',
        ];
    }

    // Las URL usan el slug (/recetas/charquican), no el id.
    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function ingredients(): HasMany
    {
        return $this->hasMany(Ingredient::class)->orderBy('position');
    }

    // 3500 → "$3.500"
    protected function costLabel(): Attribute
    {
        return Attribute::get(fn () => '$'.number_format($this->cost, 0, ',', '.'));
    }

    // Filtros del catálogo: Recipe::filter([...])->paginate(8)
    public function scopeFilter(Builder $query, array $filters): void
    {
        $query
            ->when($filters['q'] ?? null, function (Builder $query, string $q) {
                $query->where(function (Builder $query) use ($q) {
                    $query->where('title', 'like', "%{$q}%")
                        ->orWhereHas('ingredients', fn (Builder $query) => $query->where('name', 'like', "%{$q}%"));
                });
            })
            ->when($filters['categoria'] ?? null, fn (Builder $query, string $category) => $query->where('category', $category))
            ->when($filters['tiempo'] ?? null, fn (Builder $query, int|string $minutes) => $query->where('minutes', '<=', (int) $minutes))
            ->when($filters['dificultad'] ?? null, fn (Builder $query, string $difficulty) => $query->where('difficulty', $difficulty));
    }
}
```

**Entiende**
- Un modelo es una clase que representa una tabla: `Recipe` ↔ `recipes` (Laravel deduce el nombre en plural).
- `$fillable` son las columnas que se pueden llenar con `Recipe::create([...])`. Es una protección: nadie puede colar otras columnas desde un formulario.
- `casts()`: `allergens` y `steps` se guardan como JSON y se leen como arreglos de PHP.
- `getRouteKeyName()`: cuando una ruta tiene `{recipe}`, Laravel busca la receta por `slug` en vez de por `id`.
- `ingredients()` es la relación «una receta tiene muchos ingredientes». Se usa como `$recipe->ingredients`.
- `costLabel()` es un atributo calculado: `$recipe->cost_label` devuelve «$3.500».
- `scopeFilter` es un *scope*: un trozo de consulta con nombre. Se usa como `Recipe::filter($filtros)`. Cada `when(valor, función)` agrega su condición **solo si** el filtro viene con valor.
- La búsqueda mira el título **o** el nombre de algún ingrediente (`orWhereHas`), igual que el buscador del mockup. Los valores van como parámetros de la consulta: no hay riesgo de inyección SQL.

📄 **`web/app/Models/Ingredient.php`** · 19 líneas

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Ingredient extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'quantity', 'position'];

    public function recipe(): BelongsTo
    {
        return $this->belongsTo(Recipe::class);
    }
}
```

## Paso 4 · Relaciones y atributos de `User`

**Reemplaza todo** (lo nuevo empieza en la línea `// --- YouCook`. Arriba cambian dos cosas respecto de lo que trae Laravel: tres `use` nuevos, y `$fillable` y `$hidden` escritos como propiedades, igual que en `Recipe.php` y que en la clase 10):

📄 **`web/app/Models/User.php`** · 83 líneas

```php
<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    // Los campos que se pueden llenar de una vez, igual que en Recipe.php.
    protected $fillable = ['name', 'email', 'password'];

    // Los que no salen cuando el objeto se convierte en JSON.
    protected $hidden = ['password', 'remember_token'];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // --- YouCook: recetas guardadas y cocinadas ---

    public function savedRecipes(): BelongsToMany
    {
        return $this->belongsToMany(Recipe::class, 'saved_recipes')->withTimestamps();
    }

    public function cookedRecipes(): BelongsToMany
    {
        return $this->belongsToMany(Recipe::class, 'cooked_recipes')->withTimestamps();
    }

    public function hasSaved(Recipe $recipe): bool
    {
        return $this->savedRecipes()->where('recipe_id', $recipe->id)->exists();
    }

    public function hasCooked(Recipe $recipe): bool
    {
        return $this->cookedRecipes()->where('recipe_id', $recipe->id)->exists();
    }

    // "Camila Rojas" → "Camila"
    protected function firstName(): Attribute
    {
        return Attribute::get(fn () => Str::before($this->name, ' '));
    }

    // "Camila Rojas" → "Camila R."
    protected function shortName(): Attribute
    {
        return Attribute::get(function () {
            $lastName = Str::after($this->name, ' ');

            return $lastName === $this->name
                ? $this->name
                : $this->first_name.' '.Str::upper(Str::substr($lastName, 0, 1)).'.';
        });
    }

    // "Camila Rojas" → "C" (la letra del avatar)
    protected function initial(): Attribute
    {
        return Attribute::get(fn () => Str::upper(Str::substr($this->name, 0, 1)));
    }
}
```

**Entiende**
- `$fillable` son los campos que `User::create([...])` puede llenar (los usa `AuthController` al registrar) y `$hidden` los que nunca salen si el usuario se convierte en JSON. Laravel 13 los trae escritos como atributos (`#[Fillable([...])]`); funcionan igual, pero los dejamos como en clases.
- `belongsToMany(Recipe::class, 'saved_recipes')`: la relación «muchos a muchos» a través de la tabla pivote. `$user->savedRecipes` entrega las recetas guardadas y `$user->savedRecipes()->toggle($recipe)` guarda o quita.
- `hasSaved()` y `hasCooked()` preguntan a la base de datos si existe la pareja, sin traer todas las recetas.
- `first_name`, `short_name` e `initial` son atributos calculados para la interfaz: «Hola, Camila», «Camila R.» y la letra del avatar. En el código se escriben en `camelCase` (`firstName`) y se leen en `snake_case` (`$user->first_name`).

Comprueba que todo calce y sube el **PR 1**:

```bash
php artisan migrate:fresh && php artisan test      # 9 pruebas en verde
git add . && git commit -m "Migraciones y modelos"
git push -u origin miguel/dia1-modelos
```

Avisa: **📣 «Emma: modelos en PR»** (su layout cuenta las guardadas y cocinadas con tus relaciones de `User`).

## Paso 5 · Las 20 recetas

Rama nueva: `git switch -c miguel/dia1-recetas`.

Las 8 primeras son las del mockup (`data.ts`) y las otras 12 completan el reto de 20. **Este archivo es contenido, no código: se puede copiar y pegar.** Lo que sí tienes que entender es la forma de **una** receta. **Crea** `database/data/recetas.php`:

📄 **`web/database/data/recetas.php`** · parte 1 de 5 (líneas 1–123) · empieza el archivo

```php
<?php

// Las 20 recetas de YouCook. Las 8 primeras vienen del mockup (con foto);
// las otras 12 completan el reto de 20 y todavía no tienen foto ('image' => null).
// Cada ingrediente es [nombre, cantidad].

$foto = fn (string $id) => "https://images.unsplash.com/{$id}?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=1200";

return [
    // --- Recetas del mockup (1 a 4) ---
    [
        'slug' => 'charquican',
        'title' => 'Charquicán',
        'category' => 'Chilenas',
        'minutes' => 45,
        'difficulty' => 'Media',
        'servings' => 3,
        'cost' => 3500,
        'image' => $foto('photo-1628606336803-77914bbe8225'),
        'description' => 'El guiso chileno de toda la vida: papas, zapallo y choclo aplastados con carne. Rinde para dos días de almuerzo.',
        'allergens' => ['Huevo (si lo sirves con huevo frito)'],
        'sticker' => 'choclo',
        'sticker_name' => 'Choclito',
        'ingredients' => [
            ['Carne molida', '250 g'],
            ['Papas', '4 medianas'],
            ['Zapallo camote', '300 g'],
            ['Choclo', '1 taza'],
            ['Cebolla', '1 unidad'],
            ['Aceite', '2 cdas'],
            ['Comino y orégano', '1 cdta c/u'],
        ],
        'steps' => [
            'Pela y corta las papas y el zapallo en cubos medianos. Cuécelos en agua con sal por 15 min, hasta que un tenedor entre fácil.',
            'Mientras, pica la cebolla y sofríela en el aceite a fuego medio por 5 min, hasta que esté transparente.',
            'Agrega la carne molida, el comino y el orégano. Cocina revolviendo hasta que la carne cambie de color (unos 7 min).',
            'Suma el choclo y ½ taza del agua de cocción. Deja hervir 3 min.',
            'Escurre papas y zapallo, agrégalos al sartén y aplasta todo con un tenedor, dejando algunos trozos. Ajusta sal.',
            'Sirve caliente. Si quieres, ponle un huevo frito encima.',
        ],
    ],
    [
        'slug' => 'tallarines-salsa',
        'title' => 'Tallarines con salsa de tomate',
        'category' => 'Pastas',
        'minutes' => 25,
        'difficulty' => 'Fácil',
        'servings' => 2,
        'cost' => 2000,
        'image' => $foto('photo-1551892374-ecf8754cf8b0'),
        'description' => 'Salsa casera en el tiempo que hierve el agua. Ideal para la semana de pruebas.',
        'allergens' => ['Gluten', 'Lácteos (queso rallado)'],
        'sticker' => 'tallarin',
        'sticker_name' => 'Fideo feliz',
        'ingredients' => [
            ['Tallarines', '200 g'],
            ['Tomates', '3 maduros'],
            ['Ajo', '2 dientes'],
            ['Aceite de oliva', '2 cdas'],
            ['Queso rallado', 'a gusto'],
        ],
        'steps' => [
            'Pon a hervir 2 litros de agua con sal.',
            'Pica el ajo y ralla o pica los tomates.',
            'Dora el ajo en el aceite 1 min y agrega el tomate. Cocina 10 min a fuego bajo.',
            'Cuece los tallarines según el paquete (8–10 min) y escúrrelos.',
            'Mezcla la pasta con la salsa y sirve con queso.',
        ],
    ],
    [
        'slug' => 'arroz-huevo',
        'title' => 'Arroz con huevo frito',
        'category' => 'Rápidas',
        'minutes' => 20,
        'difficulty' => 'Fácil',
        'servings' => 1,
        'cost' => 900,
        'image' => $foto('photo-1600688654899-379ec76aca42'),
        'description' => 'El clásico salvavidas: barato, rápido y reconfortante.',
        'allergens' => ['Huevo'],
        'sticker' => 'huevo',
        'sticker_name' => 'Huevito',
        'ingredients' => [
            ['Arroz', '½ taza'],
            ['Huevo', '1–2 unidades'],
            ['Aceite', '1 cda'],
            ['Sal', 'a gusto'],
        ],
        'steps' => [
            'Lava el arroz y ponlo en una olla con 1 taza de agua y sal.',
            'Cuando hierva, tapa y baja el fuego al mínimo por 15 min.',
            'Fríe el huevo en aceite caliente hasta que la clara esté blanca y los bordes crujientes.',
            'Sirve el arroz y pon el huevo encima.',
        ],
    ],
    [
        'slug' => 'panqueques',
        'title' => 'Panqueques con manjar',
        'category' => 'Dulces',
        'minutes' => 20,
        'difficulty' => 'Fácil',
        'servings' => 4,
        'cost' => 1800,
        'image' => $foto('photo-1656057205408-4a0a62cf2dfb'),
        'description' => 'Masa de licuadora y a la sartén. Para once o para celebrar que terminó el semestre.',
        'allergens' => ['Gluten', 'Huevo', 'Lácteos'],
        'sticker' => 'panqueque',
        'sticker_name' => 'Torre dulce',
        'ingredients' => [
            ['Harina', '1 taza'],
            ['Leche', '1 ¼ taza'],
            ['Huevos', '2 unidades'],
            ['Mantequilla', '1 cda'],
            ['Manjar', 'a gusto'],
        ],
        'steps' => [
            'Licúa harina, leche, huevos y una pizca de sal hasta que no queden grumos.',
            'Deja reposar la mezcla 5 min.',
            'Calienta un sartén con un poco de mantequilla y vierte un cucharón de masa, girando para cubrir.',
            'Cocina 1 min por lado, hasta que se dore.',
            'Rellena con manjar y enrolla.',
        ],
    ],
```

<details>
<summary>Recetas 5 a 20 (copiar debajo, en el mismo archivo)</summary>

📄 **`web/database/data/recetas.php`** · partes 2 a 5 de 5 (líneas 124–563) · sigue debajo de la parte anterior

```php
    // --- Recetas del mockup (5 a 8) ---
    [
        'slug' => 'lentejas',
        'title' => 'Lentejas guisadas',
        'category' => 'Chilenas',
        'minutes' => 50,
        'difficulty' => 'Media',
        'servings' => 4,
        'cost' => 2500,
        'image' => $foto('photo-1605909388460-74ec8b204127'),
        'description' => 'Rinde un montón, se congela bien y te deja lista para la semana.',
        'allergens' => ['Sin alérgenos comunes'],
        'sticker' => 'olla',
        'sticker_name' => 'Guiso power',
        'ingredients' => [
            ['Lentejas', '1 ½ taza'],
            ['Zanahoria', '1 unidad'],
            ['Cebolla', '1 unidad'],
            ['Arroz', '¼ taza'],
        ],
        'steps' => [
            'Remoja las lentejas por 1 hora (opcional pero ayuda).',
            'Sofríe cebolla y zanahoria picadas 5 min.',
            'Agrega lentejas y 1 litro de agua. Cocina 25 min.',
            'Suma el arroz y cocina 15 min más. Ajusta sal.',
        ],
    ],
    [
        'slug' => 'crema-zapallo',
        'title' => 'Crema de zapallo',
        'category' => 'Vegetarianas',
        'minutes' => 35,
        'difficulty' => 'Fácil',
        'servings' => 3,
        'cost' => 1500,
        'image' => $foto('photo-1680529670101-c8b552219c06'),
        'description' => 'Suave, calentita y con solo 4 ingredientes.',
        'allergens' => ['Lácteos (opcional)'],
        'sticker' => 'zapallo',
        'sticker_name' => 'Zapallín',
        'ingredients' => [
            ['Zapallo', '500 g'],
            ['Papa', '1 unidad'],
            ['Cebolla', '½ unidad'],
            ['Crema o leche', '¼ taza'],
        ],
        'steps' => [
            'Pica todo en cubos y cuécelo en agua con sal 20 min.',
            'Licúa con parte del agua hasta lograr la textura que te guste.',
            'Agrega la crema, ajusta sal y sirve.',
        ],
    ],
    [
        'slug' => 'ensalada-chilena',
        'title' => 'Ensalada chilena con palta',
        'category' => 'Vegetarianas',
        'minutes' => 10,
        'difficulty' => 'Fácil',
        'servings' => 2,
        'cost' => 1700,
        'image' => $foto('photo-1542814880-7e62cf14b7c8'),
        'description' => 'Tomate, cebolla pluma y palta. Sin cocinar, acompaña todo.',
        'allergens' => ['Sin alérgenos comunes'],
        'sticker' => 'palta',
        'sticker_name' => 'Palta zen',
        'ingredients' => [
            ['Tomates', '2 unidades'],
            ['Cebolla', '½ unidad'],
            ['Palta', '1 unidad'],
            ['Cilantro', 'a gusto'],
        ],
        'steps' => [
            'Corta la cebolla en pluma y déjala 5 min en agua fría para quitarle lo picante.',
            'Corta los tomates en gajos y la palta en cubos.',
            'Mezcla todo con aceite, sal y cilantro.',
        ],
    ],
    [
        'slug' => 'bowl-arroz',
        'title' => 'Bowl de arroz y verduras',
        'category' => 'Rápidas',
        'minutes' => 25,
        'difficulty' => 'Fácil',
        'servings' => 2,
        'cost' => 2200,
        'image' => $foto('photo-1688431508895-4c2cab13b181'),
        'description' => 'Lo que quede en el refri + arroz = almuerzo para llevar.',
        'allergens' => ['Soya', 'Sésamo'],
        'sticker' => 'tomate',
        'sticker_name' => 'Tomatín',
        'ingredients' => [
            ['Arroz cocido', '2 tazas'],
            ['Verduras de temporada', '2 tazas'],
            ['Salsa de soya', '2 cdas'],
        ],
        'steps' => [
            'Saltea las verduras 5 min a fuego alto.',
            'Agrega el arroz y la soya, mezcla 2 min.',
            'Sirve en bowl.',
        ],
    ],
    // --- Recetas nuevas (9 a 12) ---
    [
        'slug' => 'huevos-revueltos',
        'title' => 'Huevos revueltos con tomate',
        'category' => 'Rápidas',
        'minutes' => 10,
        'difficulty' => 'Fácil',
        'servings' => 1,
        'cost' => 800,
        'image' => null,
        'description' => 'Desayuno o cena en diez minutos, con lo que siempre hay en la cocina.',
        'allergens' => ['Huevo', 'Gluten (si lo sirves con pan)'],
        'sticker' => 'huevo2',
        'sticker_name' => 'Madrugador',
        'ingredients' => [
            ['Huevos', '2 unidades'],
            ['Tomate', '1 unidad'],
            ['Cebolla', '¼ unidad'],
            ['Aceite', '1 cda'],
            ['Pan', '1 marraqueta'],
        ],
        'steps' => [
            'Pica la cebolla y el tomate en cubos chicos.',
            'Sofríe la cebolla en el aceite 2 min, agrega el tomate y cocina 3 min más.',
            'Agrega los huevos y revuelve a fuego bajo hasta que cuajen (1–2 min).',
            'Ajusta sal y sirve con pan tostado.',
        ],
    ],
    [
        'slug' => 'sopaipillas',
        'title' => 'Sopaipillas',
        'category' => 'Chilenas',
        'minutes' => 40,
        'difficulty' => 'Media',
        'servings' => 4,
        'cost' => 1500,
        'image' => null,
        'description' => 'Las de día de lluvia: masa con zapallo, fritas y doradas. Con pebre o con mostaza.',
        'allergens' => ['Gluten'],
        'sticker' => 'pan',
        'sticker_name' => 'Pancito',
        'ingredients' => [
            ['Harina', '2 tazas'],
            ['Zapallo cocido', '1 taza'],
            ['Manteca o mantequilla', '2 cdas'],
            ['Polvos de hornear', '1 cdta'],
            ['Sal', '1 cdta'],
            ['Aceite para freír', '2 tazas'],
        ],
        'steps' => [
            'Muele el zapallo cocido con un tenedor hasta hacerlo puré.',
            'Mezcla la harina, los polvos de hornear y la sal. Agrega el zapallo y la manteca derretida.',
            'Amasa hasta que quede una masa suave que no se pegue. Si está seca, agrega un poco del agua del zapallo.',
            'Estira la masa hasta dejarla de ½ cm, corta círculos con un vaso y pínchalos con un tenedor.',
            'Fríe en aceite caliente 2 min por lado, hasta que estén doradas. Déjalas sobre papel absorbente.',
        ],
    ],
    [
        'slug' => 'porotos',
        'title' => 'Porotos con riendas',
        'category' => 'Chilenas',
        'minutes' => 50,
        'difficulty' => 'Media',
        'servings' => 4,
        'cost' => 2800,
        'image' => null,
        'description' => 'Plato de invierno que llena de verdad: porotos, zapallo y tallarines.',
        'allergens' => ['Gluten'],
        'sticker' => 'olla2',
        'sticker_name' => 'Olla mágica',
        'ingredients' => [
            ['Porotos cocidos', '2 tazas'],
            ['Zapallo', '300 g'],
            ['Tallarines', '100 g'],
            ['Cebolla', '1 unidad'],
            ['Ají de color', '1 cdta'],
            ['Aceite', '2 cdas'],
        ],
        'steps' => [
            'Pica la cebolla y sofríela en el aceite con el ají de color por 5 min.',
            'Agrega los porotos, el zapallo en cubos y 3 tazas de agua. Cocina 20 min.',
            'Aplasta parte del zapallo contra la olla para espesar el caldo.',
            'Suma los tallarines partidos por la mitad y cocina 10 min más. Ajusta sal.',
        ],
    ],
    [
        'slug' => 'pure',
        'title' => 'Puré con vienesas',
        'category' => 'Rápidas',
        'minutes' => 30,
        'difficulty' => 'Fácil',
        'servings' => 2,
        'cost' => 2000,
        'image' => null,
        'description' => 'Comida de infancia: puré cremoso hecho con papas de verdad y vienesas doradas.',
        'allergens' => ['Lácteos'],
        'sticker' => 'estrella',
        'sticker_name' => 'Puré nube',
        'ingredients' => [
            ['Papas', '4 medianas'],
            ['Leche', '½ taza'],
            ['Mantequilla', '1 cda'],
            ['Vienesas', '4 unidades'],
            ['Sal', 'a gusto'],
        ],
        'steps' => [
            'Pela las papas, córtalas en cuatro y cuécelas en agua con sal por 20 min.',
            'Escúrrelas y muélelas calientes con un tenedor o prensapapas.',
            'Agrega la mantequilla y la leche tibia de a poco, revolviendo hasta que quede cremoso.',
            'Dora las vienesas en un sartén 3 min y sírvelas sobre el puré.',
        ],
    ],
    // --- Recetas nuevas (13 a 16) ---
    [
        'slug' => 'tortilla',
        'title' => 'Tortilla de verduras',
        'category' => 'Vegetarianas',
        'minutes' => 25,
        'difficulty' => 'Media',
        'servings' => 2,
        'cost' => 1800,
        'image' => null,
        'description' => 'Para rescatar la zanahoria y el zapallo italiano que quedaron en el refri.',
        'allergens' => ['Huevo', 'Gluten'],
        'sticker' => 'estrella',
        'sticker_name' => 'Tortillita',
        'ingredients' => [
            ['Huevos', '3 unidades'],
            ['Zanahoria', '1 unidad'],
            ['Zapallo italiano', '1 unidad'],
            ['Cebolla', '½ unidad'],
            ['Harina', '2 cdas'],
            ['Aceite', '2 cdas'],
        ],
        'steps' => [
            'Ralla la zanahoria y el zapallo italiano. Pica la cebolla.',
            'Saltea las verduras en 1 cda de aceite por 5 min y déjalas entibiar.',
            'Bate los huevos con la harina y sal, y mézclalos con las verduras.',
            'Vierte todo en un sartén con el resto del aceite. Cocina tapado a fuego bajo por 6 min.',
            'Da vuelta la tortilla con ayuda de un plato y cocina 4 min más.',
        ],
    ],
    [
        'slug' => 'quesadillas',
        'title' => 'Quesadillas de jamón y queso',
        'category' => 'Rápidas',
        'minutes' => 10,
        'difficulty' => 'Fácil',
        'servings' => 1,
        'cost' => 1500,
        'image' => null,
        'description' => 'Sartén, tortilla y dos minutos por lado. La once más rápida que existe.',
        'allergens' => ['Gluten', 'Lácteos'],
        'sticker' => 'estrella',
        'sticker_name' => 'Quesadilla feliz',
        'ingredients' => [
            ['Tortillas de trigo', '2 unidades'],
            ['Queso laminado', '4 láminas'],
            ['Jamón', '2 láminas'],
            ['Orégano', 'a gusto'],
        ],
        'steps' => [
            'Pon queso, jamón y orégano sobre la mitad de cada tortilla y dóblala.',
            'Calienta un sartén sin aceite a fuego medio.',
            'Dora cada quesadilla 2 min por lado, hasta que el queso se derrita.',
            'Córtalas en triángulos y sirve.',
        ],
    ],
    [
        'slug' => 'pebre',
        'title' => 'Pebre casero',
        'category' => 'Chilenas',
        'minutes' => 15,
        'difficulty' => 'Fácil',
        'servings' => 4,
        'cost' => 1200,
        'image' => null,
        'description' => 'El acompañamiento chileno para el pan, las sopaipillas y todo lo demás.',
        'allergens' => ['Sin alérgenos comunes'],
        'sticker' => 'estrella',
        'sticker_name' => 'Pebre picarón',
        'ingredients' => [
            ['Tomates', '3 unidades'],
            ['Cebolla', '1 unidad'],
            ['Cilantro', '½ atado'],
            ['Ají verde', '1 unidad'],
            ['Aceite', '2 cdas'],
            ['Jugo de limón', '1 unidad'],
        ],
        'steps' => [
            'Pica la cebolla en cubos chicos y lávala con agua fría para suavizarla.',
            'Pica los tomates en cubos, el cilantro fino y el ají sin pepas.',
            'Mezcla todo con el aceite, el jugo de limón y sal.',
            'Deja reposar 10 min antes de servir para que tome sabor.',
        ],
    ],
    [
        'slug' => 'leche-asada',
        'title' => 'Leche asada',
        'category' => 'Dulces',
        'minutes' => 60,
        'difficulty' => 'Media',
        'servings' => 6,
        'cost' => 2000,
        'image' => null,
        'description' => 'Postre de abuela con cuatro ingredientes. El horno hace casi todo el trabajo.',
        'allergens' => ['Huevo', 'Lácteos'],
        'sticker' => 'estrella',
        'sticker_name' => 'Dulce de horno',
        'ingredients' => [
            ['Leche', '1 litro'],
            ['Huevos', '5 unidades'],
            ['Azúcar', '1 taza'],
            ['Esencia de vainilla', '1 cdta'],
        ],
        'steps' => [
            'Precalienta el horno a 180 °C.',
            'Derrite ½ taza de azúcar en una olla a fuego bajo hasta formar caramelo y viértelo en una fuente para horno.',
            'Bate los huevos con el resto del azúcar y la vainilla. Agrega la leche y mezcla sin hacer espuma.',
            'Vierte la mezcla en la fuente y hornea 45 min, hasta que esté dorada y firme.',
            'Deja enfriar y refrigera antes de servir.',
        ],
    ],
    // --- Recetas nuevas (17 a 20) ---
    [
        'slug' => 'atun',
        'title' => 'Tallarines con atún',
        'category' => 'Pastas',
        'minutes' => 20,
        'difficulty' => 'Fácil',
        'servings' => 2,
        'cost' => 2500,
        'image' => null,
        'description' => 'Una lata de atún, un tarro de salsa y listo. Fin de mes resuelto.',
        'allergens' => ['Gluten', 'Pescado'],
        'sticker' => 'estrella',
        'sticker_name' => 'Atún al rescate',
        'ingredients' => [
            ['Tallarines', '200 g'],
            ['Atún en lata', '1 lata'],
            ['Salsa de tomate', '1 taza'],
            ['Cebolla', '½ unidad'],
            ['Ajo', '1 diente'],
            ['Aceite', '1 cda'],
        ],
        'steps' => [
            'Cuece los tallarines en agua con sal según el paquete y escúrrelos.',
            'Sofríe la cebolla y el ajo picados en el aceite por 4 min.',
            'Agrega la salsa de tomate y el atún escurrido. Cocina 5 min a fuego bajo.',
            'Mezcla la salsa con los tallarines y sirve.',
        ],
    ],
    [
        'slug' => 'cazuela',
        'title' => 'Cazuela de pollo',
        'category' => 'Chilenas',
        'minutes' => 60,
        'difficulty' => 'Media',
        'servings' => 4,
        'cost' => 4500,
        'image' => null,
        'description' => 'El caldo que arregla todo: una presa, una papa, zapallo y choclo en cada plato.',
        'allergens' => ['Sin alérgenos comunes'],
        'sticker' => 'estrella',
        'sticker_name' => 'Cazuelita',
        'ingredients' => [
            ['Trutros de pollo', '4 unidades'],
            ['Papas', '4 medianas'],
            ['Zapallo', '4 trozos'],
            ['Choclo', '2 unidades'],
            ['Zanahoria', '1 unidad'],
            ['Arroz', '¼ taza'],
            ['Cilantro', 'a gusto'],
        ],
        'steps' => [
            'Dora las presas de pollo en una olla grande con un poco de aceite, 3 min por lado.',
            'Agrega la zanahoria en rodajas y 2 litros de agua con sal. Cocina 20 min.',
            'Suma las papas peladas enteras, el zapallo y el choclo cortado en trozos. Cocina 20 min más.',
            'Agrega el arroz y cocina 10 min, hasta que esté blando.',
            'Sirve en plato hondo con cilantro picado encima.',
        ],
    ],
    [
        'slug' => 'budin',
        'title' => 'Budín de pan',
        'category' => 'Dulces',
        'minutes' => 55,
        'difficulty' => 'Fácil',
        'servings' => 6,
        'cost' => 1800,
        'image' => null,
        'description' => 'El pan duro de la semana convertido en postre. Nada se bota.',
        'allergens' => ['Gluten', 'Huevo', 'Lácteos'],
        'sticker' => 'estrella',
        'sticker_name' => 'Pan salvado',
        'ingredients' => [
            ['Pan duro', '4 marraquetas'],
            ['Leche', '3 tazas'],
            ['Huevos', '3 unidades'],
            ['Azúcar', '¾ taza'],
            ['Pasas', '¼ taza'],
            ['Esencia de vainilla', '1 cdta'],
        ],
        'steps' => [
            'Precalienta el horno a 180 °C y enmantequilla un molde.',
            'Troza el pan y remójalo en la leche tibia por 10 min.',
            'Muele el pan con un tenedor y agrega los huevos batidos, el azúcar, la vainilla y las pasas.',
            'Vierte la mezcla en el molde y hornea 40 min, hasta que al pincharlo el palito salga seco.',
            'Deja enfriar antes de desmoldar.',
        ],
    ],
    [
        'slug' => 'sandwich',
        'title' => 'Sándwich de palta y huevo',
        'category' => 'Rápidas',
        'minutes' => 15,
        'difficulty' => 'Fácil',
        'servings' => 1,
        'cost' => 1600,
        'image' => null,
        'description' => 'Marraqueta, palta molida y huevo duro. Sirve de desayuno, almuerzo o colación.',
        'allergens' => ['Gluten', 'Huevo'],
        'sticker' => 'estrella',
        'sticker_name' => 'Sanguchito',
        'ingredients' => [
            ['Marraqueta', '1 unidad'],
            ['Palta', '1 unidad'],
            ['Huevo', '1 unidad'],
            ['Jugo de limón', 'unas gotas'],
            ['Sal', 'a gusto'],
        ],
        'steps' => [
            'Cuece el huevo en agua hirviendo por 10 min, enfríalo y pélalo.',
            'Muele la palta con un tenedor y agrégale sal y unas gotas de limón.',
            'Abre el pan y tuéstalo un poco.',
            'Unta la palta, pon el huevo en rodajas y cierra el sándwich.',
        ],
    ],
];
```

</details>

**Entiende**
- El archivo devuelve (`return`) un arreglo de recetas. `$foto` es una función corta que arma la URL de Unsplash a partir del código de la foto.
- Las 12 recetas nuevas tienen `'image' => null`: la app muestra su sticker en vez de la foto. Buscar esas fotos es una tarea del domingo.
- `sticker` es el nombre del dibujo (un archivo de Emma en `components/stickers/`). Las recetas sin dibujo propio usan `estrella`.

## Paso 6 · Seeders

Un seeder llena la base de datos. **Crea:**

📄 **`web/database/seeders/RecipeSeeder.php`** · 33 líneas

```php
<?php

namespace Database\Seeders;

use App\Models\Recipe;
use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;

class RecipeSeeder extends Seeder
{
    public function run(): void
    {
        $recipes = require database_path('data/recetas.php');

        foreach ($recipes as $data) {
            // updateOrCreate: se puede ejecutar varias veces sin duplicar recetas.
            $recipe = Recipe::updateOrCreate(
                ['slug' => $data['slug']],
                Arr::except($data, ['ingredients']),
            );

            $recipe->ingredients()->delete();

            foreach ($data['ingredients'] as $index => [$name, $quantity]) {
                $recipe->ingredients()->create([
                    'name' => $name,
                    'quantity' => $quantity,
                    'position' => $index + 1,
                ]);
            }
        }
    }
}
```

**Reemplaza todo:**

📄 **`web/database/seeders/DatabaseSeeder.php`** · 33 líneas

```php
<?php

namespace Database\Seeders;

use App\Models\Recipe;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $this->call(RecipeSeeder::class);

        // Cuenta de demostración, igual a la del mockup. Contraseña: password
        $camila = User::factory()->create([
            'name' => 'Camila Rojas',
            'email' => 'camila.rojas@uni.cl',
        ]);

        $ids = fn (array $slugs) => Recipe::whereIn('slug', $slugs)->pluck('id');

        $camila->savedRecipes()->attach($ids(['charquican', 'panqueques', 'crema-zapallo']));

        $camila->cookedRecipes()->attach($ids([
            'tallarines-salsa', 'arroz-huevo', 'panqueques', 'ensalada-chilena',
            'huevos-revueltos', 'sopaipillas', 'porotos',
        ]));
    }
}
```

```bash
php artisan migrate:fresh --seed
php artisan tinker
```

Dentro de tinker, comprueba (y sal con `exit`):

```php
App\Models\Recipe::count();                                   // 20
App\Models\Recipe::first()->ingredients->pluck('name');       // Carne molida, Papas, ...
App\Models\Recipe::first()->cost_label;                       // "$3.500"
App\Models\Recipe::filter(['q' => 'zapallo'])->pluck('title');
$u = App\Models\User::first();
$u->short_name;                                               // "Camila R."
$u->savedRecipes()->count();                                  // 3
$u->cookedRecipes()->count();                                 // 7
```

**Entiende**
- `updateOrCreate([buscar], [datos])`: si ya existe una receta con ese slug, la actualiza; si no, la crea. Por eso el seeder se puede ejecutar varias veces.
- `Arr::except($data, ['ingredients'])` saca los ingredientes del arreglo, porque van a otra tabla. `$recipe->ingredients()->create([...])` crea cada uno ya unido a su receta.
- `foreach (... as $index => [$name, $quantity])` desarma cada par `['Papas', '4 medianas']` en dos variables.
- `DatabaseSeeder` crea a Camila con los mismos guardados (3) y cocinadas (7) del mockup. Su contraseña es `password` (la que pone `User::factory()`).
- `migrate:fresh --seed` **borra todo** y parte de cero. Úsalo cada vez que cambien las migraciones o los datos.

Sube el **PR 2**: `git add . && git commit -m "Las 20 recetas y la cuenta de demostración" && git push -u origin miguel/dia1-recetas`.

## Paso 7 · Controlador del catálogo

Rama nueva: `git switch -c miguel/dia1-catalogo`.

```bash
php artisan make:controller RecipeController
```

**Reemplaza todo:**

📄 **`web/app/Http/Controllers/RecipeController.php`** · 43 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\View\View;

class RecipeController extends Controller
{
    // Catálogo: /recetas?q=huevo&categoria=Rápidas&tiempo=30&dificultad=Fácil
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'q' => ['nullable', 'string', 'max:60'],
            'categoria' => ['nullable', 'string'],
            'tiempo' => ['nullable', 'integer'],
            'dificultad' => ['nullable', 'string'],
        ]);

        $user = $request->user();

        return view('recetas.index', [
            'recipes' => Recipe::filter($filters)->orderBy('id')->paginate(8)->withQueryString(),
            'filters' => $filters,
            'total' => Recipe::count(),
            'savedIds' => $user->savedRecipes()->pluck('recipes.id')->all(),
            'cookedIds' => $user->cookedRecipes()->pluck('recipes.id')->all(),
        ]);
    }

    // Detalle: /recetas/charquican
    public function show(Request $request, Recipe $recipe): View
    {
        $user = $request->user();

        return view('recetas.show', [
            'recipe' => $recipe->load('ingredients'),
            'isSaved' => $user->hasSaved($recipe),
            'isCooked' => $user->hasCooked($recipe),
        ]);
    }
}
```

**Entiende**
- `validate([...])` revisa los filtros de la URL. `nullable` permite que no vengan. Devuelve solo los campos validados.
- `paginate(8)` trae 8 recetas según `?page=`. `withQueryString()` hace que los enlaces de las páginas conserven los filtros (`?q=arroz&page=2`). El mockup ya anunciaba «Paginación clásica (Laravel paginate)».
- `pluck('recipes.id')->all()` entrega solo los ids de las recetas guardadas (y cocinadas). La vista pregunta `in_array($recipe->id, $savedIds)` por cada tarjeta, sin hacer una consulta por receta.
- En `show`, `Recipe $recipe` llega ya buscada por su slug. Si no existe, Laravel responde 404 sola. `load('ingredients')` trae los ingredientes en una sola consulta.

## Paso 8 · Rutas del catálogo

**Reemplaza todo** (cambian las dos primeras rutas del grupo; el resto sigue provisional hasta mañana):

📄 **`web/routes/web.php`** · 29 líneas · **versión provisional**

```php
<?php

use App\Http\Controllers\RecipeController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/recetas');

Route::middleware('auth')->group(function () {
    Route::get('/recetas', [RecipeController::class, 'index'])->name('recetas.index');
    Route::get('/recetas/{recipe}', [RecipeController::class, 'show'])->name('recetas.show');

    // Provisionales: se reemplazan mañana por sus controladores.
    Route::post('/recetas/{recipe}/guardar', fn () => back())->name('recetas.guardar');
    Route::post('/recetas/{recipe}/cocinada', fn () => back())->name('recetas.cocinada');

    Route::view('/guardados', 'pendiente')->name('guardados.index');

    Route::view('/perfil', 'pendiente')->name('perfil.show');
    Route::patch('/perfil', fn () => back())->name('perfil.update');
});

// Página de pruebas visuales, solo en tu computador: crea
// resources/views/muestra.blade.php (está en .gitignore y no se sube).
if (app()->isLocal()) {
    Route::view('/muestra', 'muestra')->middleware('auth');
}

require __DIR__.'/ia.php';
require __DIR__.'/auth.php';
```

## Paso 9 · Vistas provisionales

Dos vistas **sin diseño**, solo para comprobar los datos. Emma las reemplaza mañana por las del mockup y le sirven para ver qué variables entrega cada controlador. **Crea:**

📄 **`web/resources/views/recetas/index.blade.php`** · 21 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para comprobar los datos. Emma la reemplaza. --}}
<h1>Recetas</h1>
<p>{{ $recipes->count() }} de {{ $total }} recetas</p>

<form method="GET" action="{{ route('recetas.index') }}">
    <input name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Buscar">
    <button>Buscar</button>
</form>

@forelse ($recipes as $recipe)
    <p>
        <a href="{{ route('recetas.show', $recipe) }}">{{ $recipe->title }}</a>
        · {{ $recipe->category }} · {{ $recipe->minutes }} min · {{ $recipe->difficulty }} · {{ $recipe->cost_label }}
        @if (in_array($recipe->id, $savedIds)) · guardada @endif
        @if (in_array($recipe->id, $cookedIds)) · cocinada @endif
    </p>
@empty
    <p>No encontramos recetas con esos filtros</p>
@endforelse

{{ $recipes->links() }}
```

📄 **`web/resources/views/recetas/show.blade.php`** · 30 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para comprobar los datos. Emma la reemplaza. --}}
<p><a href="{{ route('recetas.index') }}">← Volver a recetas</a></p>
<h1>{{ $recipe->title }}</h1>
<p>{{ $recipe->description }}</p>
<p>{{ $recipe->category }} · {{ $recipe->minutes }} min · {{ $recipe->difficulty }} · {{ $recipe->servings }} porciones · {{ $recipe->cost_label }}</p>
<p>{{ $isSaved ? 'Guardada' : 'Sin guardar' }} · {{ $isCooked ? 'Cocinada' : 'Sin cocinar' }}</p>

<form method="POST" action="{{ route('recetas.guardar', $recipe) }}">@csrf <button>Guardar / quitar</button></form>
<form method="POST" action="{{ route('recetas.cocinada', $recipe) }}">@csrf <button>Cocinada / desmarcar</button></form>

@if (session('toast'))
    <p><strong>{{ session('toast')['title'] }}</strong> {{ session('toast')['body'] ?? '' }}</p>
@endif

<h2>Alérgenos</h2>
<p>{{ implode(' · ', $recipe->allergens) }}</p>

<h2>Ingredientes</h2>
<ul>
    @foreach ($recipe->ingredients as $ingredient)
        <li>{{ $ingredient->name }}: {{ $ingredient->quantity }}</li>
    @endforeach
</ul>

<h2>Preparación</h2>
<ol>
    @foreach ($recipe->steps as $step)
        <li>{{ $step }}</li>
    @endforeach
</ol>
```

Entra con `camila.rojas@uni.cl` / `password` y revisa:

- [ ] `/recetas` muestra «8 de 20 recetas» y los enlaces de página.
- [ ] `/recetas?q=zapallo` y `/recetas?categoria=Chilenas&tiempo=45` filtran.
- [ ] `/recetas?q=xyz` muestra «No encontramos recetas con esos filtros».
- [ ] `/recetas/charquican` muestra ingredientes, pasos y alérgenos. `/recetas/no-existe` responde 404.

## Cierre del día

```bash
vendor/bin/pint && php artisan test
git add . && git commit -m "Catálogo y detalle con vistas provisionales"
git push -u origin miguel/dia1-catalogo
```

- [ ] Tres PR abiertos (modelos, recetas, catálogo). Sebastián los integra.
- [ ] Check-in de las 21:00.
