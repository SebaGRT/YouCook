<!-- Archivo generado por scripts/guias/generar.py: edita la plantilla, no este archivo. -->
# Miguel · Día 2 (sábado 14): guardar, cocinar, perfil y pruebas

**Meta del día:** que guardar una receta, marcarla como cocinada y editar el perfil funcionen de verdad, con pruebas automáticas y mensajes en español.

← [Día 1](dia1.md) · [Índice de guías](../README.md) · Siguiente: [Día 3](dia3.md)

## Mapa del día

| Paso | Qué haces | Archivo | Entrega |
|---|---|---|---|
| 1 | Fábricas de datos de prueba | `database/factories/RecipeFactory.php`, `IngredientFactory.php` | **📣 A las 10:00 (Sebastián las espera)** |
| 2 | Pruebas del catálogo | `tests/Feature/RecipeCatalogTest.php` | PR 1 |
| 3 | Guardar y Guardados | `SavedRecipeController.php` | |
| 4 | Marcar como cocinada | `CookedRecipeController.php` | |
| 5 | Perfil | `ProfileController.php` | |
| 6 | Rutas definitivas | `routes/web.php` | |
| 7 | Vistas provisionales | `guardados/index.blade.php`, `perfil/show.blade.php` | |
| 8 | Pruebas de guardar y cocinar | `tests/Feature/SavedAndCookedTest.php` | |
| 9 | Mensajes en español | `lang/es/validation.php` | **PR 2 a las 16:00 (Emma necesita el perfil para mañana)** |

**Tiempo:** unas 3 h 30 (~520 líneas).

Rama: `git switch main && git pull && composer install && npm install && php artisan migrate:fresh --seed && git switch -c miguel/dia2-pruebas`.

---

## Paso 1 · Fábricas de datos de prueba

Una *factory* crea modelos de mentira para las pruebas: `Recipe::factory()->create()`. **Crea:**

📄 **`web/database/factories/RecipeFactory.php`** · 34 líneas

```php
<?php

namespace Database\Factories;

use App\Models\Recipe;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<Recipe>
 */
class RecipeFactory extends Factory
{
    public function definition(): array
    {
        $title = Str::ucfirst(fake()->unique()->words(3, true));

        return [
            'slug' => Str::slug($title),
            'title' => $title,
            'category' => fake()->randomElement(Recipe::CATEGORIES),
            'minutes' => fake()->numberBetween(10, 60),
            'difficulty' => fake()->randomElement(Recipe::DIFFICULTIES),
            'servings' => fake()->numberBetween(1, 6),
            'cost' => fake()->numberBetween(8, 50) * 100,
            'image' => null,
            'description' => fake()->sentence(),
            'allergens' => ['Sin alérgenos comunes'],
            'steps' => [fake()->sentence(), fake()->sentence()],
            'sticker' => 'estrella',
            'sticker_name' => 'Estrella',
        ];
    }
}
```

📄 **`web/database/factories/IngredientFactory.php`** · 23 líneas

```php
<?php

namespace Database\Factories;

use App\Models\Ingredient;
use App\Models\Recipe;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Ingredient>
 */
class IngredientFactory extends Factory
{
    public function definition(): array
    {
        return [
            'recipe_id' => Recipe::factory(),
            'name' => fake()->unique()->word(),
            'quantity' => '1 taza',
            'position' => 1,
        ];
    }
}
```

**Entiende**
- `definition()` devuelve valores por defecto. En cada prueba se cambian solo los que importan: `Recipe::factory()->create(['title' => 'Charquicán'])`.
- `fake()` genera datos al azar (palabras, números, frases).
- `'recipe_id' => Recipe::factory()`: si no se indica la receta, crea una nueva para ese ingrediente.
- Los modelos ya tienen `use HasFactory;`: por eso existe `Recipe::factory()`.

Súbelas de inmediato (`git add . && git commit -m "Factories" && git push -u origin miguel/dia2-pruebas`), abre el PR y avisa: **📣 «Sebastián: factories en PR»**. Sigue en la misma rama.

## Paso 2 · Pruebas del catálogo

**Crea:**

📄 **`web/tests/Feature/RecipeCatalogTest.php`** · 100 líneas

```php
<?php

namespace Tests\Feature;

use App\Models\Ingredient;
use App\Models\Recipe;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RecipeCatalogTest extends TestCase
{
    use RefreshDatabase;

    public function test_el_catalogo_exige_iniciar_sesion(): void
    {
        $this->get('/recetas')->assertRedirect('/login');
    }

    public function test_el_catalogo_muestra_ocho_recetas_por_pagina(): void
    {
        Recipe::factory()->count(9)->create();
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas')
            ->assertOk()
            ->assertSee('8 de 9 recetas')
            ->assertViewHas('recipes', fn ($recipes) => $recipes->count() === 8);

        $this->actingAs($user)->get('/recetas?page=2')
            ->assertViewHas('recipes', fn ($recipes) => $recipes->count() === 1);
    }

    public function test_busca_por_titulo_y_por_ingrediente(): void
    {
        $charquican = Recipe::factory()->create(['title' => 'Charquicán']);
        Ingredient::factory()->for($charquican)->create(['name' => 'Zapallo camote']);
        Recipe::factory()->create(['title' => 'Crema de zapallo']);
        Recipe::factory()->create(['title' => 'Arroz con huevo']);
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas?q=zapallo')
            ->assertOk()
            ->assertSee('Charquicán')
            ->assertSee('Crema de zapallo')
            ->assertDontSee('Arroz con huevo');
    }

    public function test_filtra_por_categoria_tiempo_y_dificultad(): void
    {
        Recipe::factory()->create(['title' => 'Rápida y fácil', 'category' => 'Rápidas', 'minutes' => 10, 'difficulty' => 'Fácil']);
        Recipe::factory()->create(['title' => 'Rápida pero lenta', 'category' => 'Rápidas', 'minutes' => 50, 'difficulty' => 'Fácil']);
        Recipe::factory()->create(['title' => 'Dulce difícil', 'category' => 'Dulces', 'minutes' => 10, 'difficulty' => 'Media']);
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas?categoria=Rápidas&tiempo=15&dificultad=Fácil')
            ->assertOk()
            ->assertSee('Rápida y fácil')
            ->assertDontSee('Rápida pero lenta')
            ->assertDontSee('Dulce difícil');
    }

    public function test_sin_resultados_muestra_el_estado_vacio(): void
    {
        Recipe::factory()->create();
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas?q=inexistente')
            ->assertOk()
            ->assertSee('No encontramos recetas con esos filtros');
    }

    public function test_el_detalle_muestra_ingredientes_pasos_y_alergenos(): void
    {
        $recipe = Recipe::factory()->create([
            'slug' => 'charquican',
            'steps' => ['Pela las papas.', 'Sirve caliente.'],
            'allergens' => ['Huevo'],
            'cost' => 3500,
        ]);
        Ingredient::factory()->for($recipe)->create(['name' => 'Papas', 'quantity' => '4 medianas']);
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas/charquican')
            ->assertOk()
            ->assertSee($recipe->title)
            ->assertSee('Papas')
            ->assertSee('4 medianas')
            ->assertSee('Pela las papas.')
            ->assertSee('Huevo')
            ->assertSee('$3.500');
    }

    public function test_una_receta_que_no_existe_responde_404(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->get('/recetas/no-existe')->assertNotFound();
    }
}
```

```bash
php artisan test --filter=RecipeCatalogTest     # 7 pruebas en verde
```

**Entiende**
- `use RefreshDatabase;`: cada prueba parte con una base de datos vacía (en memoria; no toca tu `database.sqlite`).
- Cada prueba tiene tres momentos: preparar datos, hacer la petición y comprobar. `actingAs($user)` es «como si esta persona hubiera iniciado sesión».
- `assertSee('texto')` busca el texto en la página. Las pruebas pasan con tus vistas provisionales **y** tienen que seguir pasando con las de Emma: son el contrato entre los dos.
- `assertViewHas('recipes', fn ...)` revisa los datos que el controlador entregó a la vista.

## Paso 3 · Guardar y Guardados

```bash
php artisan make:controller SavedRecipeController
```

**Reemplaza todo:**

📄 **`web/app/Http/Controllers/SavedRecipeController.php`** · 30 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SavedRecipeController extends Controller
{
    // Guardados: /guardados
    public function index(Request $request): View
    {
        $user = $request->user();

        return view('guardados.index', [
            'recipes' => $user->savedRecipes()->orderBy('saved_recipes.created_at')->get(),
            'cookedIds' => $user->cookedRecipes()->pluck('recipes.id')->all(),
        ]);
    }

    // Guarda la receta o, si ya estaba guardada, la quita.
    public function toggle(Request $request, Recipe $recipe): RedirectResponse
    {
        $request->user()->savedRecipes()->toggle($recipe);

        return back()->withFragment('receta-'.$recipe->slug);
    }
}
```

**Entiende**
- `toggle($recipe)` hace todo el trabajo: si la pareja persona-receta no existe, la crea; si existe, la borra. Es el `toggleSave` de `store.tsx`.
- `back()` devuelve a la página desde donde se envió el formulario (catálogo, detalle o guardados). `withFragment('receta-charquican')` agrega `#receta-charquican` a la URL para que el navegador vuelva a la tarjeta y no al inicio de la página.
- En `index`, `orderBy('saved_recipes.created_at')` ordena por cuándo se guardó cada una.

## Paso 4 · Marcar como cocinada

```bash
php artisan make:controller CookedRecipeController
```

**Reemplaza todo:**

📄 **`web/app/Http/Controllers/CookedRecipeController.php`** · 33 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CookedRecipeController extends Controller
{
    // Marca la receta como cocinada o, si ya lo estaba, la desmarca.
    public function toggle(Request $request, Recipe $recipe): RedirectResponse
    {
        $user = $request->user();
        $changes = $user->cookedRecipes()->toggle($recipe);

        // Solo hay sticker nuevo cuando se marca, no cuando se desmarca.
        if ($changes['attached'] === []) {
            return back();
        }

        return back()->with('toast', [
            'title' => '¡Receta cocinada!',
            'body' => sprintf(
                'Desbloqueaste el sticker «%s» · %d de %d',
                $recipe->sticker_name,
                $user->cookedRecipes()->count(),
                Recipe::count(),
            ),
            'sticker' => $recipe->sticker,
        ]);
    }
}
```

**Entiende**
- `toggle()` devuelve qué pasó: `['attached' => [...], 'detached' => [...]]`. Si `attached` está vacío, la receta se **desmarcó** y no hay aviso.
- `->with('toast', [...])` guarda el aviso en la sesión **solo para la siguiente página** (un dato *flash*). El layout de Emma lo lee con `session('toast')` y dibuja el aviso con el sticker.
- `sprintf('… «%s» · %d de %d', ...)` arma el texto: `%s` es un texto y `%d`, un número.

## Paso 5 · Perfil

```bash
php artisan make:controller ProfileController
```

**Reemplaza todo:**

📄 **`web/app/Http/Controllers/ProfileController.php`** · 55 líneas

```php
<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProfileController extends Controller
{
    // Perfil: datos, progreso del reto, stickers y checklist.
    public function show(Request $request): View
    {
        $user = $request->user();
        $recipes = Recipe::orderBy('id')->get(['id', 'slug', 'title', 'sticker', 'sticker_name']);
        $cookedIds = $user->cookedRecipes()->pluck('recipes.id')->all();
        $cooked = count($cookedIds);

        return view('perfil.show', [
            'user' => $user,
            'recipes' => $recipes,
            'cookedIds' => $cookedIds,
            'cooked' => $cooked,
            'saved' => $user->savedRecipes()->count(),
            'total' => $recipes->count(),
            'level' => match (true) {
                $cooked >= 20 => 'Maestra de cocina',
                $cooked >= 10 => 'Chef de pensión',
                $cooked >= 5 => 'Aprendiz',
                default => 'Cocinera en entrenamiento',
            },
        ]);
    }

    // Guarda el nombre y el correo (formulario «Mis datos»).
    public function update(Request $request): RedirectResponse
    {
        $user = $request->user();

        $datos = $request->validate([
            'name' => 'required|string|max:255',
            // Único entre los usuarios, salvo el mío: si no cambio el correo, no choca conmigo.
            'email' => ['required', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
        ]);

        $user->update($datos);

        return redirect()->route('perfil.show')->with('toast', [
            'title' => 'Datos actualizados',
            'body' => 'Guardamos tu nombre y tu correo.',
        ]);
    }
}
```

**Entiende**
- `show` entrega todo lo que la pantalla necesita: la lista de las 20 recetas (para los stickers y el checklist), los ids de las cocinadas y los contadores.
- `match (true) { ... }` elige el nivel según cuántas recetas van: es una cadena de `if` más ordenada. Los cortes (5, 10 y 20) son los de la barra de progreso del mockup.
- `update` valida con `$request->validate([...])`, como el `AuthController` de Sebastián: nombre obligatorio y correo válido. Si algo falla, Laravel vuelve al formulario con los errores y el resto del método no se ejecuta.
- `Rule::unique('users')->ignore($user->id)`: el correo no puede ser el de **otra** cuenta. Sin `ignore`, guardar el perfil sin cambiar el correo fallaría, porque el correo «ya existe»: es el mío.
- `$user->update($datos)` guarda solo los campos validados (y que están en `$fillable`).

## Paso 6 · Rutas definitivas

**Reemplaza todo** (versión definitiva):

📄 **`web/routes/web.php`** · 30 líneas

```php
<?php

use App\Http\Controllers\CookedRecipeController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RecipeController;
use App\Http\Controllers\SavedRecipeController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/recetas');

Route::middleware('auth')->group(function () {
    Route::get('/recetas', [RecipeController::class, 'index'])->name('recetas.index');
    Route::get('/recetas/{recipe}', [RecipeController::class, 'show'])->name('recetas.show');
    Route::post('/recetas/{recipe}/guardar', [SavedRecipeController::class, 'toggle'])->name('recetas.guardar');
    Route::post('/recetas/{recipe}/cocinada', [CookedRecipeController::class, 'toggle'])->name('recetas.cocinada');

    Route::get('/guardados', [SavedRecipeController::class, 'index'])->name('guardados.index');

    Route::get('/perfil', [ProfileController::class, 'show'])->name('perfil.show');
    Route::patch('/perfil', [ProfileController::class, 'update'])->name('perfil.update');
});

// Página de pruebas visuales, solo en tu computador: crea
// resources/views/muestra.blade.php (está en .gitignore y no se sube).
if (app()->isLocal()) {
    Route::view('/muestra', 'muestra')->middleware('auth');
}

require __DIR__.'/ia.php';
require __DIR__.'/auth.php';
```

## Paso 7 · Vistas provisionales

Igual que ayer: sin diseño. Emma las reemplaza mañana. **Crea:**

📄 **`web/resources/views/guardados/index.blade.php`** · 12 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para comprobar los datos. Emma la reemplaza. --}}
<p><a href="{{ route('recetas.index') }}">← Recetas</a></p>
<h1>Guardados</h1>

@forelse ($recipes as $recipe)
    <p>
        <a href="{{ route('recetas.show', $recipe) }}">{{ $recipe->title }}</a>
        @if (in_array($recipe->id, $cookedIds)) · cocinada @endif
    </p>
@empty
    <p>Aún no guardas recetas</p>
@endforelse
```

📄 **`web/resources/views/perfil/show.blade.php`** · 30 líneas · **versión provisional**

```blade
{{-- Versión provisional: sin diseño, solo para comprobar los datos. Emma la reemplaza. --}}
<p><a href="{{ route('recetas.index') }}">← Recetas</a></p>
<h1>{{ $user->name }}</h1>
<p>{{ $user->email }} · {{ $level }}</p>
<p>{{ $cooked }} de {{ $total }} recetas cocinadas ({{ $total > 0 ? round($cooked / $total * 100) : 0 }}%) · {{ $saved }} guardadas</p>

@if (session('toast'))
    <p><strong>{{ session('toast')['title'] }}</strong></p>
@endif

<form method="POST" action="{{ route('perfil.update') }}">
    @csrf
    @method('PATCH')
    <input name="name" value="{{ old('name', $user->name) }}">
    <input name="email" value="{{ old('email', $user->email) }}">
    <button>Guardar</button>
    @foreach ($errors->all() as $error)
        <p>{{ $error }}</p>
    @endforeach
</form>

<h2>Checklist y stickers</h2>
<ul>
    @foreach ($recipes as $recipe)
        @php $ganado = in_array($recipe->id, $cookedIds); @endphp
        <li>{{ $ganado ? '✔' : '·' }} {{ $recipe->title }} — {{ $ganado ? $recipe->sticker_name : '???' }}</li>
    @endforeach
</ul>

<form method="POST" action="{{ route('logout') }}">@csrf <button>Cerrar sesión</button></form>
```

- [ ] En `/recetas/charquican`, los botones guardan y marcan (si el detalle del mockup aún no está, usa tu vista provisional).
- [ ] `/guardados` y `/perfil` muestran los datos de Camila: 3 guardadas, «7 de 20 recetas cocinadas (35%)».
- [ ] En `/perfil`, cambiar el nombre funciona; un correo sin `@` muestra un error.

## Paso 8 · Pruebas de guardar y cocinar

**Crea:**

📄 **`web/tests/Feature/SavedAndCookedTest.php`** · 75 líneas

```php
<?php

namespace Tests\Feature;

use App\Models\Recipe;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SavedAndCookedTest extends TestCase
{
    use RefreshDatabase;

    public function test_guardar_dos_veces_guarda_y_luego_quita(): void
    {
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create();

        $this->actingAs($user)->post("/recetas/{$recipe->slug}/guardar")->assertRedirect();
        $this->assertTrue($user->hasSaved($recipe));

        $this->actingAs($user)->post("/recetas/{$recipe->slug}/guardar");
        $this->assertFalse($user->hasSaved($recipe));
    }

    public function test_guardados_muestra_solo_mis_recetas(): void
    {
        $user = User::factory()->create();
        $mia = Recipe::factory()->create(['title' => 'Mi receta guardada']);
        $ajena = Recipe::factory()->create(['title' => 'Receta de otra persona']);
        $user->savedRecipes()->attach($mia);
        User::factory()->create()->savedRecipes()->attach($ajena);

        $this->actingAs($user)->get('/guardados')
            ->assertOk()
            ->assertSee('Mi receta guardada')
            ->assertDontSee('Receta de otra persona');
    }

    public function test_guardados_vacio_invita_a_explorar(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->get('/guardados')
            ->assertOk()
            ->assertSee('Aún no guardas recetas');
    }

    public function test_marcar_como_cocinada_desbloquea_el_sticker(): void
    {
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create(['sticker' => 'choclo', 'sticker_name' => 'Choclito']);

        $response = $this->actingAs($user)->post("/recetas/{$recipe->slug}/cocinada");

        $response->assertRedirect()->assertSessionHas('toast', [
            'title' => '¡Receta cocinada!',
            'body' => 'Desbloqueaste el sticker «Choclito» · 1 de 1',
            'sticker' => 'choclo',
        ]);
        $this->assertTrue($user->hasCooked($recipe));
    }

    public function test_desmarcar_una_receta_cocinada_no_muestra_aviso(): void
    {
        $user = User::factory()->create();
        $recipe = Recipe::factory()->create();
        $user->cookedRecipes()->attach($recipe);

        $response = $this->actingAs($user)->post("/recetas/{$recipe->slug}/cocinada");

        $response->assertSessionMissing('toast');
        $this->assertFalse($user->hasCooked($recipe));
    }
}
```

**Entiende**
- `test_guardados_muestra_solo_mis_recetas` es una prueba de privacidad: lo que guarda otra persona no aparece en mi lista.
- `assertSessionHas('toast', [...])` comprueba el aviso exacto que verá la persona, con el nombre del sticker y «1 de 1».

## Paso 9 · Mensajes en español

Con `APP_LOCALE=es`, Laravel busca los textos en `lang/es/`. Si no existen, los muestra en inglés. **Crea:**

📄 **`web/lang/es/validation.php`** · 31 líneas

```php
<?php

// Solo las reglas que usa YouCook. Si agregas una regla nueva, agrega aquí
// su mensaje; si falta, Laravel muestra el mensaje en inglés.
return [
    'confirmed' => 'La confirmación de :attribute no coincide.',
    'current_password' => 'La contraseña es incorrecta.',
    'email' => 'Escribe un correo válido.',
    'integer' => 'El campo :attribute debe ser un número entero.',
    'lowercase' => 'El campo :attribute debe estar en minúsculas.',
    'max' => [
        'string' => 'El campo :attribute no puede tener más de :max caracteres.',
    ],
    'min' => [
        'string' => 'El campo :attribute debe tener al menos :min caracteres.',
    ],
    'required' => 'El campo :attribute es obligatorio.',
    'string' => 'El campo :attribute debe ser texto.',
    'unique' => 'Ya existe una cuenta con ese :attribute.',

    // Nombre de cada campo dentro de los mensajes.
    'attributes' => [
        'name' => 'nombre',
        'email' => 'correo',
        'password' => 'contraseña',
        'current_password' => 'contraseña actual',
        'mensaje' => 'mensaje',
        'q' => 'búsqueda',
        'tiempo' => 'tiempo',
    ],
];
```

**Entiende**
- Son los mensajes de `$request->validate()`. `:attribute`, `:min` y `:max` se reemplazan solos: «El campo contraseña debe tener al menos 8 caracteres.» El arreglo `attributes` traduce el nombre de cada campo.
- El mensaje de «correo o contraseña incorrectos» no está aquí: lo escribió Sebastián en español directo en `AuthController`.
- Prueba: en `/registro`, una contraseña de 3 letras debe mostrar el error en español.

## Cierre del día

```bash
vendor/bin/pint && php artisan test
git add . && git commit -m "Guardar, cocinada, perfil y textos en español"
git push
```

- [ ] PR 2 abierto antes de las 16:00. Avisa: **📣 «Emma: `/guardados` y `/perfil` ya entregan datos»**.
- [ ] Check-in de las 21:00.
