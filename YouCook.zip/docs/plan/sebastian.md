# Sebastián Herrera: líder, IA e integración

**Eres dueño de:** el proyecto (creación y configuración), `resources/css/app.css`, `vite.config.js`, `routes/ia.php`, `routes/console.php`, el servicio de IA, los dos controladores de IA, `resources/js/` y la pantalla del asistente. Además integras todos los PR y preparas la entrega.

**Tu código, día por día:** [Día 1](../guias/sebastian/dia1.md) · [Día 2](../guias/sebastian/dia2.md) · [Día 3](../guias/sebastian/dia3.md).
**Tiempo estimado:** unas 10 h (3 h el viernes, 4 h el sábado, 3 h el domingo).

---

## Jueves 12 (noche, ~1 h)

- [ ] Enviar a Emma y Miguel el enlace a `docs/plan/` y a su archivo.
- [ ] Crear el repositorio y subirlo (el código se crea mañana):
  ```bash
  cd ~/Documents/UDD/Trimestre11/Tecnologias-Web/Proyectos/YouCook
  git add docs mockup scripts README.md .gitignore && git status   # NO debe aparecer referencia/ ni node_modules/
  git commit -m "Propuesta, mockup, plan y guías"
  gh repo create YouCook --private --source . --push
  gh repo edit --add-collaborator <usuario-emma>     # y lo mismo con Miguel
  ```
- [ ] Sacar la clave de **Groq** con la cuenta del grupo y probarla con `curl` (ver [día 1, paso 11](../guias/sebastian/dia1.md#paso-11--comando-para-probar-la-conexión)).
- [ ] Preguntar al profesor lo de la [lista «Por confirmar»](README.md#por-confirmar-con-el-profesor-jueves-o-viernes-temprano).

## Viernes 13 ([guía](../guias/sebastian/dia1.md))

- [ ] **Esqueleto en `main` a las 10:30.** Es lo único urgente del día: los otros dos no pueden empezar sin él.
- [ ] Tarde: servicio de IA con Groq, `php artisan ia:probar`.
- [ ] Integrar los PR de Miguel (3) y Emma (2) en el orden en que lleguen.
- **Cierre:** se puede registrar y entrar; la barra muestra «7 de 20 recetas» con la cuenta de Camila.

## Sábado 14 ([guía](../guias/sebastian/dia2.md))

- [ ] **Fila de ingrediente en `main` a las 12:00** (Emma la espera).
- [ ] Alternativas y asistente con la IA real. Dos capturas de respuestas reales en `docs/evidencia/`.
- [ ] **18:00: decisión del plan B de la IA** (ver [README](README.md#plan-b-de-la-ia-decisión-el-sábado-a-las-1800)).
- **Cierre:** toda la app funciona con IA real.

## Domingo 15 ([guía](../guias/sebastian/dia3.md))

- [ ] Integrar Guardados y Perfil, borrar lo provisional, recorrido completo.
- [ ] README del repo. **Congelamiento a las 18:00** y tag `v1.0`.
- [ ] Ensayo general a las 21:00.

## Lunes 16

- [ ] Llegar con el computador listo (`ia:probar` en la red del lugar o con el teléfono compartiendo internet).
- [ ] Presentar: problema, IA y cómo está hecha.
