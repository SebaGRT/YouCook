# Emma Westcott: diseño y frontend

**Eres dueña de:** todos los componentes visuales (`resources/views/components/`, salvo los tres de la IA), los dos layouts y las pantallas de ingreso, registro, catálogo, detalle, guardados y perfil. También de la revisión visual contra el mockup.

**Tu código, día por día:** [Día 1](../guias/emma/dia1.md) · [Día 2](../guias/emma/dia2.md) · [Día 3](../guias/emma/dia3.md).
**Tiempo estimado:** unas 10 h (3 h 30 por día el viernes y el sábado, 3 h el domingo).
**Mockup:** carpeta `mockup/Mockup de YouCook/` del repo ([Figma](https://www.figma.com/make/YxfgzwAvSW1RFc46TdE6Lj/Mockup-de-YouCook?t=u6hOFMOe8BEePNEQ-20&fullscreen=1)). Para verlo en tu computador: `cd "mockup/Mockup de YouCook" && npm install && npm run dev`.

No edites controladores, modelos ni rutas. Si necesitas un dato que la vista no recibe, pídeselo a Miguel por chat.

---

## Jueves 12 (noche, ~30 min)

- [ ] Instalar PHP, Composer y Node ([instrucciones](README.md#instalación-jueves-en-la-noche)). Comprobar `php -v`, `composer -V` y `node -v`.
- [ ] Aceptar la invitación al repositorio.
- [ ] Abrir el mockup y leer `src/components/Nav.tsx` y `Icons.tsx`.

## Viernes 13 ([guía](../guias/emma/dia1.md))

- [ ] Mañana (desde las 10:30): íconos, logo, stickers, ingreso y registro. **PR 1.**
- [ ] Tarde (con los modelos de Miguel en `main`): avatar, barra, aviso y layout. **PR 2.**
- **Cierre:** ingreso y registro iguales al mockup; la barra aparece en todas las páginas.

## Sábado 14 ([guía](../guias/emma/dia2.md))

- [ ] Mañana: componentes de la tarjeta y el catálogo completo. **PR 1.**
- [ ] Tarde (con la fila de ingrediente de Sebastián, 12:00): detalle de receta. **PR 2.**
- **Cierre:** catálogo y detalle iguales al mockup.

## Domingo 15 ([guía](../guias/emma/dia3.md))

- [ ] **Guardados y Perfil antes de las 13:00.**
- [ ] Revisión visual en escritorio y teléfono (`docs/evidencia/qa-visual.md`) y capturas. Correcciones **antes de las 18:00**.
- [ ] Ensayo general a las 21:00.

## Lunes 16

- [ ] Presentar el registro y el catálogo, y explicar cómo pasamos el mockup de React a Blade (2 min).
