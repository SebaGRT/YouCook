# Plan YouCook: viernes 13 al lunes 16 de noviembre de 2026

La propuesta tenía un cronograma de cuatro semanas. Lo comprimimos en **tres días de trabajo** y presentamos el **lunes 16**.

Archivos por integrante: [Sebastián](sebastian.md) · [Emma](emma.md) · [Miguel](miguel.md). **El código a escribir día por día está en las [guías](../guias/README.md).** Este plan cubre lo que no es código: horarios, reglas, riesgos y presentación.

## Roles (de la propuesta)

| Integrante | Rol | En este plan |
|---|---|---|
| **Sebastián Herrera** | Líder del grupo | Crea el proyecto, integra todos los PR, hace la IA (servicio, «No lo tengo» y asistente) y prepara la entrega |
| **Emma Westcott** | Diseño y frontend | Todas las pantallas del mockup en Blade: componentes, layouts, catálogo, detalle, guardados, perfil y revisión visual |
| **Miguel Figueroa** | Desarrollo backend | Base de datos, modelos, las 20 recetas, controladores, validación en español y pruebas automáticas |

El cronograma de la propuesta se respeta en su reparto: Emma y Miguel hacen rutas, vistas y base de datos; Sebastián, la integración de la IA.

## Calendario

| Día | Sebastián | Emma | Miguel | Cierre del día |
|---|---|---|---|---|
| **Jue 12** (noche) | Leer el plan; crear el repo y sumar a Emma y Miguel; sacar la clave de Groq | Instalar PHP, Composer y Node | Instalar PHP, Composer y Node; leer `data.ts` del mockup | Los tres tienen `php -v`, `composer -V` y `node -v` funcionando |
| **Vie 13** | [Esqueleto en `main` (**10:30**)](../guias/sebastian/dia1.md) y servicio de IA | [Íconos, stickers, ingreso, registro y barra](../guias/emma/dia1.md) | [Migraciones y modelos (**13:00**), 20 recetas y catálogo](../guias/miguel/dia1.md) | Se puede registrar, entrar y ver la barra con datos reales |
| **Sáb 14** | [Fila de ingrediente (**12:00**), alternativas y asistente](../guias/sebastian/dia2.md) | [Catálogo y detalle del mockup](../guias/emma/dia2.md) | [Factories (**10:00**), guardar, cocinada, perfil (**16:00**) y pruebas](../guias/miguel/dia2.md) | Toda la app funciona con IA real; solo Guardados y Perfil sin diseño |
| **Dom 15** | [Integración, limpieza, README](../guias/sebastian/dia3.md); **congelamiento a las 18:00** | [Guardados y Perfil (**13:00**), revisión visual y capturas](../guias/emma/dia3.md) | [Pruebas del perfil, fotos y revisión del backend](../guias/miguel/dia3.md) | **Ensayo general a las 21:00** |
| **Lun 16** | Preparar el computador y presentar | Presentar su parte | Presentar su parte | Entregado |

Carga estimada: Sebastián ~10 h, Emma ~10 h, Miguel ~9 h 30 en los tres días.

## Instalación (jueves en la noche)

- **Windows:** <https://herd.laravel.com> (trae PHP, Composer y el instalador de Laravel) y Node 22 o superior desde <https://nodejs.org>.
- **macOS o Linux:** `/bin/bash -c "$(curl -fsSL https://php.new/install/linux/8.5)"` (en macOS, cambia `linux` por `mac`) y Node 22 o superior.
- Comprobar: `php -v` (8.3 o más), `composer -V`, `laravel --version`, `node -v`, `git --version`.
- No hace falta instalar una base de datos: usamos SQLite (un archivo).

## Reglas

1. **Check-in diario a las 21:00** (10 min por chat o llamada): qué hice, qué sigue, qué me bloquea.
2. **Ramas cortas** con el formato `nombre/diaN-tema`. Push y PR antes de las 22:00; Sebastián integra en la noche o a las 9:00.
3. **Cada archivo tiene un dueño** ([tabla](../guias/README.md#quién-es-dueño-de-cada-archivo)). Si necesitas un cambio en un archivo de otro, se pide por chat.
4. **Antes de cada push**, desde `web/`: `vendor/bin/pint && npm run build && php artisan test`.
5. **Las claves de la IA nunca van al repositorio.** Solo en `.env` (que está en `.gitignore`) y se comparten por mensaje privado. Antes de entregar: `git grep -n "gsk_"` no debe encontrar nada.
6. **Los textos visibles salen del mockup.** Las pruebas los buscan: si cambias un texto, revisa las pruebas en el mismo PR.
7. **Sin funciones fuera de la propuesta:** nada de subir recetas propias, comentarios, valoraciones ni cuentas de administración.

## Qué se recorta si vamos atrasados (en este orden)

1. Fotos de las 12 recetas nuevas (se ve el sticker) y stickers propios para ellas (se usa la estrella).
2. «Editar» en el Perfil (queda como texto, igual que en el mockup).
3. Animaciones (`pop`, `rise`, el toast que se desvanece).
4. Fidelidad al mockup en Guardados y Perfil: bastan las vistas provisionales de Miguel con algo de estilo.
5. **Nunca se recorta:** registro e inicio de sesión, catálogo con filtros, guardar, cocinada con progreso, las alternativas y el asistente con IA real, y las pruebas en verde.

## Plan B de la IA (decisión el sábado a las 18:00)

Si a esa hora `php artisan ia:probar` no responde:

1. Revisar `storage/logs/laravel.log` (ahí queda el error que devolvió Groq), probar otro modelo en `GROQ_MODEL` (lista con `curl` en la [guía de Sebastián, día 1](../guias/sebastian/dia1.md#paso-11--comando-para-probar-la-conexión)) o una clave nueva de otro integrante.
2. Si ninguno funciona, se presenta igual con el estado de error de la IA («El asistente no está disponible» y «Reintentar») y se declara la limitación en el README y en la presentación. **Nunca presentar respuestas escritas a mano como si fueran de la IA.**

## Riesgos (de la propuesta) y cómo los cubre el código

| Riesgo | Mitigación |
|---|---|
| Que la IA invente información o dé respuestas malas | Las reglas del asistente le piden no inventar y le entregamos la receta completa; aviso fijo «La IA puede equivocarse» |
| Alérgenos e intolerancias | Caja de alérgenos en cada receta; el asistente debe advertir; aviso «Revisa alérgenos antes de reemplazar» |
| Depender demasiado de la IA (si falla la API) | Toda la app funciona sin IA; las alternativas ya consultadas quedan en caché; estado de error con «Reintentar» |
| Que se use la IA para otras cosas | Reglas: solo temas de cocina; mensajes de máximo 500 caracteres |
| Límites del plan gratis | Máximo 20 consultas por minuto por persona (`throttle`); las alternativas se guardan una semana en caché |
| Falta de conexión | Las alternativas ya consultadas quedan en caché |
| Falta de tiempo para los stickers | 11 dibujos del mockup + la estrella para el resto |
| Los modelos de IA cambian de nombre | El modelo está en `.env`; `php artisan ia:probar` lo comprueba en segundos |
| Que la propuesta no atraiga usuarios | Fuera del alcance de estos días: se menciona como trabajo futuro |

## Por confirmar con el profesor (jueves o viernes temprano)

- ¿El lunes es presentación en vivo, entrega del repositorio, o ambas? ¿Cuánto dura? ¿Lleva diapositivas?
- ¿Hay que entregar la app publicada en internet o basta con ejecutarla en un computador?

## Guion de la demo (5 minutos)

1. **Problema y persona** (Sebastián, 30 s): Camila, 20 años, cocina poco y le faltan ingredientes.
2. **Registro y catálogo** (Emma, 1 min): crear cuenta, buscar «zapallo», filtrar «Hasta 30 min», guardar una receta.
3. **Detalle y IA** (Sebastián, 1 min 30): marcar pasos, «No lo tengo» en un ingrediente, abrir el asistente y hacer una pregunta.
4. **Gamificación** (Miguel, 1 min): «Marcar como cocinada» → aviso con sticker → Perfil con progreso, stickers y checklist.
5. **Cómo está hecho** (los tres, 1 min): tablas y modelos (Miguel), componentes Blade (Emma), IA en el servidor y pruebas (Sebastián).

Antes de empezar: entrar con la cuenta de Camila en otra pestaña (para mostrar el perfil con progreso) y haber consultado una vez las alternativas que se van a mostrar.

## Cómo pedir ayuda paso a paso

Abrir Claude Code en la carpeta del repo y escribir, por ejemplo: *«Soy Emma, voy en el día 2, paso 7 (catálogo), y la página me dice "Undefined variable $filters"»*. Claude lee tu guía y te ayuda. La idea es que escribas y entiendas el código tú, no que lo pegues.
