# Miguel Figueroa: desarrollo backend

**Eres dueño de:** `database/` (migraciones, datos, seeders y factories), `app/Models/`, los controladores del catálogo, guardados, cocinadas y perfil, `routes/web.php`, `lang/` y las pruebas de esas partes. También de la revisión del backend.

**Tu código, día por día:** [Día 1](../guias/miguel/dia1.md) · [Día 2](../guias/miguel/dia2.md) · [Día 3](../guias/miguel/dia3.md).
**Tiempo estimado:** unas 9 h 30 (3 h 30 el viernes y el sábado, 2 h 30 el domingo).

Tus vistas son **provisionales** (sin diseño): Emma las reemplaza por las del mockup. Lo que importa de ellas es que muestren los datos correctos.

---

## Jueves 12 (noche, ~30 min)

- [ ] Instalar PHP, Composer y Node ([instrucciones](README.md#instalación-jueves-en-la-noche)). Comprobar `php -v`, `composer -V` y `node -v`.
- [ ] Aceptar la invitación al repositorio.
- [ ] Leer `mockup/Mockup de YouCook/src/data.ts` y `store.tsx`: de ahí salen las tablas.

## Viernes 13 ([guía](../guias/miguel/dia1.md))

- [ ] **Migraciones y modelos en PR a las 13:00** (Emma los necesita para la barra).
- [ ] Las 20 recetas y la cuenta de Camila (15:00).
- [ ] Catálogo y detalle con vistas provisionales.
- **Cierre:** `/recetas` filtra y pagina con datos reales.

## Sábado 14 ([guía](../guias/miguel/dia2.md))

- [ ] **Factories a las 10:00** (Sebastián las necesita para sus pruebas).
- [ ] Guardar, cocinada (con el aviso del sticker) y perfil. **PR antes de las 16:00.**
- [ ] Mensajes de validación en español.
- **Cierre:** guardar, cocinar y editar el perfil funcionan y están probados.

## Domingo 15 ([guía](../guias/miguel/dia3.md))

- [ ] Pruebas del perfil (40 pruebas en verde).
- [ ] Fotos de las recetas nuevas y revisión del backend caso por caso (`docs/evidencia/revision-backend.md`).
- [ ] Todo en `main` antes de las 18:00. Ensayo general a las 21:00.

## Lunes 16

- [ ] Presentar la gamificación y explicar el modelo de datos y las pruebas (2 min).
