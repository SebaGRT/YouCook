# Evidencia

Lo que demuestra que la app funciona y quién hizo qué. Se completa el sábado y el domingo.

| Archivo | Quién | Qué |
|---|---|---|
| `capturas/` | Emma | Cada pantalla en escritorio y teléfono, más los estados (IA cargando, alternativas, error, receta cocinada, guardados vacío) |
| `qa-visual.md` | Emma | Revisión de cada pantalla contra el mockup |
| `revision-backend.md` | Miguel | Casos límite del backend y su resultado |
| `ia-alternativas.png`, `ia-chat.png` | Sebastián | Respuestas **reales** de la IA, con fecha visible |
| `pruebas.txt` | Sebastián | Salida de `php artisan test` del domingo (`php artisan test > ../docs/evidencia/pruebas.txt`) |

El historial de commits y PR de cada uno en GitHub es la evidencia de autoría.
